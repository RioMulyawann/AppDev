﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_9
{
    public partial class FormLogin : Form
    {
       
       
        public List<string> listUsername = new List<string>();
        public List<string> listPass = new List<string>();
        int TempIndex = 0;
        public string username = "";
        public FormLogin()
        {
            InitializeComponent();

        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            
            listUsername.Add("admin");
            listPass.Add("admin");


        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            if (!listUsername.Contains(tbUsernameLogin.Text))
            {
                MessageBox.Show("Username can't be found");
            }
            else
            {
                for (int i = 0; i < listUsername.Count; i++)
                {
                    if (listUsername[i] == tbUsernameLogin.Text)
                    {
                        TempIndex = i;
                    }
                }
                if (listPass[TempIndex] == tbPasswordLogIn.Text)
                {
                    username = tbUsernameLogin.Text;
                    tbUsernameLogin.Text = "";
                    tbPasswordLogIn.Text = "";
                    FormMain formMain = new FormMain(this);
                    formMain.Show();
                    this.Hide();
                    
                }
                else
                {
                    MessageBox.Show("Wrong Password");
                }
                
            }
            
        }
    }
}
