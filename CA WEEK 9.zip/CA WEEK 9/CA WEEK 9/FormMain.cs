﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace CA_WEEK_9
{
    public partial class FormMain : Form
    {
        FormLogin formLogin = Application.OpenForms["FormLogin"] as FormLogin;
        FormUser formUser = new FormUser();

        public FormMain(Form _form)
        {
            InitializeComponent();
            
            

        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            formUser.Show();
        }
        
        private void FormMain_Load(object sender, EventArgs e)
        {
            formLogin.Hide();
            statusStripUsername.Text = formLogin.username;
        }

        private void statusStripCalendar_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                statusStripCalendar.Visible = true;
                statusStripCalendar.Text = DateTime.Now.ToString(" ddd, dd - MM - yyyy HH:mm:ss ");
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            formLogin.Show();
            this.Hide();


        }
    }
}
