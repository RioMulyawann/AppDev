﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_9
{
    public partial class FormUser : Form
    {
        FormLogin formLogin = Application.OpenForms["FormLogin"] as FormLogin;
        public FormUser()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (formLogin.listUsername.Contains(tbUsernameUser.Text))
            {
                MessageBox.Show("Username is taken");
            }
            else
            {
                if (tbPasswordUser.Text!=tbConfirmPassUser.Text)
                {
                    MessageBox.Show("Please check your password");
                }
                else
                {
                    MessageBox.Show("Account added successfully");
                    formLogin.listUsername.Add(tbUsernameUser.Text);
                    formLogin.listPass.Add(tbPasswordUser.Text);
                    tbUsernameUser.Text = "";
                    tbPasswordUser.Text = "";
                    tbConfirmPassUser.Text = "";
                    this.Hide();
                }
            }
        }
    }
}
