﻿namespace CA_WEEK_9
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelUsernameLogIn = new System.Windows.Forms.Label();
            this.labelPasswordLogIn = new System.Windows.Forms.Label();
            this.tbUsernameLogin = new System.Windows.Forms.TextBox();
            this.tbPasswordLogIn = new System.Windows.Forms.TextBox();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.btnLogIn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelUsernameLogIn
            // 
            this.labelUsernameLogIn.AutoSize = true;
            this.labelUsernameLogIn.Location = new System.Drawing.Point(197, 206);
            this.labelUsernameLogIn.Name = "labelUsernameLogIn";
            this.labelUsernameLogIn.Size = new System.Drawing.Size(122, 25);
            this.labelUsernameLogIn.TabIndex = 0;
            this.labelUsernameLogIn.Text = "Username: ";
            // 
            // labelPasswordLogIn
            // 
            this.labelPasswordLogIn.AutoSize = true;
            this.labelPasswordLogIn.Location = new System.Drawing.Point(201, 273);
            this.labelPasswordLogIn.Name = "labelPasswordLogIn";
            this.labelPasswordLogIn.Size = new System.Drawing.Size(118, 25);
            this.labelPasswordLogIn.TabIndex = 1;
            this.labelPasswordLogIn.Text = "Password: ";
            // 
            // tbUsernameLogin
            // 
            this.tbUsernameLogin.Location = new System.Drawing.Point(325, 206);
            this.tbUsernameLogin.Name = "tbUsernameLogin";
            this.tbUsernameLogin.Size = new System.Drawing.Size(336, 31);
            this.tbUsernameLogin.TabIndex = 2;
            // 
            // tbPasswordLogIn
            // 
            this.tbPasswordLogIn.Location = new System.Drawing.Point(325, 270);
            this.tbPasswordLogIn.Name = "tbPasswordLogIn";
            this.tbPasswordLogIn.Size = new System.Drawing.Size(336, 31);
            this.tbPasswordLogIn.TabIndex = 3;
            this.tbPasswordLogIn.UseSystemPasswordChar = true;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWelcome.Location = new System.Drawing.Point(310, 68);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(358, 85);
            this.labelWelcome.TabIndex = 4;
            this.labelWelcome.Text = "Welcome";
            // 
            // btnLogIn
            // 
            this.btnLogIn.Location = new System.Drawing.Point(431, 325);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.Size = new System.Drawing.Size(127, 38);
            this.btnLogIn.TabIndex = 5;
            this.btnLogIn.Text = "Log In";
            this.btnLogIn.UseVisualStyleBackColor = true;
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 409);
            this.Controls.Add(this.btnLogIn);
            this.Controls.Add(this.labelWelcome);
            this.Controls.Add(this.tbPasswordLogIn);
            this.Controls.Add(this.tbUsernameLogin);
            this.Controls.Add(this.labelPasswordLogIn);
            this.Controls.Add(this.labelUsernameLogIn);
            this.Name = "FormLogin";
            this.Text = "FormLogin";
            this.Load += new System.EventHandler(this.FormLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelUsernameLogIn;
        private System.Windows.Forms.Label labelPasswordLogIn;
        private System.Windows.Forms.TextBox tbUsernameLogin;
        private System.Windows.Forms.TextBox tbPasswordLogIn;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.Button btnLogIn;
    }
}