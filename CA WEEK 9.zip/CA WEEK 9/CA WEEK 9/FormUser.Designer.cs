﻿namespace CA_WEEK_9
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbPasswordUser = new System.Windows.Forms.TextBox();
            this.tbUsernameUser = new System.Windows.Forms.TextBox();
            this.labelPasswordUser = new System.Windows.Forms.Label();
            this.labelUsernameUser = new System.Windows.Forms.Label();
            this.tbConfirmPassUser = new System.Windows.Forms.TextBox();
            this.labelConfirmPassUser = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbPasswordUser
            // 
            this.tbPasswordUser.Location = new System.Drawing.Point(265, 111);
            this.tbPasswordUser.Name = "tbPasswordUser";
            this.tbPasswordUser.Size = new System.Drawing.Size(336, 31);
            this.tbPasswordUser.TabIndex = 7;
            // 
            // tbUsernameUser
            // 
            this.tbUsernameUser.Location = new System.Drawing.Point(265, 56);
            this.tbUsernameUser.Name = "tbUsernameUser";
            this.tbUsernameUser.Size = new System.Drawing.Size(336, 31);
            this.tbUsernameUser.TabIndex = 6;
            // 
            // labelPasswordUser
            // 
            this.labelPasswordUser.AutoSize = true;
            this.labelPasswordUser.Location = new System.Drawing.Point(50, 114);
            this.labelPasswordUser.Name = "labelPasswordUser";
            this.labelPasswordUser.Size = new System.Drawing.Size(118, 25);
            this.labelPasswordUser.TabIndex = 5;
            this.labelPasswordUser.Text = "Password: ";
            // 
            // labelUsernameUser
            // 
            this.labelUsernameUser.AutoSize = true;
            this.labelUsernameUser.Location = new System.Drawing.Point(50, 62);
            this.labelUsernameUser.Name = "labelUsernameUser";
            this.labelUsernameUser.Size = new System.Drawing.Size(122, 25);
            this.labelUsernameUser.TabIndex = 4;
            this.labelUsernameUser.Text = "Username: ";
            // 
            // tbConfirmPassUser
            // 
            this.tbConfirmPassUser.Location = new System.Drawing.Point(265, 160);
            this.tbConfirmPassUser.Name = "tbConfirmPassUser";
            this.tbConfirmPassUser.Size = new System.Drawing.Size(336, 31);
            this.tbConfirmPassUser.TabIndex = 9;
            // 
            // labelConfirmPassUser
            // 
            this.labelConfirmPassUser.AutoSize = true;
            this.labelConfirmPassUser.Location = new System.Drawing.Point(50, 166);
            this.labelConfirmPassUser.Name = "labelConfirmPassUser";
            this.labelConfirmPassUser.Size = new System.Drawing.Size(198, 25);
            this.labelConfirmPassUser.TabIndex = 8;
            this.labelConfirmPassUser.Text = "Confirm Password: ";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(265, 224);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(137, 32);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 333);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.tbConfirmPassUser);
            this.Controls.Add(this.labelConfirmPassUser);
            this.Controls.Add(this.tbPasswordUser);
            this.Controls.Add(this.tbUsernameUser);
            this.Controls.Add(this.labelPasswordUser);
            this.Controls.Add(this.labelUsernameUser);
            this.Name = "FormUser";
            this.Text = "FormUser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbPasswordUser;
        private System.Windows.Forms.TextBox tbUsernameUser;
        private System.Windows.Forms.Label labelPasswordUser;
        private System.Windows.Forms.Label labelUsernameUser;
        private System.Windows.Forms.TextBox tbConfirmPassUser;
        private System.Windows.Forms.Label labelConfirmPassUser;
        private System.Windows.Forms.Button btnAdd;
    }
}