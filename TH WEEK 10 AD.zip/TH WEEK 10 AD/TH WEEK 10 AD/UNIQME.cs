﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TH_WEEK_10_AD
{
    public partial class UNIQME : Form
    {
        DataTable dtTopwear = new DataTable();
        DataTable dtBottomwear = new DataTable();
        DataTable dtAccessories = new DataTable();
        DataTable dtShoppingList = new DataTable();
        string type = "";
        int quantityshirt1 = 0;
        int qtytshirt1 = 0;
        int qtypants1 = 0;
        int qtylongpants1 = 0;
        int qtyshoes1 = 0;
        int qtyjewel1 = 0;
        int quantityshirt2 = 0;
        int qtytshirt2 = 0;
        int qtypants2 = 0;
        int qtylongpants2 = 0;
        int qtyshoes2 = 0;
        int qtyjewel2 = 0;
        int quantityshirt3= 0;
        int qtytshirt3 = 0;
        int qtypants3 = 0;
        int qtylongpants3 = 0;
        int qtyshoes3 = 0;
        int qtyjewel3= 0;
        int qtyupload = 0;
        List<string> namelist = new List<string>();



        public UNIQME()
        {
            InitializeComponent();
            dataGridViewShoppingList.DataSource = dtShoppingList;

            dtShoppingList.Columns.Add("Item Name");
            dtShoppingList.Columns.Add("Quantity");
            dtShoppingList.Columns.Add("Price");
            dtShoppingList.Columns.Add("Total");

            dtTopwear.Columns.Add("Name");
            dtTopwear.Columns.Add("Price");
            dtBottomwear.Columns.Add("Name");
            dtBottomwear.Columns.Add("Price");
            dtAccessories.Columns.Add("Name");
            dtAccessories.Columns.Add("Price");

            dtTopwear.Rows.Add("Oversize Fit T-Shirt", "Rp.200.000");
            dtTopwear.Rows.Add("AIRism T-Shirt", "Rp.250.000");
            dtTopwear.Rows.Add("Graphic T-Shirt", "Rp.300.000");

            dtTopwear.Rows.Add("Cotton Regular Fit Shirt", "Rp.400.000");
            dtTopwear.Rows.Add("Cotton Muscle Fit Shirt", "Rp.350.000");
            dtTopwear.Rows.Add("Flannel Regular Fit Shirt", "Rp.450.000");


            dtBottomwear.Rows.Add("Cargo pants", "Rp.250.000");
            dtBottomwear.Rows.Add("SweatShorts", "Rp.200.000");
            dtBottomwear.Rows.Add("Running Short Pants", "Rp.300.000");

            dtBottomwear.Rows.Add("Cargo Long Pants", "Rp.400.000");
            dtBottomwear.Rows.Add("Black Long Jeans", "Rp.600.000");
            dtBottomwear.Rows.Add("Relaxed Fit Joggers", "Rp.450.000");


            dtAccessories.Rows.Add("Loafers", "Rp.700.000");
            dtAccessories.Rows.Add("Hiking Boots", "Rp.850.000");
            dtAccessories.Rows.Add("Air Jordan 1", "Rp.1.400.000");

            dtAccessories.Rows.Add("Diamond Earrings", "Rp.2.500.000");
            dtAccessories.Rows.Add("Diamong Ring", "Rp.4.000.000");
            dtAccessories.Rows.Add("Golden Necklace", "Rp.1.700.000");


        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            type = "tshirt";
            gantiGambar();

            panelOthers.Enabled = false;
            panelOthers.Visible = false;

            labelProductNameOne.Text = dtTopwear.Rows[0][0].ToString();
            labelProductPriceOne.Text = dtTopwear.Rows[0][1].ToString();
            labelProductNameTwo.Text = dtTopwear.Rows[1][0].ToString();
            labelProductPriceTwo.Text = dtTopwear.Rows[1][1].ToString();
            labelProductNameThree.Text = dtTopwear.Rows[2][0].ToString();
            labelProductPriceThree.Text = dtTopwear.Rows[2][1].ToString();

            labelProductNameOne.Visible = true;
            labelProductNameTwo.Visible = true;
            labelProductNameThree.Visible = true;
            labelProductPriceOne.Visible = true;
            labelProductPriceTwo.Visible = true;
            labelProductPriceThree.Visible = true;
            btnAdd1.Visible = true;
            btnAdd2.Visible = true;
            btnAdd3.Visible = true;

            gambarSatu.Visible = true;
            gambarDua.Visible = true;
            gambarTiga.Visible = true;



        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            type = "shirt";
            gantiGambar();

            panelOthers.Enabled = false;
            panelOthers.Visible = false;

            labelProductNameOne.Text = dtTopwear.Rows[3][0].ToString();
            labelProductPriceOne.Text = dtTopwear.Rows[3][1].ToString();
            labelProductNameTwo.Text = dtTopwear.Rows[4][0].ToString();
            labelProductPriceTwo.Text = dtTopwear.Rows[4][1].ToString();
            labelProductNameThree.Text = dtTopwear.Rows[5][0].ToString();
            labelProductPriceThree.Text = dtTopwear.Rows[5][1].ToString();

            labelProductNameOne.Visible = true;
            labelProductNameTwo.Visible = true;
            labelProductNameThree.Visible = true;
            labelProductPriceOne.Visible = true;
            labelProductPriceTwo.Visible = true;
            labelProductPriceThree.Visible = true;
            btnAdd1.Visible = true;
            btnAdd2.Visible = true;
            btnAdd3.Visible = true;

            gambarSatu.Visible = true;
            gambarDua.Visible = true;
            gambarTiga.Visible = true;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            type = "pants";
            gantiGambar();

            panelOthers.Enabled = false;
            panelOthers.Visible = false;

            labelProductNameOne.Text = dtBottomwear.Rows[0][0].ToString();
            labelProductPriceOne.Text = dtBottomwear.Rows[0][1].ToString();
            labelProductNameTwo.Text = dtBottomwear.Rows[1][0].ToString();
            labelProductPriceTwo.Text = dtBottomwear.Rows[1][1].ToString();
            labelProductNameThree.Text = dtBottomwear.Rows[2][0].ToString();
            labelProductPriceThree.Text = dtBottomwear.Rows[2][1].ToString();

            labelProductNameOne.Visible = true;
            labelProductNameTwo.Visible = true;
            labelProductNameThree.Visible = true;
            labelProductPriceOne.Visible = true;
            labelProductPriceTwo.Visible = true;
            labelProductPriceThree.Visible = true;
            btnAdd1.Visible = true;
            btnAdd2.Visible = true;
            btnAdd3.Visible = true;

            gambarSatu.Visible = true;
            gambarDua.Visible = true;
            gambarTiga.Visible = true;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            type = "longpants";
            gantiGambar();

            panelOthers.Enabled = false;
            panelOthers.Visible = false;

            labelProductNameOne.Text = dtBottomwear.Rows[3][0].ToString();
            labelProductPriceOne.Text = dtBottomwear.Rows[3][1].ToString();
            labelProductNameTwo.Text = dtBottomwear.Rows[4][0].ToString();
            labelProductPriceTwo.Text = dtBottomwear.Rows[4][1].ToString();
            labelProductNameThree.Text = dtBottomwear.Rows[5][0].ToString();
            labelProductPriceThree.Text = dtBottomwear.Rows[5][1].ToString();

            labelProductNameOne.Visible = true;
            labelProductNameTwo.Visible = true;
            labelProductNameThree.Visible = true;
            labelProductPriceOne.Visible = true;
            labelProductPriceTwo.Visible = true;
            labelProductPriceThree.Visible = true;
            btnAdd1.Visible = true;
            btnAdd2.Visible = true;
            btnAdd3.Visible = true;

            gambarSatu.Visible = true;
            gambarDua.Visible = true;
            gambarTiga.Visible = true;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            type = "shoes";
            gantiGambar();

            panelOthers.Enabled = false;
            panelOthers.Visible = false;

            labelProductNameOne.Text = dtAccessories.Rows[0][0].ToString();
            labelProductPriceOne.Text = dtAccessories.Rows[0][1].ToString();
            labelProductNameTwo.Text = dtAccessories.Rows[1][0].ToString();
            labelProductPriceTwo.Text = dtAccessories.Rows[1][1].ToString();
            labelProductNameThree.Text = dtAccessories.Rows[2][0].ToString();
            labelProductPriceThree.Text = dtAccessories.Rows[2][1].ToString();

            labelProductNameOne.Visible = true;
            labelProductNameTwo.Visible = true;
            labelProductNameThree.Visible = true;
            labelProductPriceOne.Visible = true;
            labelProductPriceTwo.Visible = true;
            labelProductPriceThree.Visible = true;
            btnAdd1.Visible = true;
            btnAdd2.Visible = true;
            btnAdd3.Visible = true;

            gambarSatu.Visible = true;
            gambarDua.Visible = true;
            gambarTiga.Visible = true;
        }

        private void jewlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            type = "jewel";
            gantiGambar();

            panelOthers.Enabled = false;
            panelOthers.Visible = false;

            labelProductNameOne.Text = dtAccessories.Rows[3][0].ToString();
            labelProductPriceOne.Text = dtAccessories.Rows[3][1].ToString();
            labelProductNameTwo.Text = dtAccessories.Rows[4][0].ToString();
            labelProductPriceTwo.Text = dtAccessories.Rows[4][1].ToString();
            labelProductNameThree.Text = dtAccessories.Rows[5][0].ToString();
            labelProductPriceThree.Text = dtAccessories.Rows[5][1].ToString();

            labelProductNameOne.Visible = true;
            labelProductNameTwo.Visible = true;
            labelProductNameThree.Visible = true;
            labelProductPriceOne.Visible = true;
            labelProductPriceTwo.Visible = true;
            labelProductPriceThree.Visible = true;
            btnAdd1.Visible = true;
            btnAdd2.Visible = true;
            btnAdd3.Visible = true;

            gambarSatu.Visible = true;
            gambarDua.Visible = true;
            gambarTiga.Visible = true;
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            labelProductNameOne.Visible = false;
            labelProductNameTwo.Visible = false;
            labelProductNameThree.Visible = false;
            labelProductPriceOne.Visible = false;
            labelProductPriceTwo.Visible = false;
            labelProductPriceThree.Visible = false;
            btnAdd1.Visible = false;
            btnAdd2.Visible = false;
            btnAdd3.Visible = false;

            gambarSatu.Visible = false;
            gambarDua.Visible = false;
            gambarTiga.Visible = false;

            panelOthers.Enabled = true;
            panelOthers.Visible = true;


        }
        public void gantiGambar()
        {
            if (type == "tshirt")
            {
                gambarSatu.Image = TH_WEEK_10_AD.Properties.Resources.tshirt1;
                gambarDua.Image = TH_WEEK_10_AD.Properties.Resources.tshirt2;
                gambarTiga.Image = TH_WEEK_10_AD.Properties.Resources.tshirt3;
            }
            else if (type == "shirt")
            {
                gambarSatu.Image = TH_WEEK_10_AD.Properties.Resources.shirt1;
                gambarDua.Image = TH_WEEK_10_AD.Properties.Resources.shirt2;
                gambarTiga.Image = TH_WEEK_10_AD.Properties.Resources.shirt3;
            }
            else if (type == "pants")
            {
                gambarSatu.Image = TH_WEEK_10_AD.Properties.Resources.pants1;
                gambarDua.Image = TH_WEEK_10_AD.Properties.Resources.pants2;
                gambarTiga.Image = TH_WEEK_10_AD.Properties.Resources.pants3;
            }
            else if (type == "longpants")
            {
                gambarSatu.Image = TH_WEEK_10_AD.Properties.Resources.longpants1;
                gambarDua.Image = TH_WEEK_10_AD.Properties.Resources.longpants2;
                gambarTiga.Image = TH_WEEK_10_AD.Properties.Resources.longpants3;
            }
            else if (type == "shoes")
            {
                gambarSatu.Image = TH_WEEK_10_AD.Properties.Resources.shoes1;
                gambarDua.Image = TH_WEEK_10_AD.Properties.Resources.shoes2;
                gambarTiga.Image = TH_WEEK_10_AD.Properties.Resources.shoes3;
            }
            else if (type == "jewel")
            {
                gambarSatu.Image = TH_WEEK_10_AD.Properties.Resources.jewel1;
                gambarDua.Image = TH_WEEK_10_AD.Properties.Resources.jewel2;
                gambarTiga.Image = TH_WEEK_10_AD.Properties.Resources.jewel3;
            }
        }

        private void btnAdd1_Click(object sender, EventArgs e)
        {

            if (type == "shirt")
            {

                if (quantityshirt1 == 0)
                {
                    quantityshirt1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = quantityshirt1 * temp;

                    dtShoppingList.Rows.Add(labelProductNameOne.Text, (quantityshirt1).ToString(), labelProductPriceOne.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (quantityshirt1 > 0)
                {

                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));

                    foreach (DataRow dr in dtShoppingList.Rows)
                    {
                        if (dr[0].ToString() == labelProductNameOne.Text)
                        {
                            quantityshirt1++;
                            dr["Quantity"] = quantityshirt1.ToString();
                            int total = quantityshirt1 * temp;
                            dr["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                        }
                    }


                }

            }
            else if (type == "tshirt")
            {
                if (qtytshirt1 == 0)
                {
                    qtytshirt1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtytshirt1 * temp;

                    dtShoppingList.Rows.Add(labelProductNameOne.Text, (qtytshirt1).ToString(), labelProductPriceOne.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtytshirt1 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameOne.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtytshirt1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtytshirt1 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtytshirt1.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                }
            }
            else if (type == "pants")
            {
                if (qtypants1 == 0)
                {
                    qtypants1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtypants1 * temp;

                    dtShoppingList.Rows.Add(labelProductNameOne.Text, (qtypants1).ToString(), labelProductPriceOne.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtypants1 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameOne.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtypants1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtypants1 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtypants1.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                }
            }
            else if (type == "longpants")
            {
                if (qtylongpants1 == 0)
                {
                    qtylongpants1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtylongpants1 * temp;

                    dtShoppingList.Rows.Add(labelProductNameOne.Text, (qtylongpants1).ToString(), labelProductPriceOne.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtylongpants1 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameOne.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtylongpants1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtylongpants1 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtylongpants1.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                }
            }
            else if (type == "shoes")
            {

                if (qtyshoes1 == 0)
                {
                    qtyshoes1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtyshoes1 * temp;

                    dtShoppingList.Rows.Add(labelProductNameOne.Text, (qtyshoes1).ToString(), labelProductPriceOne.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtyshoes1 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameOne.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtyshoes1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtyshoes1 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtyshoes1.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                }

            }
            else if (type == "jewel")
            {
                if (qtyjewel1 == 0)
                {
                    qtyjewel1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtyjewel1 * temp;

                    dtShoppingList.Rows.Add(labelProductNameOne.Text, (qtyjewel1).ToString(), labelProductPriceOne.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtyjewel1 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameOne.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtyjewel1++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceOne.Text, @",.*|\D", ""));
                    int total = qtyjewel1 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtyjewel1.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                }


            }

            renewDatagrid();
        }
        public void renewDatagrid()
        {
            int totals = 0;
            int temps = 0;

            foreach (DataRow row in dtShoppingList.Rows)
            {
                temps = int.Parse(Regex.Replace(row["Total"].ToString(), @",.*|\D", ""));
                totals = totals + temps;
            }
            tbsubtotal.Text = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", totals).ToString();

            tbtotal.Text = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", totals * 1.1).ToString();
        }
        

        private void btnAdd2_Click(object sender, EventArgs e)
        {
            {

                if (type == "shirt")
                {

                    if (quantityshirt2 == 0)
                    {
                        quantityshirt2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = quantityshirt2 * temp;

                        dtShoppingList.Rows.Add(labelProductNameTwo.Text, (quantityshirt2).ToString(), labelProductPriceTwo.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                    }
                    else if (quantityshirt2 > 0)
                    {

                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));

                        foreach (DataRow dr in dtShoppingList.Rows)
                        {
                            if (dr[0].ToString() == labelProductNameTwo.Text)
                            {
                                quantityshirt2++;
                                dr["Quantity"] = quantityshirt2.ToString();
                                int total = quantityshirt2 * temp;
                                dr["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                               


                            }
                        }
                        //for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                        //{
                        //    index++;
                        //    if (dtShoppingList.Rows[i][0] == labelProductNameTwo.Text)
                        //    {
                        //        break;
                        //    }

                        //}
                        //quantityshirt2++;
                        //int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        //int total = quantityshirt2 * temp;

                        //dtShoppingList.Rows[index - 1]["Quantity"] = quantityshirt2.ToString();
                        //dtShoppingList.Rows[index - 1]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                    }

                }
                else if (type == "tshirt")
                {
                    if (qtytshirt2 == 0)
                    {
                        qtytshirt2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtytshirt2 * temp;

                        dtShoppingList.Rows.Add(labelProductNameTwo.Text, (qtytshirt2).ToString(), labelProductPriceTwo.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                    }
                    else if (qtytshirt2 > 0)
                    {
                        int index = 0;
                        for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                        {
                            if (dtShoppingList.Rows[i][0].ToString() != labelProductNameTwo.Text)
                            {
                                index++;
                            }
                            else
                            { break; }
                        }
                        qtytshirt2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtytshirt2 * temp;

                        dtShoppingList.Rows[index]["Quantity"] = qtytshirt2.ToString();
                        dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                    }
                }
                else if (type == "pants")
                {
                    if (qtypants2 == 0)
                    {
                        qtypants2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtypants2 * temp;

                        dtShoppingList.Rows.Add(labelProductNameTwo.Text, (qtypants2).ToString(), labelProductPriceTwo.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                    }
                    else if (qtypants2 > 0)
                    {
                        int index = 0;
                        for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                        {
                            if (dtShoppingList.Rows[i][0].ToString() != labelProductNameTwo.Text)
                            {
                                index++;
                            }
                            else
                            { break; }
                        }
                        qtypants2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtypants2 * temp;

                        dtShoppingList.Rows[index]["Quantity"] = qtypants2.ToString();
                        dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                    }
                }
                else if (type == "longpants")
                {
                    if (qtylongpants2 == 0)
                    {
                        qtylongpants2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtylongpants2 * temp;

                        dtShoppingList.Rows.Add(labelProductNameTwo.Text, (qtylongpants2).ToString(), labelProductPriceTwo.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                    }
                    else if (qtylongpants2 > 0)
                    {
                        int index = 0;
                        for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                        {
                            if (dtShoppingList.Rows[i][0].ToString() != labelProductNameTwo.Text)
                            {
                                index++;
                            }
                            else
                            { break; }
                        }
                        qtylongpants2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtylongpants2 * temp;

                        dtShoppingList.Rows[index]["Quantity"] = qtylongpants2.ToString();
                        dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                    }
                }
                else if (type == "shoes")
                {

                    if (qtyshoes2 == 0)
                    {
                        qtyshoes2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtyshoes2 * temp;

                        dtShoppingList.Rows.Add(labelProductNameTwo.Text, (qtyshoes2).ToString(), labelProductPriceTwo.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                    }
                    else if (qtyshoes2 > 0)
                    {
                        int index = 0;
                        for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                        {
                            if (dtShoppingList.Rows[i][0].ToString() != labelProductNameTwo.Text)
                            {
                                index++;
                            }
                            else
                            { break; }
                        }
                        qtyshoes2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtyshoes2 * temp;

                        dtShoppingList.Rows[index]["Quantity"] = qtyshoes2.ToString();
                        dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                    }

                }
                else if (type == "jewel")
                {
                    if (qtyjewel2 == 0)
                    {
                        qtyjewel2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtyjewel2 * temp;

                        dtShoppingList.Rows.Add(labelProductNameTwo.Text, (qtyjewel2).ToString(), labelProductPriceTwo.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                    }
                    else if (qtyjewel2 > 0)
                    {
                        int index = 0;
                        for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                        {
                            if (dtShoppingList.Rows[i][0].ToString() != labelProductNameTwo.Text)
                            {
                                index++;
                            }
                            else
                            { break; }
                        }
                        qtyjewel2++;
                        int temp = int.Parse(Regex.Replace(labelProductPriceTwo.Text, @",.*|\D", ""));
                        int total = qtyjewel2 * temp;

                        dtShoppingList.Rows[index]["Quantity"] = qtyjewel2.ToString();
                        dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                    }


                }



                }
            renewDatagrid();
        }

        

        private void btnAdd3_Click(object sender, EventArgs e)
        {

            if (type == "shirt")
            {

                if (quantityshirt3 == 0)
                {
                    quantityshirt3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = quantityshirt3 * temp;

                    dtShoppingList.Rows.Add(labelProductNameThree.Text, (quantityshirt3).ToString(), labelProductPriceThree.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (quantityshirt3 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameThree.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    quantityshirt3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = quantityshirt3 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = quantityshirt3.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                }

            }
            else if (type == "tshirt")
            {
                if (qtytshirt3 == 0)
                {
                    qtytshirt3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtytshirt3 * temp;

                    dtShoppingList.Rows.Add(labelProductNameThree.Text, (qtytshirt3).ToString(), labelProductPriceThree.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtytshirt3 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameThree.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtytshirt3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtytshirt3 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtytshirt3.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                }
            }
            else if (type == "pants")
            {
                if (qtypants3 == 0)
                {
                    qtypants3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtypants3 * temp;

                    dtShoppingList.Rows.Add(labelProductNameThree.Text, (qtypants3).ToString(), labelProductPriceThree.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtypants3 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameThree.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtypants3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtypants3 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtypants3.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();

                }
            }
            else if (type == "longpants")
            {
                if (qtylongpants3 == 0)
                {
                    qtylongpants3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtylongpants3 * temp;

                    dtShoppingList.Rows.Add(labelProductNameThree.Text, (qtylongpants3).ToString(), labelProductPriceThree.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtylongpants3 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameThree.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtylongpants3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtylongpants3 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtylongpants3.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                }
            }
            else if (type == "shoes")
            {

                if (qtyshoes3 == 0)
                {
                    qtyshoes3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtyshoes3 * temp;

                    dtShoppingList.Rows.Add(labelProductNameThree.Text, (qtyshoes3).ToString(), labelProductPriceThree.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtyshoes3 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameThree.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtyshoes3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtyshoes3 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtyshoes3.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                }

            }
            else if (type == "jewel")
            {
                if (qtyjewel3 == 0)
                {
                    qtyjewel3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtyjewel3 * temp;

                    dtShoppingList.Rows.Add(labelProductNameThree.Text, (qtyjewel3).ToString(), labelProductPriceThree.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                }
                else if (qtyjewel3 > 0)
                {
                    int index = 0;
                    for (int i = 0; i < dtShoppingList.Rows.Count; i++)
                    {
                        if (dtShoppingList.Rows[i][0].ToString() != labelProductNameThree.Text)
                        {
                            index++;
                        }
                        else
                        { break; }
                    }
                    qtyjewel3++;
                    int temp = int.Parse(Regex.Replace(labelProductPriceThree.Text, @",.*|\D", ""));
                    int total = qtyjewel3 * temp;

                    dtShoppingList.Rows[index]["Quantity"] = qtyjewel3.ToString();
                    dtShoppingList.Rows[index]["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                    
                }
                
            }
            renewDatagrid();
        }

        private void btnUploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                tbitemname.Enabled = true;
                tbitemprice.Enabled = true;
                btnAddtoCartUpload.Enabled = true;
                // display image in picture box
                gambarUpload.Image = new Bitmap(open.FileName);
                // image file path
                //textBox1.Text = open.FileName;
            }
            
        }

        private void btnAddtoCartUpload_Click(object sender, EventArgs e)
        {
            if (!namelist.Contains(tbitemname.Text))
            {
                qtyupload = 0;
                if (qtyupload == 0)
                {
                    qtyupload++;
                    int temp = Convert.ToInt32(tbitemprice.Text);
                    int total = qtyupload * temp;

                    dtShoppingList.Rows.Add(tbitemname.Text, (qtyupload).ToString(), tbitemprice.Text, string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString());
                    namelist.Add(tbitemname.Text);
                    qtyupload++;
                }
               
                renewDatagrid();
            }
            else
            {
               
                foreach (DataRow dr in dtShoppingList.Rows)
                {
                    if (dr[0].ToString() == tbitemname.Text)
                    {
                        qtyupload = Convert.ToInt32(dr["Quantity"]);
                        qtyupload++;
                        int total = qtyupload * Convert.ToInt32(tbitemprice.Text);
                        
                        

                       
                        dr["Quantity"] = qtyupload.ToString();
                        dr["Total"] = string.Format(CultureInfo.CreateSpecificCulture("id-id"), "Rp. {0:N}", total).ToString();
                    }
                }
                
                renewDatagrid();
            }
            
        }

        private void dataGridViewShoppingList_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            renewDatagrid();
        }
    }         

    
}
