﻿namespace TH_WEEK_10_AD
{
    partial class UNIQME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridViewShoppingList = new System.Windows.Forms.DataGridView();
            this.labelsubtotal = new System.Windows.Forms.Label();
            this.labeltotal = new System.Windows.Forms.Label();
            this.tbsubtotal = new System.Windows.Forms.TextBox();
            this.tbtotal = new System.Windows.Forms.TextBox();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gambarSatu = new System.Windows.Forms.PictureBox();
            this.gambarDua = new System.Windows.Forms.PictureBox();
            this.gambarTiga = new System.Windows.Forms.PictureBox();
            this.labelProductNameOne = new System.Windows.Forms.Label();
            this.labelProductPriceOne = new System.Windows.Forms.Label();
            this.labelProductPriceTwo = new System.Windows.Forms.Label();
            this.labelProductNameTwo = new System.Windows.Forms.Label();
            this.labelProductPriceThree = new System.Windows.Forms.Label();
            this.labelProductNameThree = new System.Windows.Forms.Label();
            this.panelOthers = new System.Windows.Forms.Panel();
            this.labelUploadImage = new System.Windows.Forms.Label();
            this.btnUploadImage = new System.Windows.Forms.Button();
            this.gambarUpload = new System.Windows.Forms.PictureBox();
            this.labelitemname = new System.Windows.Forms.Label();
            this.labelitemprice = new System.Windows.Forms.Label();
            this.tbitemname = new System.Windows.Forms.TextBox();
            this.tbitemprice = new System.Windows.Forms.TextBox();
            this.btnAddtoCartUpload = new System.Windows.Forms.Button();
            this.btnAdd1 = new System.Windows.Forms.Button();
            this.btnAdd2 = new System.Windows.Forms.Button();
            this.btnAdd3 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShoppingList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambarSatu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambarDua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambarTiga)).BeginInit();
            this.panelOthers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gambarUpload)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1165, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewlToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dataGridViewShoppingList
            // 
            this.dataGridViewShoppingList.AllowUserToAddRows = false;
            this.dataGridViewShoppingList.AllowUserToResizeColumns = false;
            this.dataGridViewShoppingList.AllowUserToResizeRows = false;
            this.dataGridViewShoppingList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShoppingList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewShoppingList.Location = new System.Drawing.Point(650, 27);
            this.dataGridViewShoppingList.MultiSelect = false;
            this.dataGridViewShoppingList.Name = "dataGridViewShoppingList";
            this.dataGridViewShoppingList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewShoppingList.Size = new System.Drawing.Size(468, 284);
            this.dataGridViewShoppingList.TabIndex = 1;
            this.dataGridViewShoppingList.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dataGridViewShoppingList_UserDeletedRow);
            // 
            // labelsubtotal
            // 
            this.labelsubtotal.AutoSize = true;
            this.labelsubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsubtotal.Location = new System.Drawing.Point(655, 320);
            this.labelsubtotal.Name = "labelsubtotal";
            this.labelsubtotal.Size = new System.Drawing.Size(128, 25);
            this.labelsubtotal.TabIndex = 2;
            this.labelsubtotal.Text = "Sub-Total: ";
            // 
            // labeltotal
            // 
            this.labeltotal.AutoSize = true;
            this.labeltotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltotal.Location = new System.Drawing.Point(704, 345);
            this.labeltotal.Name = "labeltotal";
            this.labeltotal.Size = new System.Drawing.Size(79, 25);
            this.labeltotal.TabIndex = 3;
            this.labeltotal.Text = "Total: ";
            // 
            // tbsubtotal
            // 
            this.tbsubtotal.Enabled = false;
            this.tbsubtotal.Location = new System.Drawing.Point(774, 322);
            this.tbsubtotal.Name = "tbsubtotal";
            this.tbsubtotal.Size = new System.Drawing.Size(171, 20);
            this.tbsubtotal.TabIndex = 4;
            // 
            // tbtotal
            // 
            this.tbtotal.Enabled = false;
            this.tbtotal.Location = new System.Drawing.Point(774, 348);
            this.tbtotal.Name = "tbtotal";
            this.tbtotal.Size = new System.Drawing.Size(171, 20);
            this.tbtotal.TabIndex = 5;
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewlToolStripMenuItem
            // 
            this.jewlToolStripMenuItem.Name = "jewlToolStripMenuItem";
            this.jewlToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.jewlToolStripMenuItem.Text = "Jewelleries";
            this.jewlToolStripMenuItem.Click += new System.EventHandler(this.jewlToolStripMenuItem_Click);
            // 
            // gambarSatu
            // 
            this.gambarSatu.Location = new System.Drawing.Point(12, 27);
            this.gambarSatu.Name = "gambarSatu";
            this.gambarSatu.Size = new System.Drawing.Size(155, 235);
            this.gambarSatu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gambarSatu.TabIndex = 6;
            this.gambarSatu.TabStop = false;
            this.gambarSatu.Visible = false;
            // 
            // gambarDua
            // 
            this.gambarDua.Location = new System.Drawing.Point(228, 27);
            this.gambarDua.Name = "gambarDua";
            this.gambarDua.Size = new System.Drawing.Size(155, 235);
            this.gambarDua.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gambarDua.TabIndex = 7;
            this.gambarDua.TabStop = false;
            this.gambarDua.Visible = false;
            // 
            // gambarTiga
            // 
            this.gambarTiga.Location = new System.Drawing.Point(441, 27);
            this.gambarTiga.Name = "gambarTiga";
            this.gambarTiga.Size = new System.Drawing.Size(155, 235);
            this.gambarTiga.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gambarTiga.TabIndex = 8;
            this.gambarTiga.TabStop = false;
            this.gambarTiga.Visible = false;
            // 
            // labelProductNameOne
            // 
            this.labelProductNameOne.AutoSize = true;
            this.labelProductNameOne.Location = new System.Drawing.Point(12, 277);
            this.labelProductNameOne.Name = "labelProductNameOne";
            this.labelProductNameOne.Size = new System.Drawing.Size(35, 13);
            this.labelProductNameOne.TabIndex = 9;
            this.labelProductNameOne.Text = "label1";
            this.labelProductNameOne.Visible = false;
            // 
            // labelProductPriceOne
            // 
            this.labelProductPriceOne.AutoSize = true;
            this.labelProductPriceOne.Location = new System.Drawing.Point(12, 298);
            this.labelProductPriceOne.Name = "labelProductPriceOne";
            this.labelProductPriceOne.Size = new System.Drawing.Size(35, 13);
            this.labelProductPriceOne.TabIndex = 10;
            this.labelProductPriceOne.Text = "label2";
            this.labelProductPriceOne.Visible = false;
            // 
            // labelProductPriceTwo
            // 
            this.labelProductPriceTwo.AutoSize = true;
            this.labelProductPriceTwo.Location = new System.Drawing.Point(225, 298);
            this.labelProductPriceTwo.Name = "labelProductPriceTwo";
            this.labelProductPriceTwo.Size = new System.Drawing.Size(35, 13);
            this.labelProductPriceTwo.TabIndex = 12;
            this.labelProductPriceTwo.Text = "label2";
            this.labelProductPriceTwo.Visible = false;
            // 
            // labelProductNameTwo
            // 
            this.labelProductNameTwo.AutoSize = true;
            this.labelProductNameTwo.Location = new System.Drawing.Point(225, 277);
            this.labelProductNameTwo.Name = "labelProductNameTwo";
            this.labelProductNameTwo.Size = new System.Drawing.Size(35, 13);
            this.labelProductNameTwo.TabIndex = 11;
            this.labelProductNameTwo.Text = "label1";
            this.labelProductNameTwo.Visible = false;
            // 
            // labelProductPriceThree
            // 
            this.labelProductPriceThree.AutoSize = true;
            this.labelProductPriceThree.Location = new System.Drawing.Point(438, 298);
            this.labelProductPriceThree.Name = "labelProductPriceThree";
            this.labelProductPriceThree.Size = new System.Drawing.Size(35, 13);
            this.labelProductPriceThree.TabIndex = 14;
            this.labelProductPriceThree.Text = "label2";
            this.labelProductPriceThree.Visible = false;
            // 
            // labelProductNameThree
            // 
            this.labelProductNameThree.AutoSize = true;
            this.labelProductNameThree.Location = new System.Drawing.Point(438, 277);
            this.labelProductNameThree.Name = "labelProductNameThree";
            this.labelProductNameThree.Size = new System.Drawing.Size(35, 13);
            this.labelProductNameThree.TabIndex = 13;
            this.labelProductNameThree.Text = "label1";
            this.labelProductNameThree.Visible = false;
            // 
            // panelOthers
            // 
            this.panelOthers.Controls.Add(this.btnAddtoCartUpload);
            this.panelOthers.Controls.Add(this.tbitemprice);
            this.panelOthers.Controls.Add(this.tbitemname);
            this.panelOthers.Controls.Add(this.labelitemprice);
            this.panelOthers.Controls.Add(this.labelitemname);
            this.panelOthers.Controls.Add(this.gambarUpload);
            this.panelOthers.Controls.Add(this.btnUploadImage);
            this.panelOthers.Controls.Add(this.labelUploadImage);
            this.panelOthers.Enabled = false;
            this.panelOthers.Location = new System.Drawing.Point(199, 27);
            this.panelOthers.Name = "panelOthers";
            this.panelOthers.Size = new System.Drawing.Size(397, 438);
            this.panelOthers.TabIndex = 15;
            this.panelOthers.Visible = false;
            // 
            // labelUploadImage
            // 
            this.labelUploadImage.AutoSize = true;
            this.labelUploadImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUploadImage.Location = new System.Drawing.Point(34, 28);
            this.labelUploadImage.Name = "labelUploadImage";
            this.labelUploadImage.Size = new System.Drawing.Size(73, 13);
            this.labelUploadImage.TabIndex = 0;
            this.labelUploadImage.Text = "Upload Image";
            // 
            // btnUploadImage
            // 
            this.btnUploadImage.Location = new System.Drawing.Point(139, 21);
            this.btnUploadImage.Name = "btnUploadImage";
            this.btnUploadImage.Size = new System.Drawing.Size(147, 26);
            this.btnUploadImage.TabIndex = 1;
            this.btnUploadImage.Text = "Upload";
            this.btnUploadImage.UseVisualStyleBackColor = true;
            this.btnUploadImage.Click += new System.EventHandler(this.btnUploadImage_Click);
            // 
            // gambarUpload
            // 
            this.gambarUpload.Location = new System.Drawing.Point(37, 53);
            this.gambarUpload.Name = "gambarUpload";
            this.gambarUpload.Size = new System.Drawing.Size(219, 271);
            this.gambarUpload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gambarUpload.TabIndex = 2;
            this.gambarUpload.TabStop = false;
            // 
            // labelitemname
            // 
            this.labelitemname.AutoSize = true;
            this.labelitemname.Location = new System.Drawing.Point(263, 67);
            this.labelitemname.Name = "labelitemname";
            this.labelitemname.Size = new System.Drawing.Size(64, 13);
            this.labelitemname.TabIndex = 3;
            this.labelitemname.Text = "Item Name: ";
            // 
            // labelitemprice
            // 
            this.labelitemprice.AutoSize = true;
            this.labelitemprice.Location = new System.Drawing.Point(262, 116);
            this.labelitemprice.Name = "labelitemprice";
            this.labelitemprice.Size = new System.Drawing.Size(60, 13);
            this.labelitemprice.TabIndex = 4;
            this.labelitemprice.Text = "Item Price: ";
            // 
            // tbitemname
            // 
            this.tbitemname.Enabled = false;
            this.tbitemname.Location = new System.Drawing.Point(266, 83);
            this.tbitemname.Name = "tbitemname";
            this.tbitemname.Size = new System.Drawing.Size(117, 20);
            this.tbitemname.TabIndex = 5;
            // 
            // tbitemprice
            // 
            this.tbitemprice.Enabled = false;
            this.tbitemprice.Location = new System.Drawing.Point(266, 132);
            this.tbitemprice.Name = "tbitemprice";
            this.tbitemprice.Size = new System.Drawing.Size(117, 20);
            this.tbitemprice.TabIndex = 6;
            // 
            // btnAddtoCartUpload
            // 
            this.btnAddtoCartUpload.Enabled = false;
            this.btnAddtoCartUpload.Location = new System.Drawing.Point(273, 300);
            this.btnAddtoCartUpload.Name = "btnAddtoCartUpload";
            this.btnAddtoCartUpload.Size = new System.Drawing.Size(110, 24);
            this.btnAddtoCartUpload.TabIndex = 7;
            this.btnAddtoCartUpload.Text = "Add To Cart";
            this.btnAddtoCartUpload.UseVisualStyleBackColor = true;
            this.btnAddtoCartUpload.Click += new System.EventHandler(this.btnAddtoCartUpload_Click);
            // 
            // btnAdd1
            // 
            this.btnAdd1.Location = new System.Drawing.Point(12, 320);
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(149, 25);
            this.btnAdd1.TabIndex = 16;
            this.btnAdd1.Text = "Add To Cart";
            this.btnAdd1.UseVisualStyleBackColor = true;
            this.btnAdd1.Visible = false;
            this.btnAdd1.Click += new System.EventHandler(this.btnAdd1_Click);
            // 
            // btnAdd2
            // 
            this.btnAdd2.Location = new System.Drawing.Point(228, 320);
            this.btnAdd2.Name = "btnAdd2";
            this.btnAdd2.Size = new System.Drawing.Size(149, 25);
            this.btnAdd2.TabIndex = 17;
            this.btnAdd2.Text = "Add To Cart";
            this.btnAdd2.UseVisualStyleBackColor = true;
            this.btnAdd2.Visible = false;
            this.btnAdd2.Click += new System.EventHandler(this.btnAdd2_Click);
            // 
            // btnAdd3
            // 
            this.btnAdd3.Location = new System.Drawing.Point(441, 320);
            this.btnAdd3.Name = "btnAdd3";
            this.btnAdd3.Size = new System.Drawing.Size(149, 25);
            this.btnAdd3.TabIndex = 18;
            this.btnAdd3.Text = "Add To Cart";
            this.btnAdd3.UseVisualStyleBackColor = true;
            this.btnAdd3.Visible = false;
            this.btnAdd3.Click += new System.EventHandler(this.btnAdd3_Click);
            // 
            // UNIQME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1165, 569);
            this.Controls.Add(this.btnAdd3);
            this.Controls.Add(this.btnAdd2);
            this.Controls.Add(this.btnAdd1);
            this.Controls.Add(this.panelOthers);
            this.Controls.Add(this.labelProductPriceThree);
            this.Controls.Add(this.labelProductNameThree);
            this.Controls.Add(this.labelProductPriceTwo);
            this.Controls.Add(this.labelProductNameTwo);
            this.Controls.Add(this.labelProductPriceOne);
            this.Controls.Add(this.labelProductNameOne);
            this.Controls.Add(this.gambarTiga);
            this.Controls.Add(this.gambarDua);
            this.Controls.Add(this.gambarSatu);
            this.Controls.Add(this.tbtotal);
            this.Controls.Add(this.tbsubtotal);
            this.Controls.Add(this.labeltotal);
            this.Controls.Add(this.labelsubtotal);
            this.Controls.Add(this.dataGridViewShoppingList);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "UNIQME";
            this.Text = "UNIQME";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShoppingList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambarSatu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambarDua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gambarTiga)).EndInit();
            this.panelOthers.ResumeLayout(false);
            this.panelOthers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gambarUpload)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridViewShoppingList;
        private System.Windows.Forms.Label labelsubtotal;
        private System.Windows.Forms.Label labeltotal;
        private System.Windows.Forms.TextBox tbsubtotal;
        private System.Windows.Forms.TextBox tbtotal;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewlToolStripMenuItem;
        private System.Windows.Forms.PictureBox gambarSatu;
        private System.Windows.Forms.PictureBox gambarDua;
        private System.Windows.Forms.PictureBox gambarTiga;
        private System.Windows.Forms.Label labelProductNameOne;
        private System.Windows.Forms.Label labelProductPriceOne;
        private System.Windows.Forms.Label labelProductPriceTwo;
        private System.Windows.Forms.Label labelProductNameTwo;
        private System.Windows.Forms.Label labelProductPriceThree;
        private System.Windows.Forms.Label labelProductNameThree;
        private System.Windows.Forms.Panel panelOthers;
        private System.Windows.Forms.TextBox tbitemname;
        private System.Windows.Forms.Label labelitemprice;
        private System.Windows.Forms.Label labelitemname;
        private System.Windows.Forms.PictureBox gambarUpload;
        private System.Windows.Forms.Button btnUploadImage;
        private System.Windows.Forms.Label labelUploadImage;
        private System.Windows.Forms.Button btnAddtoCartUpload;
        private System.Windows.Forms.TextBox tbitemprice;
        private System.Windows.Forms.Button btnAdd1;
        private System.Windows.Forms.Button btnAdd2;
        private System.Windows.Forms.Button btnAdd3;
    }
}

