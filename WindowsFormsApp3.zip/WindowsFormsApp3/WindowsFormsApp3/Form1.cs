﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            int jmlahtbtn = Convert.ToInt32(tbTotalBtn.Text);
            int x = 50;
            int y = 200;
            for (int i = 1; i <= Convert.ToInt32(tbTotalBtn.Text); i++)
            {
                Button buttonBaru = new Button();
                buttonBaru.Text = i.ToString();
                buttonBaru.Size = new Size(50, 36);
                buttonBaru.Click += new EventHandler(buttonClicksEvent);
                if (i  % 2 == 0)
                {
                    buttonBaru.Tag = "Even";
                }
                else
                {
                    buttonBaru.Tag = "Odd";
                }
                buttonBaru.Name = i.ToString();
                buttonBaru.BackColor = Color.Aqua;
                buttonBaru.Location = new Point(x, y);
                x += 50;
                this.Controls.Add(buttonBaru);
                if (i % 5 == 0)
                {
                    x= 50;
                    y += 50;
                }
                


            }


        }
        public void buttonClicksEvent(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            MessageBox.Show(btn.Text + " is " + btn.Tag);
        }
    }
    
}
