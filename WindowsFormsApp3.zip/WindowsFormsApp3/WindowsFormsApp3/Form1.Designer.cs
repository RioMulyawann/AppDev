﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelJumlahBtn = new System.Windows.Forms.Label();
            this.tbTotalBtn = new System.Windows.Forms.TextBox();
            this.btnCreate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelJumlahBtn
            // 
            this.labelJumlahBtn.AutoSize = true;
            this.labelJumlahBtn.Location = new System.Drawing.Point(240, 166);
            this.labelJumlahBtn.Name = "labelJumlahBtn";
            this.labelJumlahBtn.Size = new System.Drawing.Size(161, 25);
            this.labelJumlahBtn.TabIndex = 1;
            this.labelJumlahBtn.Text = "Jumlah Button: ";
            // 
            // tbTotalBtn
            // 
            this.tbTotalBtn.Location = new System.Drawing.Point(407, 163);
            this.tbTotalBtn.Name = "tbTotalBtn";
            this.tbTotalBtn.Size = new System.Drawing.Size(149, 31);
            this.tbTotalBtn.TabIndex = 2;
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(587, 160);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(135, 36);
            this.btnCreate.TabIndex = 3;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1789, 874);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.tbTotalBtn);
            this.Controls.Add(this.labelJumlahBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelJumlahBtn;
        private System.Windows.Forms.TextBox tbTotalBtn;
        private System.Windows.Forms.Button btnCreate;
    }
}

