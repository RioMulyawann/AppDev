﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        int posisi = 0;
        Random rnd = new Random();
        bool checker = false;
        int posisilogo = 0;
        string[] daftarlogo = { "logo1", "logo2", "logo3", "logo4", "logo5", "logo6", "logo7", "logo8", "logo9", "logo10" };
        string[] daftarmenu = { "food1", "food2", "food3", "food4", "food5", "food6", "food7", "food8", "food9", "food10", "food11", "food12", "food13", "food14", "food15", "food16", "food17", "food18", "food19", "food20" };
        bool logo = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnTampil_Click(object sender, EventArgs e)
        {
            //cara ambil photo dari local files
            int random= rnd.Next(0, daftarlogo.Count());

            //string filename = "Y:\\" + daftarlogo[random] + ".jpeg";
            //pictureBox1.Image = new Bitmap(filename);
            string filenameo = "Y:\\" + daftarmenu[0] + ".jpeg";
            pictureBox1.Image = new Bitmap(filenameo);
            checker = true;

            // cara tampilkan foto dari resources
            // pictureBox1.Image = WindowsFormsApp3.Properties.Resources.(namafile di resources);


        }

        private void btnNext_Click(object sender, EventArgs e)
        {

            if (posisi != 19 && checker == true && logo == false)
            {
                string filename = "Y:\\" + daftarmenu[posisi+1] + ".jpeg";
                 pictureBox1.Image = new Bitmap(filename);
                posisi++;
            }
            if (posisilogo != 9 && checker == true && logo == true)
            {
                string filenames = "Y:\\" + daftarlogo[posisilogo + 1] + ".jpeg";
                pictureBox1.Image = new Bitmap(filenames);
                posisilogo++;
            }
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            if (posisi != 0 && checker == true && logo == false)
            {
                string filename = "Y:\\" + daftarmenu[posisi - 1] + ".jpeg";
                pictureBox1.Image = new Bitmap(filename);
                posisi--;
            }
            if (posisilogo != 0 && checker == true && logo == true)
            {
                string filenames = "Y:\\" + daftarlogo[posisilogo - 1] + ".jpeg";
                pictureBox1.Image = new Bitmap(filenames);
                posisilogo--;
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            if (logo == false&& checker==true)
            {
                logo = true;
                posisi = 0;
                posisilogo = 0;
                string filename = "Y:\\" + daftarlogo[0] + ".jpeg";
                pictureBox1.Image = new Bitmap(filename);
            }
            else if (logo == true && checker == true)
            {
                logo = false;
                posisi = 0;
                posisilogo = 0;
                string filenameo = "Y:\\" + daftarmenu[0] + ".jpeg";
                pictureBox1.Image = new Bitmap(filenameo);
            }
           
            
            
        }
    }
}
