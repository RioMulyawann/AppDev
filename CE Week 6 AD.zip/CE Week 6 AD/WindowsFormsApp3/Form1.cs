﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        FormKedua  form2;
        DataTable dt;
        FormRemove form3;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Nama Produk");
            dt.Columns.Add("Harga");
            dt.Rows.Add("001", "Nasi Goyeng", "25000");
            dt.Rows.Add("002", "Ayang Geprek", "28000");
            dt.Rows.Add("003", "Nasi Ayang Sayur", "25000");
            dt.Rows.Add("004", "Nasi Ayang Spesial", "28000");
            dataGridViewProducts.DataSource = dt;
        }

        private void btnForm2_Click(object sender, EventArgs e)
        {
            form2 = new FormKedua(this);
            
            form2.ShowDialog();

        }
        public void kirimdata(string _ID, string _Nama, string _Harga)
        {
            dt.Rows.Add(_ID, _Nama, _Harga);


        }

        private void btnRemove_Click(object sender, EventArgs e)
        { 

            form3 = new FormRemove(this);
            form3.ambildataform1(dt);
            form3.ShowDialog();
        }
        public void removeID(string _ID)
        {
            int index = 0;
            foreach (DataRow row in dt.Rows)
            {
                if (row[0].ToString() == _ID)
                {
                    index = dt.Rows.IndexOf(row);
                }
            }
                dt.Rows.RemoveAt(index);
            
        }
    }
}
