﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp3
{
    public partial class FormKedua : Form
    {
        Form1 form1;
        public FormKedua(Form _form)
        {
            InitializeComponent();
            form1 = (Form1) _form;
        }

        private void FormKedua_Load(object sender, EventArgs e)
        {

        }
        

        private void btnRandom_Click(object sender, EventArgs e)
        {
           
        }

        private void btnAddProduk_Click(object sender, EventArgs e)
        {
            
            
            form1.kirimdata(tbIDProduk.Text, tbNamaProduk.Text, tbHarga.Text);
            this.Close();
        }
    }
}
