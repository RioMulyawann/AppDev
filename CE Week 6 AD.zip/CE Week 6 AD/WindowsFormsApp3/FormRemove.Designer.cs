﻿namespace WindowsFormsApp3
{
    partial class FormRemove
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRemoveProduk = new System.Windows.Forms.Button();
            this.lblHarga = new System.Windows.Forms.Label();
            this.lblNamaProduk = new System.Windows.Forms.Label();
            this.lblProdukID = new System.Windows.Forms.Label();
            this.tbID = new System.Windows.Forms.TextBox();
            this.tbHarga = new System.Windows.Forms.TextBox();
            this.cboxNama = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnRemoveProduk
            // 
            this.btnRemoveProduk.Location = new System.Drawing.Point(643, 449);
            this.btnRemoveProduk.Name = "btnRemoveProduk";
            this.btnRemoveProduk.Size = new System.Drawing.Size(183, 42);
            this.btnRemoveProduk.TabIndex = 13;
            this.btnRemoveProduk.Text = "Remove";
            this.btnRemoveProduk.UseVisualStyleBackColor = true;
            this.btnRemoveProduk.Click += new System.EventHandler(this.btnRemoveProduk_Click);
            // 
            // lblHarga
            // 
            this.lblHarga.AutoSize = true;
            this.lblHarga.Location = new System.Drawing.Point(419, 374);
            this.lblHarga.Name = "lblHarga";
            this.lblHarga.Size = new System.Drawing.Size(82, 25);
            this.lblHarga.TabIndex = 12;
            this.lblHarga.Text = "Harga: ";
            // 
            // lblNamaProduk
            // 
            this.lblNamaProduk.AutoSize = true;
            this.lblNamaProduk.Location = new System.Drawing.Point(347, 256);
            this.lblNamaProduk.Name = "lblNamaProduk";
            this.lblNamaProduk.Size = new System.Drawing.Size(154, 25);
            this.lblNamaProduk.TabIndex = 11;
            this.lblNamaProduk.Text = "Nama Produk: ";
            // 
            // lblProdukID
            // 
            this.lblProdukID.AutoSize = true;
            this.lblProdukID.Location = new System.Drawing.Point(383, 313);
            this.lblProdukID.Name = "lblProdukID";
            this.lblProdukID.Size = new System.Drawing.Size(118, 25);
            this.lblProdukID.TabIndex = 10;
            this.lblProdukID.Text = "ID Produk: ";
            // 
            // tbID
            // 
            this.tbID.Enabled = false;
            this.tbID.Location = new System.Drawing.Point(524, 307);
            this.tbID.Name = "tbID";
            this.tbID.Size = new System.Drawing.Size(402, 31);
            this.tbID.TabIndex = 9;
            // 
            // tbHarga
            // 
            this.tbHarga.Enabled = false;
            this.tbHarga.Location = new System.Drawing.Point(524, 368);
            this.tbHarga.Name = "tbHarga";
            this.tbHarga.Size = new System.Drawing.Size(402, 31);
            this.tbHarga.TabIndex = 8;
            // 
            // cboxNama
            // 
            this.cboxNama.FormattingEnabled = true;
            this.cboxNama.Location = new System.Drawing.Point(524, 248);
            this.cboxNama.Name = "cboxNama";
            this.cboxNama.Size = new System.Drawing.Size(401, 33);
            this.cboxNama.TabIndex = 14;
            this.cboxNama.SelectionChangeCommitted += new System.EventHandler(this.cboxNama_SelectionChangeCommitted);
            // 
            // FormRemove
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1273, 738);
            this.Controls.Add(this.cboxNama);
            this.Controls.Add(this.btnRemoveProduk);
            this.Controls.Add(this.lblHarga);
            this.Controls.Add(this.lblNamaProduk);
            this.Controls.Add(this.lblProdukID);
            this.Controls.Add(this.tbID);
            this.Controls.Add(this.tbHarga);
            this.Name = "FormRemove";
            this.Text = "FormRemove";
            this.Load += new System.EventHandler(this.FormRemove_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRemoveProduk;
        private System.Windows.Forms.Label lblHarga;
        private System.Windows.Forms.Label lblNamaProduk;
        private System.Windows.Forms.Label lblProdukID;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.TextBox tbHarga;
        private System.Windows.Forms.ComboBox cboxNama;
    }
}