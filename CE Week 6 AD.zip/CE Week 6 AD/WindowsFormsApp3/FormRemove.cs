﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class FormRemove : Form
    {
        Form1 form1;
        DataTable produks;
        public FormRemove(Form1 _form)
        {
            InitializeComponent();
            form1 = (Form1) _form;
        }
        public void ambildataform1(DataTable _dt)
        {
            
            produks = _dt;

        }

        private void FormRemove_Load(object sender, EventArgs e)
        {


            cboxNama.DataSource = produks;
            cboxNama.DisplayMember = "Nama Produk";
            cboxNama.SelectedIndex = -1;
            cboxNama.ValueMember = "ID";

            
        }

        private void btnRemoveProduk_Click(object sender, EventArgs e)
        {
            form1.removeID(cboxNama.SelectedValue.ToString());
            this.Close();
        }

        private void cboxNama_SelectionChangeCommitted(object sender, EventArgs e)
        {
            foreach (DataRow row in produks.Rows)
            {
                if (row[0].ToString() == cboxNama.SelectedValue.ToString())
                {
                    tbHarga.Text = row[2].ToString();
                    tbID.Text = row[0].ToString();
                }
            }
        }
    }
}
