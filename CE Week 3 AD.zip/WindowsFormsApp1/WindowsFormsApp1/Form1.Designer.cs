﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listbox_favfood = new System.Windows.Forms.ListBox();
            this.comboBox_destination = new System.Windows.Forms.ComboBox();
            this.button_add = new System.Windows.Forms.Button();
            this.label_namaMakanan = new System.Windows.Forms.Label();
            this.textBox_makanan = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox_destination = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_pilih = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listbox_favfood
            // 
            this.listbox_favfood.FormattingEnabled = true;
            this.listbox_favfood.Location = new System.Drawing.Point(131, 77);
            this.listbox_favfood.Name = "listbox_favfood";
            this.listbox_favfood.Size = new System.Drawing.Size(113, 160);
            this.listbox_favfood.TabIndex = 0;
            this.listbox_favfood.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // comboBox_destination
            // 
            this.comboBox_destination.FormattingEnabled = true;
            this.comboBox_destination.Location = new System.Drawing.Point(268, 77);
            this.comboBox_destination.Name = "comboBox_destination";
            this.comboBox_destination.Size = new System.Drawing.Size(117, 21);
            this.comboBox_destination.TabIndex = 1;
            this.comboBox_destination.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(202, 303);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(75, 23);
            this.button_add.TabIndex = 2;
            this.button_add.Text = "Add";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // label_namaMakanan
            // 
            this.label_namaMakanan.AutoSize = true;
            this.label_namaMakanan.Location = new System.Drawing.Point(79, 248);
            this.label_namaMakanan.Name = "label_namaMakanan";
            this.label_namaMakanan.Size = new System.Drawing.Size(83, 13);
            this.label_namaMakanan.TabIndex = 3;
            this.label_namaMakanan.Text = "Nama Makanan";
            // 
            // textBox_makanan
            // 
            this.textBox_makanan.AccessibleName = "";
            this.textBox_makanan.Location = new System.Drawing.Point(82, 274);
            this.textBox_makanan.Name = "textBox_makanan";
            this.textBox_makanan.Size = new System.Drawing.Size(100, 20);
            this.textBox_makanan.TabIndex = 4;
            this.textBox_makanan.Tag = "";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(26, 12);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // textBox_destination
            // 
            this.textBox_destination.Location = new System.Drawing.Point(82, 329);
            this.textBox_destination.Name = "textBox_destination";
            this.textBox_destination.Size = new System.Drawing.Size(100, 20);
            this.textBox_destination.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 303);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Tempat Makanan";
            // 
            // button_clear
            // 
            this.button_clear.Location = new System.Drawing.Point(268, 142);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(75, 23);
            this.button_clear.TabIndex = 9;
            this.button_clear.Text = "Clear";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_delete
            // 
            this.button_delete.Location = new System.Drawing.Point(268, 113);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(75, 23);
            this.button_delete.TabIndex = 10;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_pilih
            // 
            this.button_pilih.Location = new System.Drawing.Point(268, 171);
            this.button_pilih.Name = "button_pilih";
            this.button_pilih.Size = new System.Drawing.Size(75, 23);
            this.button_pilih.TabIndex = 11;
            this.button_pilih.Text = "Pilih";
            this.button_pilih.UseVisualStyleBackColor = true;
            this.button_pilih.Click += new System.EventHandler(this.button_pilih_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_pilih);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.textBox_destination);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBox_makanan);
            this.Controls.Add(this.label_namaMakanan);
            this.Controls.Add(this.button_add);
            this.Controls.Add(this.comboBox_destination);
            this.Controls.Add(this.listbox_favfood);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listbox_favfood;
        private System.Windows.Forms.ComboBox comboBox_destination;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Label label_namaMakanan;
        private System.Windows.Forms.TextBox textBox_makanan;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox_destination;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_pilih;
    }
}

