﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        DataTable dtmakan = new DataTable();


        public Form1()
        {
            
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_add_Click(object sender, EventArgs e)
        {
            listbox_favfood.Items.Add(textBox_makanan.Text);
            comboBox_destination.Items.Add(textBox_destination.Text);
            textBox_destination.Clear();
            textBox_makanan.Clear();



        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            listbox_favfood.Items.Clear();
            comboBox_destination.Items.Clear();


        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            listbox_favfood.Items.Remove(listbox_favfood.Text);
            comboBox_destination.Items.Remove(comboBox_destination.SelectedItem);
        }

        private void button_pilih_Click(object sender, EventArgs e)
        {
            int indexdatadipilih = listbox_favfood.SelectedIndex;

            MessageBox.Show($"{dtmakan.Rows[indexdatadipilih][0]} - {dtmakan.Rows[indexdatadipilih][1]}  {String.Format("{0:C0}", Convert.ToInt32(dtmakan.Rows[indexdatadipilih][2]))}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            dtmakan.Columns.Add("ID Makanan");
            dtmakan.Columns.Add("Nama makanan");
            dtmakan.Columns.Add("Harga Makanan");
            dtmakan.Rows.Add("A001", "Ayam Goreng","50000");
            dtmakan.Rows.Add("A002", "Mie HK", "60000");
            dtmakan.Rows.Add("A003", "Xiobak", "55000");
            dtmakan.Rows.Add("A004", "Pisang Goreng", "20000");
            dtmakan.Rows.Add("A005", "Kwetiau", "32000");
            listbox_favfood.DataSource=dtmakan;
            listbox_favfood.DisplayMember = "Nama Makanan";
            listbox_favfood.ValueMember = "Harga Makanan";
        }
    }
}
