﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{

    // 0706022310046 Jefferson WL
    public partial class Form1 : Form
    { 

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string sqlQuery;
        string sqlQuery2;
        string sqlQuery3;
        string date;
        string temp;
        DataTable dtteam;
        DataTable dtteam1;
        DataTable dtteam2;
        DataTable player;
        DataTable dtdate;
        DataTable dgv;
        DataTable teamid;
        DataTable playerid;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtteam = new DataTable();
            sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
            sqlConnect.Open();
            sqlQuery = "SELECT team_name FROM team";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteam);
            cbxTeamHome.DataSource = dtteam;
            cbxTeamHome.DisplayMember = "team_name";

            dtteam1 = new DataTable();
            sqlDataAdapter.Fill(dtteam1);
            cbxTeamAway.DataSource = dtteam1;
            cbxTeamAway.DisplayMember = "team_name";
            sqlConnect.Close();
            cbxTeamHome.SelectedIndex = -1;
            cbxTeamAway.SelectedIndex = -1;

            dgv = new DataTable();
            dgv.Columns.Add("Minute");
            dgv.Columns.Add("Team");
            dgv.Columns.Add("Player");
            dgv.Columns.Add("Type");
            dgv.Columns.Add("Team_ID");

            cbxType.Items.Add("GO");
            cbxType.Items.Add("GP");
            cbxType.Items.Add("GW");
            cbxType.Items.Add("CR");
            cbxType.Items.Add("CY");
            cbxType.Items.Add("PM");


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            dgv.Rows.Add(tbxMinute.Text, cbxTeam.Text, cbxPlayer.Text, cbxType.Text);
            dgvPremierLeague.DataSource = dgv;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            dgv.Rows.RemoveAt(dgvPremierLeague.CurrentCell.RowIndex);
            dgvPremierLeague.DataSource = dgv;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            foreach (DataRow data in dgv.Rows)
            {
                try
                {
                    teamid = new DataTable();
                    string sqlQuery4 = $"Select team_id FROM team WHERE team_name = '{data[1].ToString()}';";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery4, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(teamid);
                    sqlConnect.Close();

                    playerid = new DataTable();
                    string sqlQuery5 = $"Select player_id FROM player WHERE player_name = '{data[2].ToString()}';";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery5, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(playerid);
                    sqlConnect.Close();
                    MessageBox.Show($"VALUES ('{tbxMatchID.Text}', '{data[0]}', '{teamid.Rows[0][0]}', '{playerid.Rows[0][0]}', '{data[3]}', '0')");

                   //sqlQuery3 = $"INSERT INTO dmatch ('match_id', 'minute', 'team_id', 'player_id', 'type', 'delete') VALUES('{tbxMatchID.Text}', '{data[0]}', '{teamid.Rows[0][0]}', '{playerid.Rows[0][0]}', '{data[3]}', '0');";
                    sqlQuery3 = $"INSERT INTO dmatch VALUES('{tbxMatchID.Text}', '{data[0]}', '{teamid.Rows[0][0]}', '{playerid.Rows[0][0]}', '{data[3]}', '0');";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery3, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void cbxTeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxTeam.Items.Clear();
            if (cbxTeamHome.SelectedIndex == cbxTeamAway.SelectedIndex)
            {
                MessageBox.Show("Silahkan Memilih Team Lainnya");
            }
            else
            {
                cbxTeam.Items.Add(cbxTeamHome.Text);
                cbxTeam.Items.Add(cbxTeamAway.Text);
            }
        }

        private void cbxTeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxTeam.Items.Clear();
            if (cbxTeamAway.SelectedIndex == cbxTeamHome.SelectedIndex)
            {
                MessageBox.Show("Silahkan Memilih Team Lainnya");
            }
            else
            {
                cbxTeam.Items.Add(cbxTeamHome.Text);
                cbxTeam.Items.Add(cbxTeamAway.Text);
            }
        }
        private void cbxTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            player = new DataTable();
            sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
            sqlConnect.Open();
            sqlQuery = $"SELECT player.player_name FROM player, team WHERE player.team_id = team.team_id and team.team_name = '{cbxTeam.Text}' ;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(player);
            cbxPlayer.DataSource = player;
            cbxPlayer.DisplayMember = "player_name";
            sqlConnect.Close();
            cbxPlayer.SelectedIndex = -1;
        }
        private void dateTimePickerMatch_ValueChanged(object sender, EventArgs e)
        {
            dtdate = new DataTable();
            //date = dateTimePickerMatch.Value.ToString("yyyy-MM-DD");
            tbxMatchID.Text = dateTimePickerMatch.Value.Year.ToString();
            try
            {
                sqlQuery2 = $"SELECT COUNT(match_id) FROM `match` WHERE match_id LIKE '{dateTimePickerMatch.Value.Year}%'";
                sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                sqlConnect.Open();
                sqlCommand = new MySqlCommand(sqlQuery2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtdate);
                int total = Convert.ToInt32(dtdate.Rows[0][0]) + 1;
                if(total < 0)
                {
                    temp = $"{dateTimePickerMatch.Value.Year}00{total}";

                }
                else if (total < 100)
                {
                    temp = $"{dateTimePickerMatch.Value.Year}0{total}";

                }
                else
                {
                    temp = $"{dateTimePickerMatch.Value.Year}{total}";

                }
                tbxMatchID.Text = temp;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void dgvPremierLeague_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
