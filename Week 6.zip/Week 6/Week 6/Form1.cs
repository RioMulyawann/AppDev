﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_6
{
    public partial class Form1 : Form
    {
        List<Button> buttonlist = new List<Button>();
        List <Label> labelScore = new List<Label>();
        
        public Form1()
        {
            InitializeComponent();
         
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            int size = 0;
            size = Convert.ToInt32(tbInput.Text);
            


            if (size % 2 == 0 || size < 3 || size > 9)
            {
                MessageBox.Show("Input Error");
            }
            else
            {
                panelMainMenu.Visible = false;
                int jmlahtbtn = size * size;
                int x = 50;
                int y = 50;

                Label red = new Label();
                red.Location = new Point(400, 200);
                red.Text = "red";
                this.Controls.Add(red);
                
                

                Label blue = new Label();
                blue.Location = new Point(550, 200);
                blue.Text = "blue";
                this.Controls.Add(blue);
                for (int i = 1; i <= jmlahtbtn; i++)
                {
                    Button buttonBaru = new Button();
                    buttonBaru.Size = new Size(50, 50);
                    buttonBaru.Click += new EventHandler(buttonClicksEvent);
                    buttonBaru.Name = i.ToString();
                    buttonBaru.BackColor = Color.Gray;
                    buttonBaru.Location = new Point(x, y);
                    buttonBaru.Tag = "Gray";
                    x += 50;
                    this.Controls.Add(buttonBaru);
                    if (i % size == 0)
                    {
                        x = 50;
                        y += 50;
                    }
                    buttonlist.Add(buttonBaru);
                }
            }


            


        }
        public void buttonClicksEvent(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Point LocationBtn = btn.Location;
            int xAxis = LocationBtn.X;
            int yAxis = LocationBtn.Y;

            //if (btn.BackColor == Color.Gray)
            //{
            //    btn.BackColor = Color.Red;
            //}
            //else if (btn.BackColor == Color.Red)
            //{
            //    btn.BackColor = Color.Blue;
            //}
            //else if (btn.BackColor == Color.Blue)
            //{
            //    btn.BackColor = Color.Red;
            //}
            for (int i = 0; i < buttonlist.Count; i++)
            {
                if (buttonlist[i].Location.X == xAxis && buttonlist[i].Location.Y == yAxis - 50 && buttonlist[i].Tag != "Gray")
                {
                    if (buttonlist[i].Tag == "Red")
                    {
                        buttonlist[i].BackColor = Color.Blue;
                        buttonlist[i].Tag = "Blue";
                    }
                    else if (buttonlist[i].Tag == "Blue")
                    {
                        buttonlist[i].BackColor = Color.Red;
                        buttonlist[i].Tag = "Red";
                    }
                }

                if (buttonlist[i].Location.X == xAxis && buttonlist[i].Location.Y == yAxis + 50 && buttonlist[i].Tag != "Gray")
                {
                    if (buttonlist[i].Tag == "Red")
                    {
                        buttonlist[i].BackColor = Color.Blue;
                        buttonlist[i].Tag = "Blue";
                    }
                    else if (buttonlist[i].Tag == "Blue")
                    {
                        buttonlist[i].BackColor = Color.Red;
                        buttonlist[i].Tag = "Red";
                    }
                }

                if (buttonlist[i].Location.X == xAxis - 50 && buttonlist[i].Location.Y == yAxis && buttonlist[i].Tag != "Gray")
                {
                    if (buttonlist[i].Tag == "Red")
                    {
                        buttonlist[i].BackColor = Color.Blue;
                        buttonlist[i].Tag = "Blue";
                    }
                    else if (buttonlist[i].Tag == "Blue")
                    {
                        buttonlist[i].BackColor = Color.Red;
                        buttonlist[i].Tag = "Red";
                    }
                }

                if (buttonlist[i].Location.X == xAxis + 50 && buttonlist[i].Location.Y == yAxis && buttonlist[i].Tag != "Gray")
                {
                    if (buttonlist[i].Tag == "Red")
                    {
                        buttonlist[i].BackColor = Color.Blue;
                        buttonlist[i].Tag = "Blue";
                    }
                    else if (buttonlist[i].Tag == "Blue")
                    {
                        buttonlist[i].BackColor = Color.Red;
                        buttonlist[i].Tag = "Red";
                    }
                }
                
            }
            if (btn.Tag == "Gray")
            {
                btn.BackColor = Color.Red;
                btn.Tag = "Red";
            }
            else if (btn.Tag == "Red")
            {
                btn.BackColor = Color.Blue;
                btn.Tag = "Blue";
            }

            int jmlahred = 0;
            int jmlahblue = 0;

            foreach(Button button in buttonlist)
            {
                if (button.Tag == "Red")
                {
                    jmlahred++;
                }
                if (button.Tag == "Blue")
                {
                    jmlahblue++;
                }

            }
            //labelScore[0].Text = jmlahred.ToString();
            //labelScore[1].Text = jmlahblue.ToString();

            //if (labelScore[0].Text == Convert.ToString(buttonlist.Count))
            //{
            //    MessageBox.Show("You Win!");
            //}
            //else if (labelScore[1].Text == Convert.ToString(buttonlist.Count))
            //{
            //    MessageBox.Show("You Win!");
            //}
            //int size = Convert.ToInt16(btn.Tag);
            //if (buttonlist[abc].BackColor == Color.Gray)
            //{
            //    btn.BackColor = Color.Red;
            //}
            //else if (buttonlist[abc].BackColor == Color.Red)
            //{
            //    btn.BackColor = Color.Blue;
            //}
            //else if (buttonlist[abc].BackColor == Color.Blue)
            //{
            //    btn.BackColor = Color.Red;
            //}

            //if (Convert.ToInt16(btn.Name) < 5)
            //{
            //    //bawah
            //    if (buttonlist[abc + size].BackColor == Color.Blue )
            //    {
            //        buttonlist[abc + size].BackColor = Color.Red;

            //    }
            //    else if (buttonlist[abc + size].BackColor == Color.Red)
            //    {
            //        buttonlist[abc + size].BackColor = Color.Blue;
            //    }

            //    // not kanan
            //    if (Convert.ToInt16(btn.Name) % size != 0)
            //    {
            //        if (buttonlist[abc + 1].BackColor == Color.Blue)
            //        {
            //            buttonlist[abc + 1].BackColor = Color.Red;

            //        }
            //        else if (buttonlist[abc + 1].BackColor == Color.Red)
            //        {
            //            buttonlist[abc + 1].BackColor = Color.Blue;
            //        }
            //    }

            //    // not kiri
            //    if (Convert.ToInt16(btn.Name) % size != 1)
            //    {
            //        if (buttonlist[abc - 1].BackColor == Color.Blue)
            //        {
            //            buttonlist[abc - 1].BackColor = Color.Red;

            //        }
            //        else if (buttonlist[abc - 1].BackColor == Color.Red)
            //        {
            //            buttonlist[abc - 1].BackColor = Color.Blue;
            //        }
            //    }

            //    // atas
            //    if (Convert.ToInt16(btn.Name) > size * (size - 1))
            //    {
            //        if (buttonlist[abc - size].BackColor == Color.Blue)
            //        {
            //            buttonlist[abc - size].BackColor = Color.Red;

            //        }
            //        else if (buttonlist[abc - size].BackColor == Color.Red)
            //        {
            //            buttonlist[abc - size].BackColor = Color.Blue;
            //        }
            //    }
            //}

            //if (Convert.ToInt16(btn.Name) % size != 0)
            //{
            //    if (buttonlist[abc + 1].BackColor == Color.Blue)
            //    {
            //        buttonlist[abc + 1].BackColor = Color.Red;

            //    }
            //    else if (buttonlist[abc + 1].BackColor == Color.Red)
            //    {
            //        buttonlist[abc + 1].BackColor = Color.Blue;
            //    }
            //}

            //if (Convert.ToInt16(btn.Name) % size != 1)
            //{
            //    if (buttonlist[abc -1 ].BackColor == Color.Blue)
            //    {
            //        buttonlist[abc - 1].BackColor = Color.Red;

            //    }
            //    else if (buttonlist[abc - 1].BackColor == Color.Red)
            //    {
            //        buttonlist[abc - 1].BackColor = Color.Blue;
            //    }
            //}

            //if (Convert.ToInt16(btn.Name) > size *(size - 1))
            //{
            //    if (buttonlist[abc - size].BackColor == Color.Blue)
            //    {
            //        buttonlist[abc - size].BackColor = Color.Red;

            //    }
            //    else if (buttonlist[abc - size].BackColor == Color.Red)
            //    {
            //        buttonlist[abc - size].BackColor = Color.Blue;
            //    }
            //}





            //    if (abc < size - 1 && buttonlist[abc + 1].BackColor == Color.Blue || buttonlist[abc + 1].BackColor != Color.Gray)
            //{
            //    buttonlist[abc + 1].BackColor = Color.Red;
            //}
            //if (abc > 1 && buttonlist[abc - 1].BackColor == Color.Blue || buttonlist[abc - 1].BackColor != Color.Gray)
            //{
            //    buttonlist[abc + -1].BackColor = Color.Red;
            //}
            //if (abc < ((size * size) - size) && buttonlist[abc + size].BackColor == Color.Blue || buttonlist[abc + size].BackColor != Color.Gray)
            //{
            //    buttonlist[abc + size].BackColor = Color.Red;
            //}
            //if (abc > size && buttonlist[abc - size].BackColor == Color.Blue || buttonlist[abc - size].BackColor != Color.Gray)
            //{
            //    buttonlist[abc - size].BackColor = Color.Red;
            //}



            //if (abc < size - 1 && buttonlist[abc + 1].BackColor == Color.Red || buttonlist[abc + 1].BackColor != Color.Gray)
            //{
            //    buttonlist[abc + 1].BackColor = Color.Blue;
            //}
            //if (abc > 1 && buttonlist[abc - 1].BackColor == Color.Red || buttonlist[abc - 1].BackColor != Color.Gray)
            //{
            //    buttonlist[abc + -1].BackColor = Color.Blue;
            //}
            //if (abc < ((size * size) - size) && buttonlist[abc + size].BackColor == Color.Red || buttonlist[abc + size].BackColor != Color.Gray)
            //{
            //    buttonlist[abc + size].BackColor = Color.Blue;
            //}
            //if (abc > size && buttonlist[abc - size].BackColor == Color.Red || buttonlist[abc - size].BackColor != Color.Gray)
            //{
            //    buttonlist[abc - size].BackColor = Color.Blue;
            //}
        }
    }
}
