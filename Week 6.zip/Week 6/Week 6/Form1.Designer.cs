﻿namespace Week_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbInput = new System.Windows.Forms.TextBox();
            this.lblInput = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.panelMainMenu = new System.Windows.Forms.Panel();
            this.panelMainMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbInput
            // 
            this.tbInput.Location = new System.Drawing.Point(277, 155);
            this.tbInput.Name = "tbInput";
            this.tbInput.Size = new System.Drawing.Size(298, 31);
            this.tbInput.TabIndex = 0;
            // 
            // lblInput
            // 
            this.lblInput.AutoSize = true;
            this.lblInput.Location = new System.Drawing.Point(86, 158);
            this.lblInput.Name = "lblInput";
            this.lblInput.Size = new System.Drawing.Size(185, 25);
            this.lblInput.TabIndex = 1;
            this.lblInput.Text = "Input size puzzle: ";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(315, 210);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(224, 43);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // panelMainMenu
            // 
            this.panelMainMenu.Controls.Add(this.btnStart);
            this.panelMainMenu.Controls.Add(this.lblInput);
            this.panelMainMenu.Controls.Add(this.tbInput);
            this.panelMainMenu.Location = new System.Drawing.Point(749, 398);
            this.panelMainMenu.Name = "panelMainMenu";
            this.panelMainMenu.Size = new System.Drawing.Size(716, 380);
            this.panelMainMenu.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2224, 1198);
            this.Controls.Add(this.panelMainMenu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panelMainMenu.ResumeLayout(false);
            this.panelMainMenu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tbInput;
        private System.Windows.Forms.Label lblInput;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Panel panelMainMenu;
    }
}

