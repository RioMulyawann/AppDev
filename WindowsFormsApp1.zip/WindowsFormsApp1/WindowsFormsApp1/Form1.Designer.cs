﻿namespace WindowsFormsApp1
{
    partial class Form_PLData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbl_TimID = new System.Windows.Forms.Label();
            this.Lbl_NamaTim = new System.Windows.Forms.Label();
            this.Lbl_NamaStadium = new System.Windows.Forms.Label();
            this.Lbl_Kapasitas = new System.Windows.Forms.Label();
            this.Lbl_Kota = new System.Windows.Forms.Label();
            this.Lbl_NamaManager = new System.Windows.Forms.Label();
            this.Tbx_TimID = new System.Windows.Forms.TextBox();
            this.Tbx_NamaTim = new System.Windows.Forms.TextBox();
            this.Tbx_NamaStadium = new System.Windows.Forms.TextBox();
            this.Tbx_Kapasitas = new System.Windows.Forms.TextBox();
            this.Tbx_Kota = new System.Windows.Forms.TextBox();
            this.Tbx_NamaManager = new System.Windows.Forms.TextBox();
            this.Btn_Input = new System.Windows.Forms.Button();
            this.Dgv_PLData = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_PLData)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl_TimID
            // 
            this.Lbl_TimID.AutoSize = true;
            this.Lbl_TimID.Location = new System.Drawing.Point(52, 43);
            this.Lbl_TimID.Name = "Lbl_TimID";
            this.Lbl_TimID.Size = new System.Drawing.Size(73, 25);
            this.Lbl_TimID.TabIndex = 0;
            this.Lbl_TimID.Text = "Tim ID";
            // 
            // Lbl_NamaTim
            // 
            this.Lbl_NamaTim.AutoSize = true;
            this.Lbl_NamaTim.Location = new System.Drawing.Point(52, 80);
            this.Lbl_NamaTim.Name = "Lbl_NamaTim";
            this.Lbl_NamaTim.Size = new System.Drawing.Size(109, 25);
            this.Lbl_NamaTim.TabIndex = 1;
            this.Lbl_NamaTim.Text = "Nama Tim";
            // 
            // Lbl_NamaStadium
            // 
            this.Lbl_NamaStadium.AutoSize = true;
            this.Lbl_NamaStadium.Location = new System.Drawing.Point(52, 117);
            this.Lbl_NamaStadium.Name = "Lbl_NamaStadium";
            this.Lbl_NamaStadium.Size = new System.Drawing.Size(152, 25);
            this.Lbl_NamaStadium.TabIndex = 2;
            this.Lbl_NamaStadium.Text = "Nama Stadium";
            // 
            // Lbl_Kapasitas
            // 
            this.Lbl_Kapasitas.AutoSize = true;
            this.Lbl_Kapasitas.Location = new System.Drawing.Point(52, 154);
            this.Lbl_Kapasitas.Name = "Lbl_Kapasitas";
            this.Lbl_Kapasitas.Size = new System.Drawing.Size(107, 25);
            this.Lbl_Kapasitas.TabIndex = 3;
            this.Lbl_Kapasitas.Text = "Kapasitas";
            // 
            // Lbl_Kota
            // 
            this.Lbl_Kota.AutoSize = true;
            this.Lbl_Kota.Location = new System.Drawing.Point(52, 194);
            this.Lbl_Kota.Name = "Lbl_Kota";
            this.Lbl_Kota.Size = new System.Drawing.Size(56, 25);
            this.Lbl_Kota.TabIndex = 4;
            this.Lbl_Kota.Text = "Kota";
            // 
            // Lbl_NamaManager
            // 
            this.Lbl_NamaManager.AutoSize = true;
            this.Lbl_NamaManager.Location = new System.Drawing.Point(52, 231);
            this.Lbl_NamaManager.Name = "Lbl_NamaManager";
            this.Lbl_NamaManager.Size = new System.Drawing.Size(159, 25);
            this.Lbl_NamaManager.TabIndex = 5;
            this.Lbl_NamaManager.Text = "Nama Manager";
            // 
            // Tbx_TimID
            // 
            this.Tbx_TimID.Enabled = false;
            this.Tbx_TimID.Location = new System.Drawing.Point(221, 40);
            this.Tbx_TimID.Name = "Tbx_TimID";
            this.Tbx_TimID.Size = new System.Drawing.Size(237, 31);
            this.Tbx_TimID.TabIndex = 6;
            this.Tbx_TimID.TextChanged += new System.EventHandler(this.Tbx_TimID_TextChanged);
            // 
            // Tbx_NamaTim
            // 
            this.Tbx_NamaTim.Location = new System.Drawing.Point(221, 77);
            this.Tbx_NamaTim.Name = "Tbx_NamaTim";
            this.Tbx_NamaTim.Size = new System.Drawing.Size(237, 31);
            this.Tbx_NamaTim.TabIndex = 7;
            this.Tbx_NamaTim.TextChanged += new System.EventHandler(this.Tbx_NamaTim_TextChanged);
            // 
            // Tbx_NamaStadium
            // 
            this.Tbx_NamaStadium.Location = new System.Drawing.Point(221, 114);
            this.Tbx_NamaStadium.Name = "Tbx_NamaStadium";
            this.Tbx_NamaStadium.Size = new System.Drawing.Size(237, 31);
            this.Tbx_NamaStadium.TabIndex = 8;
            // 
            // Tbx_Kapasitas
            // 
            this.Tbx_Kapasitas.Location = new System.Drawing.Point(221, 151);
            this.Tbx_Kapasitas.Name = "Tbx_Kapasitas";
            this.Tbx_Kapasitas.Size = new System.Drawing.Size(237, 31);
            this.Tbx_Kapasitas.TabIndex = 9;
            // 
            // Tbx_Kota
            // 
            this.Tbx_Kota.Location = new System.Drawing.Point(221, 188);
            this.Tbx_Kota.Name = "Tbx_Kota";
            this.Tbx_Kota.Size = new System.Drawing.Size(237, 31);
            this.Tbx_Kota.TabIndex = 10;
            // 
            // Tbx_NamaManager
            // 
            this.Tbx_NamaManager.Location = new System.Drawing.Point(221, 228);
            this.Tbx_NamaManager.Name = "Tbx_NamaManager";
            this.Tbx_NamaManager.Size = new System.Drawing.Size(237, 31);
            this.Tbx_NamaManager.TabIndex = 11;
            // 
            // Btn_Input
            // 
            this.Btn_Input.Location = new System.Drawing.Point(221, 276);
            this.Btn_Input.Name = "Btn_Input";
            this.Btn_Input.Size = new System.Drawing.Size(158, 52);
            this.Btn_Input.TabIndex = 12;
            this.Btn_Input.Text = "Input";
            this.Btn_Input.UseVisualStyleBackColor = true;
            this.Btn_Input.Click += new System.EventHandler(this.Btn_Input_Click);
            // 
            // Dgv_PLData
            // 
            this.Dgv_PLData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_PLData.Location = new System.Drawing.Point(57, 343);
            this.Dgv_PLData.Name = "Dgv_PLData";
            this.Dgv_PLData.RowHeadersWidth = 82;
            this.Dgv_PLData.RowTemplate.Height = 33;
            this.Dgv_PLData.Size = new System.Drawing.Size(1376, 463);
            this.Dgv_PLData.TabIndex = 13;
            // 
            // Form_PLData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1786, 861);
            this.Controls.Add(this.Dgv_PLData);
            this.Controls.Add(this.Btn_Input);
            this.Controls.Add(this.Tbx_NamaManager);
            this.Controls.Add(this.Tbx_Kota);
            this.Controls.Add(this.Tbx_Kapasitas);
            this.Controls.Add(this.Tbx_NamaStadium);
            this.Controls.Add(this.Tbx_NamaTim);
            this.Controls.Add(this.Tbx_TimID);
            this.Controls.Add(this.Lbl_NamaManager);
            this.Controls.Add(this.Lbl_Kota);
            this.Controls.Add(this.Lbl_Kapasitas);
            this.Controls.Add(this.Lbl_NamaStadium);
            this.Controls.Add(this.Lbl_NamaTim);
            this.Controls.Add(this.Lbl_TimID);
            this.Name = "Form_PLData";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Premier League Data";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_PLData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_TimID;
        private System.Windows.Forms.Label Lbl_NamaTim;
        private System.Windows.Forms.Label Lbl_NamaStadium;
        private System.Windows.Forms.Label Lbl_Kapasitas;
        private System.Windows.Forms.Label Lbl_Kota;
        private System.Windows.Forms.Label Lbl_NamaManager;
        private System.Windows.Forms.TextBox Tbx_TimID;
        private System.Windows.Forms.TextBox Tbx_NamaTim;
        private System.Windows.Forms.TextBox Tbx_NamaStadium;
        private System.Windows.Forms.TextBox Tbx_Kapasitas;
        private System.Windows.Forms.TextBox Tbx_Kota;
        private System.Windows.Forms.TextBox Tbx_NamaManager;
        private System.Windows.Forms.Button Btn_Input;
        private System.Windows.Forms.DataGridView Dgv_PLData;
    }
}

