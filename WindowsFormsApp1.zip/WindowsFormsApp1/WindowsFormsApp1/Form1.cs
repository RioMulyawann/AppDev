﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    // Howie Homan / 0706022310040
    public partial class Form_PLData : Form
    {
        DataTable dt;
        string TimID = "";
        public Form_PLData()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("Tim ID");
            dt.Columns.Add("Nama Tim");
            dt.Columns.Add("Nama Stadium");
            dt.Columns.Add("Kapasitas");
            dt.Columns.Add("Kota");
            dt.Columns.Add("Nama Manager");

            Dgv_PLData.DataSource = dt;
        }

        private void Tbx_NamaTim_TextChanged(object sender, EventArgs e)
        {
            if (Tbx_NamaTim.Text != "")
            {
                int NamaTim = 1;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][0].ToString().Substring(0, 1) == Tbx_NamaTim.Text.ToString().Substring(0, 1).ToUpper())
                    {
                        NamaTim++;
                    }
                }
                if (NamaTim < 10)
                {
                    TimID = Tbx_NamaTim.Text.ToString().Substring(0, 1).ToUpper() + "0" + NamaTim;
                    Tbx_TimID.Text = TimID;
                }
                else
                {
                    TimID = Tbx_NamaTim.Text.ToString().Substring(0, 1).ToUpper() + NamaTim;
                }
                
            }
            
        }

        private void Btn_Input_Click(object sender, EventArgs e)
        {
            bool H = false;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Tbx_TimID.Text == "" || Tbx_NamaTim.Text == "" || Tbx_NamaStadium.Text == "" || Tbx_Kapasitas.Text == "" || Tbx_Kota.Text == "" || Tbx_NamaManager.Text == "")
                {
                    MessageBox.Show("Input Error, Please Input Again");
                    H = true;
                    break;
                }
                if (dt.Rows[i][1].ToString() == Tbx_NamaTim.Text.ToString())
                {
                    MessageBox.Show("Error Same Team Name, Please Input New Team Name Again");
                    H = true;
                    break;
                }
                if (dt.Rows[i][2].ToString() == Tbx_NamaStadium.Text.ToString())
                {
                    MessageBox.Show("Error Same Stadium Name, Please Input New Stadium Name Again");
                    H = true;
                    break;
                }
                if (dt.Rows[i][5].ToString() == Tbx_NamaManager.Text.ToString())
                {
                    MessageBox.Show("Error Same Manager Name, Please Input New Manager Name Again");
                    H = true;
                    break;
                }

            }
            if (H == false)
            {
                dt.Rows.Add(Tbx_TimID.Text, Tbx_NamaTim.Text, Tbx_NamaStadium.Text, Tbx_Kapasitas.Text, Tbx_Kota.Text, Tbx_NamaManager.Text);
                Dgv_PLData.DataSource = dt;
                Tbx_NamaTim.Clear();
                Tbx_NamaStadium.Clear();
                Tbx_Kapasitas.Clear();
                Tbx_Kota.Clear();
                Tbx_NamaManager.Clear();
            }

        }

        private void Tbx_TimID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
