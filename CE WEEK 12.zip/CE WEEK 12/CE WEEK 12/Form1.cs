﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CE_WEEK_12
{
    public partial class Form1 : Form
    {
        MySqlCommand sqlcommand;
        MySqlDataAdapter sqlDataAdapter;
        MySqlConnection sqlconnect;
        string query;
        DataTable dtstudent = new DataTable();
        string NIM = "";
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlconnect = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            string sqlquery = "SELECT * FROM student";
            sqlcommand = new MySqlCommand(sqlquery, sqlconnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlcommand);
            sqlDataAdapter.Fill(dtstudent);
            dataGridView.DataSource = dtstudent;



        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            bool checker = false;
            for (int i = 0; i < dtstudent.Rows.Count; i++)
            {
                if (dtstudent.Rows[i][3].ToString() == tbNIM.Text)
                {
                    checker = true;
                    
                }
            }
            if (checker== true)
            {
                MessageBox.Show("Nim SAMA!!");
            }
            else
            {
                string date = DateTime.Now.ToString("yyyy/MM/dd");
                
                query = $"INSERT INTO student VALUES ('001','{tbname.Text}','{date}','{tbNIM.Text}')";
                sqlconnect.Open();
                sqlcommand = new MySqlCommand(query, sqlconnect);
                sqlcommand.ExecuteNonQuery();
                sqlconnect.Close();
                string sqlquery = "SELECT * FROM student";
                sqlcommand = new MySqlCommand(sqlquery, sqlconnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlcommand);
                sqlDataAdapter.Fill(dtstudent);
                dataGridView.DataSource = dtstudent;
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            
                string queryi = $"UPDATE student SET id_student = '{tbID.Text}', student_nim = '{tbNIM2.Text}', student_name = '{tbname2.Text}' WHERE student_nim = {NIM};";
                sqlconnect.Open();
                sqlcommand = new MySqlCommand(queryi, sqlconnect);
                sqlcommand.ExecuteNonQuery();
                sqlconnect.Close();
                string sqlquery = "SELECT * FROM student";
                sqlcommand = new MySqlCommand(sqlquery, sqlconnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlcommand);
                sqlDataAdapter.Fill(dtstudent);
                dataGridView.DataSource = dtstudent;
            

        }

        private void dataGridView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dataGridView.CurrentRow.Cells[0].Value.ToString();
            tbID.Text = id;

            string name = dataGridView.CurrentRow.Cells[1].Value.ToString();
            tbname2.Text = name;

             NIM = dataGridView.CurrentRow.Cells[3].Value.ToString();
            tbNIM2.Text= NIM;
            

        }
    }
}
