﻿namespace CE_WEEK_12
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInsert = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.tbname = new System.Windows.Forms.TextBox();
            this.tbNIM = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.labelNim = new System.Windows.Forms.Label();
            this.labelNIM2 = new System.Windows.Forms.Label();
            this.labelName2 = new System.Windows.Forms.Label();
            this.tbNIM2 = new System.Windows.Forms.TextBox();
            this.tbname2 = new System.Windows.Forms.TextBox();
            this.labelID = new System.Windows.Forms.Label();
            this.tbID = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(1539, 266);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(311, 72);
            this.btnInsert.TabIndex = 0;
            this.btnInsert.Text = "Insert";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(69, 60);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 82;
            this.dataGridView.RowTemplate.Height = 33;
            this.dataGridView.Size = new System.Drawing.Size(1325, 852);
            this.dataGridView.TabIndex = 1;
            this.dataGridView.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellContentDoubleClick);
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(1491, 107);
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(408, 31);
            this.tbname.TabIndex = 2;
            // 
            // tbNIM
            // 
            this.tbNIM.Location = new System.Drawing.Point(1491, 192);
            this.tbNIM.Name = "tbNIM";
            this.tbNIM.Size = new System.Drawing.Size(408, 31);
            this.tbNIM.TabIndex = 3;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(1486, 70);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(68, 25);
            this.labelName.TabIndex = 4;
            this.labelName.Text = "Name";
            // 
            // labelNim
            // 
            this.labelNim.AutoSize = true;
            this.labelNim.Location = new System.Drawing.Point(1486, 164);
            this.labelNim.Name = "labelNim";
            this.labelNim.Size = new System.Drawing.Size(50, 25);
            this.labelNim.TabIndex = 5;
            this.labelNim.Text = "NIM";
            // 
            // labelNIM2
            // 
            this.labelNIM2.AutoSize = true;
            this.labelNIM2.Location = new System.Drawing.Point(1486, 623);
            this.labelNIM2.Name = "labelNIM2";
            this.labelNIM2.Size = new System.Drawing.Size(50, 25);
            this.labelNIM2.TabIndex = 9;
            this.labelNIM2.Text = "NIM";
            // 
            // labelName2
            // 
            this.labelName2.AutoSize = true;
            this.labelName2.Location = new System.Drawing.Point(1486, 529);
            this.labelName2.Name = "labelName2";
            this.labelName2.Size = new System.Drawing.Size(68, 25);
            this.labelName2.TabIndex = 8;
            this.labelName2.Text = "Name";
            // 
            // tbNIM2
            // 
            this.tbNIM2.Location = new System.Drawing.Point(1491, 651);
            this.tbNIM2.Name = "tbNIM2";
            this.tbNIM2.Size = new System.Drawing.Size(408, 31);
            this.tbNIM2.TabIndex = 7;
            // 
            // tbname2
            // 
            this.tbname2.Location = new System.Drawing.Point(1491, 566);
            this.tbname2.Name = "tbname2";
            this.tbname2.Size = new System.Drawing.Size(408, 31);
            this.tbname2.TabIndex = 6;
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(1486, 447);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(38, 25);
            this.labelID.TabIndex = 11;
            this.labelID.Text = "ID:";
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(1491, 484);
            this.tbID.Name = "tbID";
            this.tbID.Size = new System.Drawing.Size(408, 31);
            this.tbID.TabIndex = 10;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(1539, 737);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(311, 72);
            this.btnUpdate.TabIndex = 12;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(2057, 1160);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.tbID);
            this.Controls.Add(this.labelNIM2);
            this.Controls.Add(this.labelName2);
            this.Controls.Add(this.tbNIM2);
            this.Controls.Add(this.tbname2);
            this.Controls.Add(this.labelNim);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.tbNIM);
            this.Controls.Add(this.tbname);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.btnInsert);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.TextBox tbNIM;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelNim;
        private System.Windows.Forms.Label labelNIM2;
        private System.Windows.Forms.Label labelName2;
        private System.Windows.Forms.TextBox tbNIM2;
        private System.Windows.Forms.TextBox tbname2;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.Button btnUpdate;
    }
}

