﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    internal class Player
    {
        private string playerNum;
        private string playerName;
        private string playerPos;

        // Constructor 
        public Player (string playerNum, string playerName,string playerPos)
        {
            this.playerNum = playerNum;
            this.playerName = playerName;
            this.playerPos = playerPos;
        }
        // Getter mengambil value dari variable
        public string getPlayerNum() { return playerNum; }
        public string getPlayerName() {  return playerName; }
        public string getPlayerPos() {  return playerPos; }

        // Setter set value untuk variablenya

        public void setPlayerNum(string playerNum) {this.playerNum = playerNum; }
        public void setPlayerName(string playerName) { this.playerName = playerName; }
        public void setPlayerPos(string playerPos) {  this.playerPos = playerPos; }
    }
}
