﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    internal class Team
    {
        private string teamName;
        private string teamCountry;
        private string teamCity;
        private List<Player> playerList;

        // Constructor
        public Team (string _teamName, string _teamCountry, string _teamCity, List<Player> _playerList)
        {
            teamName = _teamName;
            teamCountry = _teamCountry;
            teamCity = _teamCity;
            playerList = _playerList;
        }

        // Getter
        public string getTeamName() {  return teamName; }
        public string getTeamCountry() {  return teamCountry; }
        public string getTeamCity() {  return teamCity; }
        public List<Player> getPlayerList() {  return playerList; }

        // Setter
        public void setTeamName(string teamName) {  this.teamName = teamName; }
        public void setTeamCountry(string teamCountry) { this.teamCountry = teamCountry; }
        public void setTeamCity(string teamCity) {  this.teamCity = teamCity; }
        public void setPlayerList(List<Player> playerList) { this.playerList = playerList;}
        


    }
}
