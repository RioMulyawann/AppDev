﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        List <Team> teamLists;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            teamLists = new List<Team>();
            List<Player> playerList = new List<Player>
            {
                new Player("01","Rio","FW"),
                new Player ("02", "Howie","MF"),
                new Player ("03", "Stanley", "GK")
            };
          
            teamLists.Add(new Team ("UC Ceria", "Indonesia", "Surabaya", playerList));
            playerList = new List<Player>
            {
                new Player ("01","Jefferson","GK"),
                new Player ("02","Bernard","MF"),
                new Player ("03", "Anton", "FW")
            };
            teamLists.Add(new Team("UC Bahagia", "Indonesia", "Surabaya", playerList));

            foreach (Team team in teamLists)
            {
                string teamName = team.getTeamName();
                string teamCountry = team.getTeamCountry();
                string teamCity = team.getTeamCity();
                playerList = team.getPlayerList();
                string players = "";
                foreach (Player player in playerList)
                {
                    players += player.getPlayerName() + ", ";
                }
                MessageBox.Show(teamName + " is a " + teamCountry + " team with "+players + " members, based in " + teamCity);

            }
        }
    }
}
