﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Th_Week_2
{
    public partial class Form1 : Form
    {
        public static string kata1;
        public static string kata2;
        public static string kata3;
        public static string kata4;
        public static string kata5;
        public static string randomword;


        public Form1()
        {
            InitializeComponent();
            

        }
        List<string> katatebak = new List<string>();
        int menang = 0;
        string guessedletter = "";


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void btn_selesai_Click(object sender, EventArgs e)
        {
            kata1 = textbox_kata1.Text.ToUpper();
            kata2 = textbox_kata2.Text.ToUpper();
            kata3 = textbox_kata3.Text.ToUpper();
            kata4 = textbox_kata4.Text.ToUpper();
            kata5 = textbox_kata5.Text.ToUpper();





            if (kata1.Length == 5 && kata2.Length == 5 && kata3.Length == 5 && kata4.Length == 5 && kata5.Length == 5 && kata1 != kata2 && kata1 != kata3 && kata1 != kata4 && kata1 != kata5 && kata2 != kata3 && kata2 != kata4 && kata2 != kata5 && kata3 != kata4 && kata3 != kata5 && kata4 != kata5)
            {
                panel1.Visible = false;
                panel2.Visible = true;

                Random rdm = new Random();
                int randomnum = rdm.Next(1, 6);
                string randomword = "";
                if (randomnum == 1) { randomword = kata1; }
                else if (randomnum == 2) { randomword = kata2; }
                else if (randomnum == 3) { randomword = kata3; }
                else if (randomnum == 4) { randomword = kata4; }
                else if (randomnum == 5) { randomword = kata5; }

                foreach (char huruf in randomword)
                {
                    katatebak.Add(Convert.ToString(huruf));
                }
            }
            else
            {
                MessageBox.Show("Input tidak tepat, Silahkan benerin");
            }

        }
        private void sistemGame()
        {
            if (guessedletter == katatebak[0])
            {
                label_huruf1.Text = guessedletter;
                menang++;
            }
            if (guessedletter == katatebak[1])
            {
                label_huruf2.Text = guessedletter;
                menang++;
            }
            if (guessedletter == katatebak[2])
            {
                label_huruf3.Text = guessedletter;
                menang++;
            }
            if (guessedletter == katatebak[3])
            {
                label_huruf4.Text = guessedletter;
                menang++;
            }
            if (guessedletter == katatebak[4])
            {
                label_huruf5.Text = guessedletter;
                menang++;
            }
            if (menang == 5)
            {
                MessageBox.Show("Selamat Anda Menang");
            }
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            guessedletter = "Q";
            sistemGame();
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            guessedletter = "W";
            sistemGame();
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            guessedletter = "E";
            sistemGame();
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            guessedletter = "R";
            sistemGame();
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            guessedletter = "T";
            sistemGame();
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            guessedletter = "Y";
            sistemGame();
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            guessedletter = "U";
            sistemGame();
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            guessedletter = "I";
            sistemGame();
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            guessedletter = "O";
            sistemGame();
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            guessedletter = "P";
            sistemGame();
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            guessedletter = "A";
            sistemGame();
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            guessedletter = "S";
            sistemGame();
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            guessedletter = "D";
            sistemGame();
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            guessedletter = "F";
            sistemGame();
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            guessedletter = "G";
            sistemGame();
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            guessedletter = "H";
            sistemGame();
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            guessedletter = "J";
            sistemGame();
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            guessedletter = "K";
            sistemGame();
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            guessedletter = "L";
            sistemGame();
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            guessedletter = "Z";
            sistemGame();
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            guessedletter = "X";
            sistemGame();
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            guessedletter = "C";
            sistemGame();
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            guessedletter = "V";
            sistemGame();
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            guessedletter = "B";
            sistemGame();
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            guessedletter = "N";
            sistemGame();
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            guessedletter = "M";
            sistemGame();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }
    }
}
