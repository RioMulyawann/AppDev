﻿namespace Th_Week_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label_huruf5 = new System.Windows.Forms.Label();
            this.label_huruf4 = new System.Windows.Forms.Label();
            this.label_huruf3 = new System.Windows.Forms.Label();
            this.label_huruf2 = new System.Windows.Forms.Label();
            this.label_huruf1 = new System.Windows.Forms.Label();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_selesai = new System.Windows.Forms.Button();
            this.label_intruksi = new System.Windows.Forms.Label();
            this.label_kata5 = new System.Windows.Forms.Label();
            this.label_kata4 = new System.Windows.Forms.Label();
            this.label_kata3 = new System.Windows.Forms.Label();
            this.label_kata2 = new System.Windows.Forms.Label();
            this.label_kata1 = new System.Windows.Forms.Label();
            this.textbox_kata5 = new System.Windows.Forms.TextBox();
            this.textbox_kata4 = new System.Windows.Forms.TextBox();
            this.textbox_kata3 = new System.Windows.Forms.TextBox();
            this.textbox_kata2 = new System.Windows.Forms.TextBox();
            this.textbox_kata1 = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label_huruf5);
            this.panel2.Controls.Add(this.label_huruf4);
            this.panel2.Controls.Add(this.label_huruf3);
            this.panel2.Controls.Add(this.label_huruf2);
            this.panel2.Controls.Add(this.label_huruf1);
            this.panel2.Controls.Add(this.btn_M);
            this.panel2.Controls.Add(this.btn_N);
            this.panel2.Controls.Add(this.btn_B);
            this.panel2.Controls.Add(this.btn_V);
            this.panel2.Controls.Add(this.btn_C);
            this.panel2.Controls.Add(this.btn_X);
            this.panel2.Controls.Add(this.btn_Z);
            this.panel2.Controls.Add(this.btn_L);
            this.panel2.Controls.Add(this.btn_K);
            this.panel2.Controls.Add(this.btn_J);
            this.panel2.Controls.Add(this.btn_H);
            this.panel2.Controls.Add(this.btn_G);
            this.panel2.Controls.Add(this.btn_F);
            this.panel2.Controls.Add(this.btn_D);
            this.panel2.Controls.Add(this.btn_S);
            this.panel2.Controls.Add(this.btn_A);
            this.panel2.Controls.Add(this.btn_P);
            this.panel2.Controls.Add(this.btn_O);
            this.panel2.Controls.Add(this.btn_I);
            this.panel2.Controls.Add(this.btn_U);
            this.panel2.Controls.Add(this.btn_Y);
            this.panel2.Controls.Add(this.btn_T);
            this.panel2.Controls.Add(this.btn_R);
            this.panel2.Controls.Add(this.btn_E);
            this.panel2.Controls.Add(this.btn_W);
            this.panel2.Controls.Add(this.btn_Q);
            this.panel2.Location = new System.Drawing.Point(66, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(642, 377);
            this.panel2.TabIndex = 59;
            this.panel2.Visible = false;
            // 
            // label_huruf5
            // 
            this.label_huruf5.AutoSize = true;
            this.label_huruf5.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label_huruf5.Location = new System.Drawing.Point(390, 52);
            this.label_huruf5.Name = "label_huruf5";
            this.label_huruf5.Size = new System.Drawing.Size(42, 46);
            this.label_huruf5.TabIndex = 56;
            this.label_huruf5.Text = "_";
            // 
            // label_huruf4
            // 
            this.label_huruf4.AutoSize = true;
            this.label_huruf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label_huruf4.Location = new System.Drawing.Point(353, 52);
            this.label_huruf4.Name = "label_huruf4";
            this.label_huruf4.Size = new System.Drawing.Size(42, 46);
            this.label_huruf4.TabIndex = 55;
            this.label_huruf4.Text = "_";
            // 
            // label_huruf3
            // 
            this.label_huruf3.AutoSize = true;
            this.label_huruf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label_huruf3.Location = new System.Drawing.Point(313, 52);
            this.label_huruf3.Name = "label_huruf3";
            this.label_huruf3.Size = new System.Drawing.Size(42, 46);
            this.label_huruf3.TabIndex = 54;
            this.label_huruf3.Text = "_";
            // 
            // label_huruf2
            // 
            this.label_huruf2.AutoSize = true;
            this.label_huruf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label_huruf2.Location = new System.Drawing.Point(268, 52);
            this.label_huruf2.Name = "label_huruf2";
            this.label_huruf2.Size = new System.Drawing.Size(42, 46);
            this.label_huruf2.TabIndex = 53;
            this.label_huruf2.Text = "_";
            // 
            // label_huruf1
            // 
            this.label_huruf1.AutoSize = true;
            this.label_huruf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label_huruf1.Location = new System.Drawing.Point(220, 52);
            this.label_huruf1.Name = "label_huruf1";
            this.label_huruf1.Size = new System.Drawing.Size(42, 46);
            this.label_huruf1.TabIndex = 52;
            this.label_huruf1.Text = "_";
            // 
            // btn_M
            // 
            this.btn_M.Location = new System.Drawing.Point(435, 289);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(47, 42);
            this.btn_M.TabIndex = 51;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // btn_N
            // 
            this.btn_N.Location = new System.Drawing.Point(382, 289);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(47, 42);
            this.btn_N.TabIndex = 50;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_B
            // 
            this.btn_B.Location = new System.Drawing.Point(329, 289);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(47, 42);
            this.btn_B.TabIndex = 49;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_V
            // 
            this.btn_V.Location = new System.Drawing.Point(276, 289);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(47, 42);
            this.btn_V.TabIndex = 48;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_C
            // 
            this.btn_C.Location = new System.Drawing.Point(225, 289);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(47, 42);
            this.btn_C.TabIndex = 47;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_X
            // 
            this.btn_X.Location = new System.Drawing.Point(172, 289);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(47, 42);
            this.btn_X.TabIndex = 46;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Location = new System.Drawing.Point(119, 289);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(47, 42);
            this.btn_Z.TabIndex = 45;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // btn_L
            // 
            this.btn_L.Location = new System.Drawing.Point(512, 241);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(47, 42);
            this.btn_L.TabIndex = 44;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_K
            // 
            this.btn_K.Location = new System.Drawing.Point(459, 241);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(47, 42);
            this.btn_K.TabIndex = 43;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_J
            // 
            this.btn_J.Location = new System.Drawing.Point(406, 241);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(47, 42);
            this.btn_J.TabIndex = 42;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_H
            // 
            this.btn_H.Location = new System.Drawing.Point(353, 241);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(47, 42);
            this.btn_H.TabIndex = 41;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_G
            // 
            this.btn_G.Location = new System.Drawing.Point(302, 241);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(47, 42);
            this.btn_G.TabIndex = 40;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_F
            // 
            this.btn_F.Location = new System.Drawing.Point(249, 241);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(47, 42);
            this.btn_F.TabIndex = 39;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_D
            // 
            this.btn_D.Location = new System.Drawing.Point(196, 241);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(47, 42);
            this.btn_D.TabIndex = 38;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_S
            // 
            this.btn_S.Location = new System.Drawing.Point(142, 241);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(47, 42);
            this.btn_S.TabIndex = 37;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_A
            // 
            this.btn_A.Location = new System.Drawing.Point(89, 241);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(47, 42);
            this.btn_A.TabIndex = 36;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_P
            // 
            this.btn_P.Location = new System.Drawing.Point(539, 193);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(47, 42);
            this.btn_P.TabIndex = 35;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_O
            // 
            this.btn_O.Location = new System.Drawing.Point(486, 193);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(47, 42);
            this.btn_O.TabIndex = 34;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_I
            // 
            this.btn_I.Location = new System.Drawing.Point(433, 193);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(47, 42);
            this.btn_I.TabIndex = 33;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = true;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // btn_U
            // 
            this.btn_U.Location = new System.Drawing.Point(380, 193);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(47, 42);
            this.btn_U.TabIndex = 32;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Location = new System.Drawing.Point(329, 193);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(47, 42);
            this.btn_Y.TabIndex = 31;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_T
            // 
            this.btn_T.Location = new System.Drawing.Point(276, 193);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(47, 42);
            this.btn_T.TabIndex = 30;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_R
            // 
            this.btn_R.Location = new System.Drawing.Point(223, 193);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(47, 42);
            this.btn_R.TabIndex = 29;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_E
            // 
            this.btn_E.Location = new System.Drawing.Point(170, 193);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(47, 42);
            this.btn_E.TabIndex = 28;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_W
            // 
            this.btn_W.Location = new System.Drawing.Point(117, 193);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(47, 42);
            this.btn_W.TabIndex = 27;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // btn_Q
            // 
            this.btn_Q.Location = new System.Drawing.Point(64, 193);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(47, 42);
            this.btn_Q.TabIndex = 26;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_selesai);
            this.panel1.Controls.Add(this.label_intruksi);
            this.panel1.Controls.Add(this.label_kata5);
            this.panel1.Controls.Add(this.label_kata4);
            this.panel1.Controls.Add(this.label_kata3);
            this.panel1.Controls.Add(this.label_kata2);
            this.panel1.Controls.Add(this.label_kata1);
            this.panel1.Controls.Add(this.textbox_kata5);
            this.panel1.Controls.Add(this.textbox_kata4);
            this.panel1.Controls.Add(this.textbox_kata3);
            this.panel1.Controls.Add(this.textbox_kata2);
            this.panel1.Controls.Add(this.textbox_kata1);
            this.panel1.Location = new System.Drawing.Point(229, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(346, 291);
            this.panel1.TabIndex = 60;
            // 
            // btn_selesai
            // 
            this.btn_selesai.Location = new System.Drawing.Point(135, 238);
            this.btn_selesai.Name = "btn_selesai";
            this.btn_selesai.Size = new System.Drawing.Size(80, 24);
            this.btn_selesai.TabIndex = 11;
            this.btn_selesai.Text = "Selesai";
            this.btn_selesai.UseVisualStyleBackColor = true;
            this.btn_selesai.Click += new System.EventHandler(this.btn_selesai_Click);
            // 
            // label_intruksi
            // 
            this.label_intruksi.AutoSize = true;
            this.label_intruksi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_intruksi.Location = new System.Drawing.Point(14, 19);
            this.label_intruksi.Name = "label_intruksi";
            this.label_intruksi.Size = new System.Drawing.Size(317, 24);
            this.label_intruksi.TabIndex = 10;
            this.label_intruksi.Text = "Ketik 5 Kata yang memilik 5 huruf";
            // 
            // label_kata5
            // 
            this.label_kata5.AutoSize = true;
            this.label_kata5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_kata5.Location = new System.Drawing.Point(80, 196);
            this.label_kata5.Name = "label_kata5";
            this.label_kata5.Size = new System.Drawing.Size(22, 20);
            this.label_kata5.TabIndex = 9;
            this.label_kata5.Text = "5.";
            // 
            // label_kata4
            // 
            this.label_kata4.AutoSize = true;
            this.label_kata4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_kata4.Location = new System.Drawing.Point(80, 164);
            this.label_kata4.Name = "label_kata4";
            this.label_kata4.Size = new System.Drawing.Size(22, 20);
            this.label_kata4.TabIndex = 8;
            this.label_kata4.Text = "4.";
            // 
            // label_kata3
            // 
            this.label_kata3.AutoSize = true;
            this.label_kata3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_kata3.Location = new System.Drawing.Point(80, 132);
            this.label_kata3.Name = "label_kata3";
            this.label_kata3.Size = new System.Drawing.Size(22, 20);
            this.label_kata3.TabIndex = 7;
            this.label_kata3.Text = "3.";
            // 
            // label_kata2
            // 
            this.label_kata2.AutoSize = true;
            this.label_kata2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_kata2.Location = new System.Drawing.Point(80, 100);
            this.label_kata2.Name = "label_kata2";
            this.label_kata2.Size = new System.Drawing.Size(22, 20);
            this.label_kata2.TabIndex = 6;
            this.label_kata2.Text = "2.";
            // 
            // label_kata1
            // 
            this.label_kata1.AutoSize = true;
            this.label_kata1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_kata1.Location = new System.Drawing.Point(80, 65);
            this.label_kata1.Name = "label_kata1";
            this.label_kata1.Size = new System.Drawing.Size(22, 20);
            this.label_kata1.TabIndex = 5;
            this.label_kata1.Text = "1.";
            // 
            // textbox_kata5
            // 
            this.textbox_kata5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_kata5.Location = new System.Drawing.Point(108, 190);
            this.textbox_kata5.Name = "textbox_kata5";
            this.textbox_kata5.Size = new System.Drawing.Size(141, 26);
            this.textbox_kata5.TabIndex = 4;
            // 
            // textbox_kata4
            // 
            this.textbox_kata4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_kata4.Location = new System.Drawing.Point(108, 158);
            this.textbox_kata4.Name = "textbox_kata4";
            this.textbox_kata4.Size = new System.Drawing.Size(141, 26);
            this.textbox_kata4.TabIndex = 3;
            // 
            // textbox_kata3
            // 
            this.textbox_kata3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_kata3.Location = new System.Drawing.Point(108, 126);
            this.textbox_kata3.Name = "textbox_kata3";
            this.textbox_kata3.Size = new System.Drawing.Size(141, 26);
            this.textbox_kata3.TabIndex = 2;
            // 
            // textbox_kata2
            // 
            this.textbox_kata2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_kata2.Location = new System.Drawing.Point(108, 94);
            this.textbox_kata2.Name = "textbox_kata2";
            this.textbox_kata2.Size = new System.Drawing.Size(141, 26);
            this.textbox_kata2.TabIndex = 1;
            // 
            // textbox_kata1
            // 
            this.textbox_kata1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_kata1.Location = new System.Drawing.Point(108, 62);
            this.textbox_kata1.Name = "textbox_kata1";
            this.textbox_kata1.Size = new System.Drawing.Size(141, 26);
            this.textbox_kata1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label_huruf5;
        private System.Windows.Forms.Label label_huruf4;
        private System.Windows.Forms.Label label_huruf3;
        private System.Windows.Forms.Label label_huruf2;
        private System.Windows.Forms.Label label_huruf1;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_selesai;
        private System.Windows.Forms.Label label_intruksi;
        private System.Windows.Forms.Label label_kata5;
        private System.Windows.Forms.Label label_kata4;
        private System.Windows.Forms.Label label_kata3;
        private System.Windows.Forms.Label label_kata2;
        private System.Windows.Forms.Label label_kata1;
        private System.Windows.Forms.TextBox textbox_kata5;
        private System.Windows.Forms.TextBox textbox_kata4;
        private System.Windows.Forms.TextBox textbox_kata3;
        private System.Windows.Forms.TextBox textbox_kata2;
        private System.Windows.Forms.TextBox textbox_kata1;
    }
}

