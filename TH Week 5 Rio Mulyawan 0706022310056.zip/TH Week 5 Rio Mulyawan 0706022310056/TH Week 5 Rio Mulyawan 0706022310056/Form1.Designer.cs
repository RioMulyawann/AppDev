﻿namespace TH_Week_5_Rio_Mulyawan_0706022310056
{
    partial class ShopProgram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblProduct = new System.Windows.Forms.Label();
            this.dataGridProduct = new System.Windows.Forms.DataGridView();
            this.lblCategory = new System.Windows.Forms.Label();
            this.dataGridCategory = new System.Windows.Forms.DataGridView();
            this.lblNamaCategory = new System.Windows.Forms.Label();
            this.tbNamaCategory = new System.Windows.Forms.TextBox();
            this.btnRemoveCategory = new System.Windows.Forms.Button();
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.tbNamaProduct = new System.Windows.Forms.TextBox();
            this.lblNamaDetails = new System.Windows.Forms.Label();
            this.lblDetails = new System.Windows.Forms.Label();
            this.lblCategoryProduct = new System.Windows.Forms.Label();
            this.cboxCategory = new System.Windows.Forms.ComboBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tbHarga = new System.Windows.Forms.TextBox();
            this.tbStock = new System.Windows.Forms.TextBox();
            this.lblHarga = new System.Windows.Forms.Label();
            this.lblStock = new System.Windows.Forms.Label();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnEditProduct = new System.Windows.Forms.Button();
            this.btnRemoveProduct = new System.Windows.Forms.Button();
            this.btnFilterAll = new System.Windows.Forms.Button();
            this.btnFilter = new System.Windows.Forms.Button();
            this.cboxFilter = new System.Windows.Forms.ComboBox();
            this.PhotoBlackPink = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCategory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PhotoBlackPink)).BeginInit();
            this.SuspendLayout();
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.Location = new System.Drawing.Point(52, 21);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(103, 29);
            this.lblProduct.TabIndex = 0;
            this.lblProduct.Text = "Product";
            // 
            // dataGridProduct
            // 
            this.dataGridProduct.AllowUserToAddRows = false;
            this.dataGridProduct.AllowUserToDeleteRows = false;
            this.dataGridProduct.AllowUserToResizeRows = false;
            this.dataGridProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridProduct.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridProduct.Location = new System.Drawing.Point(57, 67);
            this.dataGridProduct.MultiSelect = false;
            this.dataGridProduct.Name = "dataGridProduct";
            this.dataGridProduct.RowHeadersVisible = false;
            this.dataGridProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridProduct.Size = new System.Drawing.Size(549, 245);
            this.dataGridProduct.TabIndex = 30;
            this.dataGridProduct.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dataGridProduct_DataBindingComplete);
            this.dataGridProduct.SelectionChanged += new System.EventHandler(this.dataGridProduct_SelectionChanged);
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.Location = new System.Drawing.Point(650, 21);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(118, 29);
            this.lblCategory.TabIndex = 2;
            this.lblCategory.Text = "Category";
            // 
            // dataGridCategory
            // 
            this.dataGridCategory.AllowUserToAddRows = false;
            this.dataGridCategory.AllowUserToDeleteRows = false;
            this.dataGridCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridCategory.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridCategory.Location = new System.Drawing.Point(655, 67);
            this.dataGridCategory.Name = "dataGridCategory";
            this.dataGridCategory.RowHeadersVisible = false;
            this.dataGridCategory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridCategory.Size = new System.Drawing.Size(242, 184);
            this.dataGridCategory.TabIndex = 3;
            this.dataGridCategory.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dataGridProduct_DataBindingComplete);
            this.dataGridCategory.SelectionChanged += new System.EventHandler(this.dataGridCategory_SelectionChanged);
            // 
            // lblNamaCategory
            // 
            this.lblNamaCategory.AutoSize = true;
            this.lblNamaCategory.Location = new System.Drawing.Point(652, 268);
            this.lblNamaCategory.Name = "lblNamaCategory";
            this.lblNamaCategory.Size = new System.Drawing.Size(41, 13);
            this.lblNamaCategory.TabIndex = 4;
            this.lblNamaCategory.Text = "Nama :";
            // 
            // tbNamaCategory
            // 
            this.tbNamaCategory.Location = new System.Drawing.Point(705, 265);
            this.tbNamaCategory.Name = "tbNamaCategory";
            this.tbNamaCategory.Size = new System.Drawing.Size(192, 20);
            this.tbNamaCategory.TabIndex = 5;
            // 
            // btnRemoveCategory
            // 
            this.btnRemoveCategory.BackColor = System.Drawing.Color.Red;
            this.btnRemoveCategory.Location = new System.Drawing.Point(804, 300);
            this.btnRemoveCategory.Name = "btnRemoveCategory";
            this.btnRemoveCategory.Size = new System.Drawing.Size(88, 42);
            this.btnRemoveCategory.TabIndex = 6;
            this.btnRemoveCategory.Text = "Remove Category";
            this.btnRemoveCategory.UseVisualStyleBackColor = false;
            this.btnRemoveCategory.Click += new System.EventHandler(this.btnRemoveCategory_Click);
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.BackColor = System.Drawing.Color.Lime;
            this.btnAddCategory.Location = new System.Drawing.Point(711, 300);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(88, 42);
            this.btnAddCategory.TabIndex = 7;
            this.btnAddCategory.Text = "Add Category";
            this.btnAddCategory.UseVisualStyleBackColor = false;
            this.btnAddCategory.Click += new System.EventHandler(this.btnAddCategory_Click);
            // 
            // tbNamaProduct
            // 
            this.tbNamaProduct.Location = new System.Drawing.Point(101, 377);
            this.tbNamaProduct.Name = "tbNamaProduct";
            this.tbNamaProduct.Size = new System.Drawing.Size(317, 20);
            this.tbNamaProduct.TabIndex = 9;
            // 
            // lblNamaDetails
            // 
            this.lblNamaDetails.AutoSize = true;
            this.lblNamaDetails.Location = new System.Drawing.Point(54, 380);
            this.lblNamaDetails.Name = "lblNamaDetails";
            this.lblNamaDetails.Size = new System.Drawing.Size(41, 13);
            this.lblNamaDetails.TabIndex = 8;
            this.lblNamaDetails.Text = "Nama :";
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetails.Location = new System.Drawing.Point(52, 334);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(94, 29);
            this.lblDetails.TabIndex = 10;
            this.lblDetails.Text = "Details";
            // 
            // lblCategoryProduct
            // 
            this.lblCategoryProduct.AutoSize = true;
            this.lblCategoryProduct.Location = new System.Drawing.Point(40, 404);
            this.lblCategoryProduct.Name = "lblCategoryProduct";
            this.lblCategoryProduct.Size = new System.Drawing.Size(58, 13);
            this.lblCategoryProduct.TabIndex = 11;
            this.lblCategoryProduct.Text = "Category : ";
            // 
            // cboxCategory
            // 
            this.cboxCategory.FormattingEnabled = true;
            this.cboxCategory.Location = new System.Drawing.Point(101, 404);
            this.cboxCategory.Name = "cboxCategory";
            this.cboxCategory.Size = new System.Drawing.Size(101, 21);
            this.cboxCategory.TabIndex = 12;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // tbHarga
            // 
            this.tbHarga.Location = new System.Drawing.Point(101, 431);
            this.tbHarga.Name = "tbHarga";
            this.tbHarga.Size = new System.Drawing.Size(101, 20);
            this.tbHarga.TabIndex = 1;
            // 
            // tbStock
            // 
            this.tbStock.Location = new System.Drawing.Point(101, 457);
            this.tbStock.Name = "tbStock";
            this.tbStock.Size = new System.Drawing.Size(101, 20);
            this.tbStock.TabIndex = 15;
            // 
            // lblHarga
            // 
            this.lblHarga.AutoSize = true;
            this.lblHarga.Location = new System.Drawing.Point(53, 431);
            this.lblHarga.Name = "lblHarga";
            this.lblHarga.Size = new System.Drawing.Size(45, 13);
            this.lblHarga.TabIndex = 16;
            this.lblHarga.Text = "Harga : ";
            // 
            // lblStock
            // 
            this.lblStock.AutoSize = true;
            this.lblStock.Location = new System.Drawing.Point(54, 460);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(44, 13);
            this.lblStock.TabIndex = 17;
            this.lblStock.Text = "Stock : ";
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.Color.Lime;
            this.btnAddProduct.Location = new System.Drawing.Point(217, 404);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(63, 73);
            this.btnAddProduct.TabIndex = 18;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnEditProduct
            // 
            this.btnEditProduct.BackColor = System.Drawing.Color.Yellow;
            this.btnEditProduct.Location = new System.Drawing.Point(286, 404);
            this.btnEditProduct.Name = "btnEditProduct";
            this.btnEditProduct.Size = new System.Drawing.Size(63, 73);
            this.btnEditProduct.TabIndex = 19;
            this.btnEditProduct.Text = "Edit Product";
            this.btnEditProduct.UseVisualStyleBackColor = false;
            this.btnEditProduct.Click += new System.EventHandler(this.btnEditProduct_Click);
            // 
            // btnRemoveProduct
            // 
            this.btnRemoveProduct.BackColor = System.Drawing.Color.Red;
            this.btnRemoveProduct.Location = new System.Drawing.Point(355, 404);
            this.btnRemoveProduct.Name = "btnRemoveProduct";
            this.btnRemoveProduct.Size = new System.Drawing.Size(63, 73);
            this.btnRemoveProduct.TabIndex = 20;
            this.btnRemoveProduct.Text = "Remove Product";
            this.btnRemoveProduct.UseVisualStyleBackColor = false;
            this.btnRemoveProduct.Click += new System.EventHandler(this.btnRemoveProduct_Click);
            // 
            // btnFilterAll
            // 
            this.btnFilterAll.Location = new System.Drawing.Point(391, 40);
            this.btnFilterAll.Name = "btnFilterAll";
            this.btnFilterAll.Size = new System.Drawing.Size(43, 21);
            this.btnFilterAll.TabIndex = 21;
            this.btnFilterAll.Text = "All";
            this.btnFilterAll.UseVisualStyleBackColor = true;
            this.btnFilterAll.Click += new System.EventHandler(this.btnFilterAll_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(440, 40);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(43, 21);
            this.btnFilter.TabIndex = 22;
            this.btnFilter.Text = "Filter: ";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // cboxFilter
            // 
            this.cboxFilter.Enabled = false;
            this.cboxFilter.FormattingEnabled = true;
            this.cboxFilter.Location = new System.Drawing.Point(489, 41);
            this.cboxFilter.Name = "cboxFilter";
            this.cboxFilter.Size = new System.Drawing.Size(117, 21);
            this.cboxFilter.TabIndex = 23;
            this.cboxFilter.SelectedValueChanged += new System.EventHandler(this.cboxFilter_SelectedValueChanged);
            // 
            // PhotoBlackPink
            // 
            this.PhotoBlackPink.Image = global::TH_Week_5_Rio_Mulyawan_0706022310056.Properties.Resources.blackpink_lalisa_lisa_blackpink_jisoo_blackpink_jennie_blackpink_hd_wallpaper_preview;
            this.PhotoBlackPink.InitialImage = global::TH_Week_5_Rio_Mulyawan_0706022310056.Properties.Resources.blackpink_lalisa_lisa_blackpink_jisoo_blackpink_jennie_blackpink_hd_wallpaper_preview;
            this.PhotoBlackPink.Location = new System.Drawing.Point(668, 348);
            this.PhotoBlackPink.Name = "PhotoBlackPink";
            this.PhotoBlackPink.Size = new System.Drawing.Size(224, 149);
            this.PhotoBlackPink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PhotoBlackPink.TabIndex = 31;
            this.PhotoBlackPink.TabStop = false;
            // 
            // ShopProgram
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(972, 509);
            this.Controls.Add(this.PhotoBlackPink);
            this.Controls.Add(this.cboxFilter);
            this.Controls.Add(this.btnFilter);
            this.Controls.Add(this.btnFilterAll);
            this.Controls.Add(this.btnRemoveProduct);
            this.Controls.Add(this.btnEditProduct);
            this.Controls.Add(this.btnAddProduct);
            this.Controls.Add(this.lblStock);
            this.Controls.Add(this.lblHarga);
            this.Controls.Add(this.tbStock);
            this.Controls.Add(this.tbHarga);
            this.Controls.Add(this.cboxCategory);
            this.Controls.Add(this.lblCategoryProduct);
            this.Controls.Add(this.lblDetails);
            this.Controls.Add(this.tbNamaProduct);
            this.Controls.Add(this.lblNamaDetails);
            this.Controls.Add(this.btnAddCategory);
            this.Controls.Add(this.btnRemoveCategory);
            this.Controls.Add(this.tbNamaCategory);
            this.Controls.Add(this.lblNamaCategory);
            this.Controls.Add(this.dataGridCategory);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.dataGridProduct);
            this.Controls.Add(this.lblProduct);
            this.Name = "ShopProgram";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ShopProgram_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridProduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCategory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PhotoBlackPink)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.DataGridView dataGridProduct;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.DataGridView dataGridCategory;
        private System.Windows.Forms.Label lblNamaCategory;
        private System.Windows.Forms.TextBox tbNamaCategory;
        private System.Windows.Forms.Button btnRemoveCategory;
        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.TextBox tbNamaProduct;
        private System.Windows.Forms.Label lblNamaDetails;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Label lblCategoryProduct;
        private System.Windows.Forms.ComboBox cboxCategory;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox tbHarga;
        private System.Windows.Forms.TextBox tbStock;
        private System.Windows.Forms.Label lblHarga;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnEditProduct;
        private System.Windows.Forms.Button btnRemoveProduct;
        private System.Windows.Forms.Button btnFilterAll;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.ComboBox cboxFilter;
        private System.Windows.Forms.PictureBox PhotoBlackPink;
    }
}

