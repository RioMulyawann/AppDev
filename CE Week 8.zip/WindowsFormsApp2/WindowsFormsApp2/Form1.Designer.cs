﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelUsername = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.labelDatabase = new System.Windows.Forms.Label();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.tbDatabse = new System.Windows.Forms.TextBox();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.dataGridViewPlayer = new System.Windows.Forms.DataGridView();
            this.tbNama = new System.Windows.Forms.TextBox();
            this.tbKota = new System.Windows.Forms.TextBox();
            this.tbNIM = new System.Windows.Forms.TextBox();
            this.labelKota = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.labelNama = new System.Windows.Forms.Label();
            this.labelNIM = new System.Windows.Forms.Label();
            this.dataGridViewMahasiswa = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMahasiswa)).BeginInit();
            this.SuspendLayout();
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.Location = new System.Drawing.Point(52, 57);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(122, 25);
            this.labelUsername.TabIndex = 0;
            this.labelUsername.Text = "Username: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password: ";
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(239, 205);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(221, 43);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // labelDatabase
            // 
            this.labelDatabase.AutoSize = true;
            this.labelDatabase.Location = new System.Drawing.Point(52, 147);
            this.labelDatabase.Name = "labelDatabase";
            this.labelDatabase.Size = new System.Drawing.Size(116, 25);
            this.labelDatabase.TabIndex = 3;
            this.labelDatabase.Text = "Database: ";
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(167, 54);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(342, 31);
            this.tbUsername.TabIndex = 4;
            // 
            // tbDatabse
            // 
            this.tbDatabse.Location = new System.Drawing.Point(167, 141);
            this.tbDatabse.Name = "tbDatabse";
            this.tbDatabse.Size = new System.Drawing.Size(342, 31);
            this.tbDatabse.TabIndex = 5;
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(167, 98);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(342, 31);
            this.tbPassword.TabIndex = 6;
            // 
            // dataGridViewPlayer
            // 
            this.dataGridViewPlayer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPlayer.Location = new System.Drawing.Point(43, 270);
            this.dataGridViewPlayer.Name = "dataGridViewPlayer";
            this.dataGridViewPlayer.RowHeadersWidth = 82;
            this.dataGridViewPlayer.RowTemplate.Height = 33;
            this.dataGridViewPlayer.Size = new System.Drawing.Size(1488, 653);
            this.dataGridViewPlayer.TabIndex = 7;
            // 
            // tbNama
            // 
            this.tbNama.Location = new System.Drawing.Point(791, 98);
            this.tbNama.Name = "tbNama";
            this.tbNama.Size = new System.Drawing.Size(342, 31);
            this.tbNama.TabIndex = 14;
            // 
            // tbKota
            // 
            this.tbKota.Location = new System.Drawing.Point(791, 141);
            this.tbKota.Name = "tbKota";
            this.tbKota.Size = new System.Drawing.Size(342, 31);
            this.tbKota.TabIndex = 13;
            // 
            // tbNIM
            // 
            this.tbNIM.Location = new System.Drawing.Point(791, 54);
            this.tbNIM.Name = "tbNIM";
            this.tbNIM.Size = new System.Drawing.Size(342, 31);
            this.tbNIM.TabIndex = 12;
            // 
            // labelKota
            // 
            this.labelKota.AutoSize = true;
            this.labelKota.Location = new System.Drawing.Point(676, 147);
            this.labelKota.Name = "labelKota";
            this.labelKota.Size = new System.Drawing.Size(116, 25);
            this.labelKota.TabIndex = 11;
            this.labelKota.Text = "Kota Asal: ";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(863, 205);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(221, 43);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // labelNama
            // 
            this.labelNama.AutoSize = true;
            this.labelNama.Location = new System.Drawing.Point(676, 101);
            this.labelNama.Name = "labelNama";
            this.labelNama.Size = new System.Drawing.Size(80, 25);
            this.labelNama.TabIndex = 9;
            this.labelNama.Text = "Nama: ";
            // 
            // labelNIM
            // 
            this.labelNIM.AutoSize = true;
            this.labelNIM.Location = new System.Drawing.Point(676, 57);
            this.labelNIM.Name = "labelNIM";
            this.labelNIM.Size = new System.Drawing.Size(62, 25);
            this.labelNIM.TabIndex = 8;
            this.labelNIM.Text = "NIM: ";
            // 
            // dataGridViewMahasiswa
            // 
            this.dataGridViewMahasiswa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMahasiswa.Location = new System.Drawing.Point(1569, 276);
            this.dataGridViewMahasiswa.Name = "dataGridViewMahasiswa";
            this.dataGridViewMahasiswa.RowHeadersWidth = 82;
            this.dataGridViewMahasiswa.RowTemplate.Height = 33;
            this.dataGridViewMahasiswa.Size = new System.Drawing.Size(974, 646);
            this.dataGridViewMahasiswa.TabIndex = 15;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(1162, 53);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(118, 119);
            this.btnRefresh.TabIndex = 16;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2581, 955);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dataGridViewMahasiswa);
            this.Controls.Add(this.tbNama);
            this.Controls.Add(this.tbKota);
            this.Controls.Add(this.tbNIM);
            this.Controls.Add(this.labelKota);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.labelNama);
            this.Controls.Add(this.labelNIM);
            this.Controls.Add(this.dataGridViewPlayer);
            this.Controls.Add(this.tbPassword);
            this.Controls.Add(this.tbDatabse);
            this.Controls.Add(this.tbUsername);
            this.Controls.Add(this.labelDatabase);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelUsername);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMahasiswa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label labelDatabase;
        private System.Windows.Forms.TextBox tbUsername;
        private System.Windows.Forms.TextBox tbDatabse;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.DataGridView dataGridViewPlayer;
        private System.Windows.Forms.TextBox tbNama;
        private System.Windows.Forms.TextBox tbKota;
        private System.Windows.Forms.TextBox tbNIM;
        private System.Windows.Forms.Label labelKota;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label labelNama;
        private System.Windows.Forms.Label labelNIM;
        private System.Windows.Forms.DataGridView dataGridViewMahasiswa;
        private System.Windows.Forms.Button btnRefresh;
    }
}

