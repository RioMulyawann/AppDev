﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection MySqlConnection;
        MySqlCommand MySqlCommand;
        MySqlDataAdapter MySqlDataAdapter;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
           
            
                string username = tbUsername.Text;
                string password = tbPassword.Text;
            string database = tbDatabse.Text;

            MySqlConnection = new MySqlConnection($"server=10.10.10.136;uid={username};pwd={password};database={database};");
            MySqlConnection.Open();
            MessageBox.Show("Yey");
            MySqlConnection.Close();
            string sqlquery = "SELECT * FROM player;";
            MySqlCommand = new MySqlCommand(sqlquery, MySqlConnection);
            MySqlDataAdapter =new MySqlDataAdapter(MySqlCommand);
            DataTable dtplayer = new DataTable();
            MySqlDataAdapter.Fill(dtplayer);
            dataGridViewPlayer.DataSource = dtplayer;

           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string insertdata = $"INSERT INTO mahasiswa(nim_mahasiswa,nama_mahasiswa,kota_asal)" +
               $"VALUES('{tbNIM.Text}','{tbNama.Text}','{tbKota.Text}')";
            MySqlCommand = new MySqlCommand(insertdata, MySqlConnection);
            MySqlConnection.Open();
            MySqlCommand.ExecuteNonQuery();
            MySqlConnection.Close();
            string sqlquery = "SELECT * FROM mahasiswa;";
            MySqlCommand = new MySqlCommand(sqlquery, MySqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
            DataTable dtmahasiswa = new DataTable();
            MySqlDataAdapter.Fill(dtmahasiswa);
            dataGridViewMahasiswa.DataSource = dtmahasiswa;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string sqlquery = "SELECT * FROM mahasiswa;";
            MySqlCommand = new MySqlCommand(sqlquery, MySqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
            DataTable dtmahasiswa = new DataTable();
            MySqlDataAdapter.Fill(dtmahasiswa);
            dataGridViewMahasiswa.DataSource = dtmahasiswa;
        }
    }
}
