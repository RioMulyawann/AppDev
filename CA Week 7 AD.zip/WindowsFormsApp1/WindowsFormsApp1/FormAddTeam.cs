﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
   
    public partial class FormAddTeam : Form
    {
        FormSchedule form1;
        public FormAddTeam(FormSchedule _form)
        {
            InitializeComponent();
            form1 = (FormSchedule) _form;
            
        }
        List<string> teamlist = new List<string>();
        public void ambildataTeam(List<string> _team)
        {
            
            
            foreach(string a in _team)
            {
                teamlist.Add(a);
            }
        }

        private void FormAddTeam_Load(object sender, EventArgs e)
        {
            
        }

        private void btnAddTeamform2_Click(object sender, EventArgs e)
        {
            bool checker = true;
            if (teamlist.Contains(tboxTeamName.Text))
            {
                MessageBox.Show("Team Already Found");
                checker = false;
            }
            if (checker == true)
            {
                form1.ambilAddTeam(tboxTeamName.Text);
                this.Close();
            }
        }
    }
}
