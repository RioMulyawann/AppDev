﻿namespace WindowsFormsApp1
{
    partial class FormAddTeam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tboxTeamName = new System.Windows.Forms.TextBox();
            this.labelTeamName = new System.Windows.Forms.Label();
            this.btnAddTeamform2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tboxTeamName
            // 
            this.tboxTeamName.Location = new System.Drawing.Point(257, 124);
            this.tboxTeamName.Name = "tboxTeamName";
            this.tboxTeamName.Size = new System.Drawing.Size(408, 31);
            this.tboxTeamName.TabIndex = 0;
            // 
            // labelTeamName
            // 
            this.labelTeamName.AutoSize = true;
            this.labelTeamName.Location = new System.Drawing.Point(80, 119);
            this.labelTeamName.Name = "labelTeamName";
            this.labelTeamName.Size = new System.Drawing.Size(140, 25);
            this.labelTeamName.TabIndex = 1;
            this.labelTeamName.Text = "Team Name: ";
            // 
            // btnAddTeamform2
            // 
            this.btnAddTeamform2.Location = new System.Drawing.Point(404, 180);
            this.btnAddTeamform2.Name = "btnAddTeamform2";
            this.btnAddTeamform2.Size = new System.Drawing.Size(128, 46);
            this.btnAddTeamform2.TabIndex = 2;
            this.btnAddTeamform2.Text = "Add";
            this.btnAddTeamform2.UseVisualStyleBackColor = true;
            this.btnAddTeamform2.Click += new System.EventHandler(this.btnAddTeamform2_Click);
            // 
            // FormAddTeam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 482);
            this.Controls.Add(this.btnAddTeamform2);
            this.Controls.Add(this.labelTeamName);
            this.Controls.Add(this.tboxTeamName);
            this.Name = "FormAddTeam";
            this.Text = "FormAddTeam";
            this.Load += new System.EventHandler(this.FormAddTeam_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tboxTeamName;
        private System.Windows.Forms.Label labelTeamName;
        private System.Windows.Forms.Button btnAddTeamform2;
    }
}