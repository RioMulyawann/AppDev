﻿namespace WindowsFormsApp1
{
    partial class FormSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridSchedule = new System.Windows.Forms.DataGridView();
            this.labelTitle = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cbHomeTeam = new System.Windows.Forms.ComboBox();
            this.cbAwayTeam = new System.Windows.Forms.ComboBox();
            this.tbHomeScore = new System.Windows.Forms.TextBox();
            this.tbAwayScore = new System.Windows.Forms.TextBox();
            this.labelVersus = new System.Windows.Forms.Label();
            this.btnAddMatch = new System.Windows.Forms.Button();
            this.btnAddTeam = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSchedule)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridSchedule
            // 
            this.dataGridSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridSchedule.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridSchedule.Location = new System.Drawing.Point(192, 102);
            this.dataGridSchedule.Name = "dataGridSchedule";
            this.dataGridSchedule.RowHeadersWidth = 82;
            this.dataGridSchedule.RowTemplate.Height = 33;
            this.dataGridSchedule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridSchedule.Size = new System.Drawing.Size(1395, 545);
            this.dataGridSchedule.TabIndex = 0;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Impact", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.Red;
            this.labelTitle.Location = new System.Drawing.Point(737, 19);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(375, 65);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "NBA\'s Schedule";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(663, 668);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(468, 31);
            this.dateTimePicker.TabIndex = 2;
            // 
            // cbHomeTeam
            // 
            this.cbHomeTeam.FormattingEnabled = true;
            this.cbHomeTeam.Location = new System.Drawing.Point(663, 718);
            this.cbHomeTeam.Name = "cbHomeTeam";
            this.cbHomeTeam.Size = new System.Drawing.Size(178, 33);
            this.cbHomeTeam.TabIndex = 3;
            this.cbHomeTeam.SelectedIndexChanged += new System.EventHandler(this.cbHomeTeam_SelectedIndexChanged);
            // 
            // cbAwayTeam
            // 
            this.cbAwayTeam.FormattingEnabled = true;
            this.cbAwayTeam.Location = new System.Drawing.Point(953, 718);
            this.cbAwayTeam.Name = "cbAwayTeam";
            this.cbAwayTeam.Size = new System.Drawing.Size(178, 33);
            this.cbAwayTeam.TabIndex = 4;
            this.cbAwayTeam.SelectedIndexChanged += new System.EventHandler(this.cbAwayTeam_SelectedIndexChanged);
            // 
            // tbHomeScore
            // 
            this.tbHomeScore.Location = new System.Drawing.Point(663, 782);
            this.tbHomeScore.Name = "tbHomeScore";
            this.tbHomeScore.Size = new System.Drawing.Size(178, 31);
            this.tbHomeScore.TabIndex = 5;
            this.tbHomeScore.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbHomeScore_KeyPress);
            // 
            // tbAwayScore
            // 
            this.tbAwayScore.Location = new System.Drawing.Point(953, 782);
            this.tbAwayScore.Name = "tbAwayScore";
            this.tbAwayScore.Size = new System.Drawing.Size(178, 31);
            this.tbAwayScore.TabIndex = 6;
            this.tbAwayScore.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbAwayScore_KeyPress);
            // 
            // labelVersus
            // 
            this.labelVersus.AutoSize = true;
            this.labelVersus.Location = new System.Drawing.Point(880, 726);
            this.labelVersus.Name = "labelVersus";
            this.labelVersus.Size = new System.Drawing.Size(34, 25);
            this.labelVersus.TabIndex = 7;
            this.labelVersus.Text = "vs";
            // 
            // btnAddMatch
            // 
            this.btnAddMatch.Location = new System.Drawing.Point(687, 829);
            this.btnAddMatch.Name = "btnAddMatch";
            this.btnAddMatch.Size = new System.Drawing.Size(129, 44);
            this.btnAddMatch.TabIndex = 8;
            this.btnAddMatch.Text = "Add Match";
            this.btnAddMatch.UseVisualStyleBackColor = true;
            this.btnAddMatch.Click += new System.EventHandler(this.btnAddMatch_Click);
            // 
            // btnAddTeam
            // 
            this.btnAddTeam.Location = new System.Drawing.Point(983, 829);
            this.btnAddTeam.Name = "btnAddTeam";
            this.btnAddTeam.Size = new System.Drawing.Size(129, 44);
            this.btnAddTeam.TabIndex = 9;
            this.btnAddTeam.Text = "Add Team";
            this.btnAddTeam.UseVisualStyleBackColor = true;
            this.btnAddTeam.Click += new System.EventHandler(this.btnAddTeam_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(192, 668);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(210, 80);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // FormSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1797, 1327);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAddTeam);
            this.Controls.Add(this.btnAddMatch);
            this.Controls.Add(this.labelVersus);
            this.Controls.Add(this.tbAwayScore);
            this.Controls.Add(this.tbHomeScore);
            this.Controls.Add(this.cbAwayTeam);
            this.Controls.Add(this.cbHomeTeam);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.dataGridSchedule);
            this.Name = "FormSchedule";
            this.Text = "NBA SCHEDULE";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSchedule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridSchedule;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.ComboBox cbHomeTeam;
        private System.Windows.Forms.ComboBox cbAwayTeam;
        private System.Windows.Forms.TextBox tbHomeScore;
        private System.Windows.Forms.TextBox tbAwayScore;
        private System.Windows.Forms.Label labelVersus;
        private System.Windows.Forms.Button btnAddMatch;
        private System.Windows.Forms.Button btnAddTeam;
        private System.Windows.Forms.Button btnDelete;
    }
}

