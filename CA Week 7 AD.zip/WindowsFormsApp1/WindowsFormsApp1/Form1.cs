﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormSchedule : Form
    {
        DataTable TeamsView;
        FormAddTeam form2;
        public FormSchedule()
        {
            InitializeComponent();
            
        }
        List<string> Teams = new List<string>();
        string temp1 = "";
        string temp2 = "";
        private void Form1_Load(object sender, EventArgs e)
        {
            TeamsView = new DataTable();
            TeamsView.Columns.Add("Date");
            TeamsView.Columns.Add("Home Team Name");
            TeamsView.Columns.Add("Home Score");
            TeamsView.Columns.Add("Away Score");
            TeamsView.Columns.Add("Away Team Name");
            

            Teams.Add("Chicago Bulls");
            Teams.Add("Cleveland Cavaliers");
            Teams.Add("Brooklyn Nets");
            Teams.Add("Detroit Pistons");
            Teams.Add("Boston Celtics");
            Teams.Add("Golden State Warriors");
            Teams.Add("LA Clippers");
            Teams.Add("Miami Heat");
            Teams.Add("Atlanta Hawks");
            Teams.Add("Houston Rockets");
            foreach (string name in Teams)
            {
                cbAwayTeam.Items.Add(name);
                cbHomeTeam.Items.Add(name);
            }
            
            string date = dateTimePicker.Value.ToString();
            dataGridSchedule.DataSource = TeamsView;
            
        }

        private void btnAddTeam_Click(object sender, EventArgs e)
        {
            form2 = new FormAddTeam(this);
            form2.ambildataTeam(Teams);
  
            form2.ShowDialog();
        }
        public void ambilAddTeam(string _teamname)
        {
            Teams.Add(_teamname);
            cbAwayTeam.Items.Add(_teamname);
            cbHomeTeam.Items.Add(_teamname);

        }

        private void btnAddMatch_Click(object sender, EventArgs e)
        {
            TeamsView.Rows.Add(dateTimePicker.Value.ToString(),cbHomeTeam.SelectedItem.ToString(),tbHomeScore.Text.ToString(),tbAwayScore.Text.ToString(),cbAwayTeam.SelectedItem.ToString());
        }

        

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            int index = 0;
            foreach (DataGridViewRow row in dataGridSchedule.SelectedRows)
            {
                index = row.Index;
            }
            TeamsView.Rows.RemoveAt(index);
        }

        private void cbHomeTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cbAwayTeam.Text))
            {
                cbAwayTeam.Items.Add(temp2);
            }
            cbAwayTeam.Items.Remove(cbHomeTeam.SelectedItem.ToString());
            temp2 = cbHomeTeam.SelectedItem.ToString();
        }

        private void cbAwayTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cbHomeTeam.Text))
            {
                cbHomeTeam.Items.Add(temp1);
            }
            cbHomeTeam.Items.Remove(cbAwayTeam.SelectedItem.ToString());
            temp1 = cbAwayTeam.SelectedItem.ToString();
        }

        private void tbHomeScore_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled= true;
            }
        }


        private void tbAwayScore_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
