﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTeam = new System.Windows.Forms.Label();
            this.cbteam = new System.Windows.Forms.ComboBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.lblplayer = new System.Windows.Forms.Label();
            this.cboxPlayer = new System.Windows.Forms.ComboBox();
            this.labelType = new System.Windows.Forms.Label();
            this.labelminute = new System.Windows.Forms.Label();
            this.cboxtype = new System.Windows.Forms.ComboBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.tboxMinute = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.Location = new System.Drawing.Point(248, 158);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(78, 25);
            this.lblTeam.TabIndex = 0;
            this.lblTeam.Text = "Team: ";
            // 
            // cbteam
            // 
            this.cbteam.FormattingEnabled = true;
            this.cbteam.Location = new System.Drawing.Point(332, 155);
            this.cbteam.Name = "cbteam";
            this.cbteam.Size = new System.Drawing.Size(396, 33);
            this.cbteam.TabIndex = 1;
            this.cbteam.SelectedIndexChanged += new System.EventHandler(this.cbteam_SelectedIndexChanged);
            // 
            // dataGridView
            // 
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(253, 251);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 82;
            this.dataGridView.RowTemplate.Height = 33;
            this.dataGridView.Size = new System.Drawing.Size(1757, 956);
            this.dataGridView.TabIndex = 2;
            this.dataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellContentClick);
            // 
            // lblplayer
            // 
            this.lblplayer.AutoSize = true;
            this.lblplayer.Location = new System.Drawing.Point(765, 158);
            this.lblplayer.Name = "lblplayer";
            this.lblplayer.Size = new System.Drawing.Size(85, 25);
            this.lblplayer.TabIndex = 3;
            this.lblplayer.Text = "Player: ";
            // 
            // cboxPlayer
            // 
            this.cboxPlayer.FormattingEnabled = true;
            this.cboxPlayer.Location = new System.Drawing.Point(849, 158);
            this.cboxPlayer.Name = "cboxPlayer";
            this.cboxPlayer.Size = new System.Drawing.Size(396, 33);
            this.cboxPlayer.TabIndex = 4;
            this.cboxPlayer.SelectedIndexChanged += new System.EventHandler(this.cboxPlayer_SelectedIndexChanged);
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(1303, 161);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(66, 25);
            this.labelType.TabIndex = 5;
            this.labelType.Text = "Type:";
            this.labelType.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelminute
            // 
            this.labelminute.AutoSize = true;
            this.labelminute.Location = new System.Drawing.Point(1660, 161);
            this.labelminute.Name = "labelminute";
            this.labelminute.Size = new System.Drawing.Size(83, 25);
            this.labelminute.TabIndex = 6;
            this.labelminute.Text = "Minute:\r\n";
            // 
            // cboxtype
            // 
            this.cboxtype.FormattingEnabled = true;
            this.cboxtype.Location = new System.Drawing.Point(1379, 158);
            this.cboxtype.Name = "cboxtype";
            this.cboxtype.Size = new System.Drawing.Size(212, 33);
            this.cboxtype.TabIndex = 8;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(1803, 95);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(207, 42);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // tboxMinute
            // 
            this.tboxMinute.Location = new System.Drawing.Point(1761, 160);
            this.tboxMinute.Name = "tboxMinute";
            this.tboxMinute.Size = new System.Drawing.Size(249, 31);
            this.tboxMinute.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2321, 1459);
            this.Controls.Add(this.tboxMinute);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.cboxtype);
            this.Controls.Add(this.labelminute);
            this.Controls.Add(this.labelType);
            this.Controls.Add(this.cboxPlayer);
            this.Controls.Add(this.lblplayer);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.cbteam);
            this.Controls.Add(this.lblTeam);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.ComboBox cbteam;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Label lblplayer;
        private System.Windows.Forms.ComboBox cboxPlayer;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelminute;
        private System.Windows.Forms.ComboBox cboxtype;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox tboxMinute;
    }
}

