﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_name = new System.Windows.Forms.Label();
            this.label_age = new System.Windows.Forms.Label();
            this.label_gender = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.tb_age = new System.Windows.Forms.TextBox();
            this.radiobutton_male = new System.Windows.Forms.RadioButton();
            this.radiobutton_female = new System.Windows.Forms.RadioButton();
            this.label_FavColor = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rb_FavOrange = new System.Windows.Forms.RadioButton();
            this.rb_FavPurple = new System.Windows.Forms.RadioButton();
            this.rb_FavRed = new System.Windows.Forms.RadioButton();
            this.label_hobby = new System.Windows.Forms.Label();
            this.cb_reading = new System.Windows.Forms.CheckBox();
            this.cb_watchingTV = new System.Windows.Forms.CheckBox();
            this.cb_playingSports = new System.Windows.Forms.CheckBox();
            this.cb_others = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tb_others = new System.Windows.Forms.TextBox();
            this.btn_submit = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(114, 90);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(35, 13);
            this.label_name.TabIndex = 0;
            this.label_name.Text = "Name";
            // 
            // label_age
            // 
            this.label_age.AutoSize = true;
            this.label_age.Location = new System.Drawing.Point(114, 113);
            this.label_age.Name = "label_age";
            this.label_age.Size = new System.Drawing.Size(26, 13);
            this.label_age.TabIndex = 1;
            this.label_age.Text = "Age";
            // 
            // label_gender
            // 
            this.label_gender.AutoSize = true;
            this.label_gender.Location = new System.Drawing.Point(4, 16);
            this.label_gender.Name = "label_gender";
            this.label_gender.Size = new System.Drawing.Size(42, 13);
            this.label_gender.TabIndex = 2;
            this.label_gender.Text = "Gender";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(155, 87);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(137, 20);
            this.tb_name.TabIndex = 3;
            this.tb_name.TextChanged += new System.EventHandler(this.tb_input_TextChanged);
            // 
            // tb_age
            // 
            this.tb_age.Location = new System.Drawing.Point(155, 110);
            this.tb_age.Name = "tb_age";
            this.tb_age.Size = new System.Drawing.Size(137, 20);
            this.tb_age.TabIndex = 4;
            // 
            // radiobutton_male
            // 
            this.radiobutton_male.AutoSize = true;
            this.radiobutton_male.Location = new System.Drawing.Point(3, 32);
            this.radiobutton_male.Name = "radiobutton_male";
            this.radiobutton_male.Size = new System.Drawing.Size(48, 17);
            this.radiobutton_male.TabIndex = 5;
            this.radiobutton_male.TabStop = true;
            this.radiobutton_male.Text = "Male";
            this.radiobutton_male.UseVisualStyleBackColor = true;
            // 
            // radiobutton_female
            // 
            this.radiobutton_female.AutoSize = true;
            this.radiobutton_female.Location = new System.Drawing.Point(74, 32);
            this.radiobutton_female.Name = "radiobutton_female";
            this.radiobutton_female.Size = new System.Drawing.Size(59, 17);
            this.radiobutton_female.TabIndex = 6;
            this.radiobutton_female.TabStop = true;
            this.radiobutton_female.Text = "Female";
            this.radiobutton_female.UseVisualStyleBackColor = true;
            // 
            // label_FavColor
            // 
            this.label_FavColor.AutoSize = true;
            this.label_FavColor.Location = new System.Drawing.Point(3, 11);
            this.label_FavColor.Name = "label_FavColor";
            this.label_FavColor.Size = new System.Drawing.Size(72, 13);
            this.label_FavColor.TabIndex = 7;
            this.label_FavColor.Text = "Favorite Color";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radiobutton_male);
            this.panel1.Controls.Add(this.radiobutton_female);
            this.panel1.Controls.Add(this.label_gender);
            this.panel1.Location = new System.Drawing.Point(111, 136);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(136, 52);
            this.panel1.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rb_FavOrange);
            this.panel2.Controls.Add(this.rb_FavPurple);
            this.panel2.Controls.Add(this.rb_FavRed);
            this.panel2.Controls.Add(this.label_FavColor);
            this.panel2.Location = new System.Drawing.Point(111, 191);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(232, 58);
            this.panel2.TabIndex = 9;
            // 
            // rb_FavOrange
            // 
            this.rb_FavOrange.AutoSize = true;
            this.rb_FavOrange.Location = new System.Drawing.Point(148, 27);
            this.rb_FavOrange.Name = "rb_FavOrange";
            this.rb_FavOrange.Size = new System.Drawing.Size(60, 17);
            this.rb_FavOrange.TabIndex = 10;
            this.rb_FavOrange.TabStop = true;
            this.rb_FavOrange.Text = "Orange";
            this.rb_FavOrange.UseVisualStyleBackColor = true;
            // 
            // rb_FavPurple
            // 
            this.rb_FavPurple.AutoSize = true;
            this.rb_FavPurple.Location = new System.Drawing.Point(74, 27);
            this.rb_FavPurple.Name = "rb_FavPurple";
            this.rb_FavPurple.Size = new System.Drawing.Size(55, 17);
            this.rb_FavPurple.TabIndex = 9;
            this.rb_FavPurple.TabStop = true;
            this.rb_FavPurple.Text = "Purple";
            this.rb_FavPurple.UseVisualStyleBackColor = true;
            // 
            // rb_FavRed
            // 
            this.rb_FavRed.AutoSize = true;
            this.rb_FavRed.Location = new System.Drawing.Point(3, 27);
            this.rb_FavRed.Name = "rb_FavRed";
            this.rb_FavRed.Size = new System.Drawing.Size(45, 17);
            this.rb_FavRed.TabIndex = 8;
            this.rb_FavRed.TabStop = true;
            this.rb_FavRed.Text = "Red";
            this.rb_FavRed.UseVisualStyleBackColor = true;
            // 
            // label_hobby
            // 
            this.label_hobby.AutoSize = true;
            this.label_hobby.Location = new System.Drawing.Point(111, 252);
            this.label_hobby.Name = "label_hobby";
            this.label_hobby.Size = new System.Drawing.Size(46, 13);
            this.label_hobby.TabIndex = 10;
            this.label_hobby.Text = "Hobbies";
            // 
            // cb_reading
            // 
            this.cb_reading.AutoSize = true;
            this.cb_reading.Location = new System.Drawing.Point(114, 279);
            this.cb_reading.Name = "cb_reading";
            this.cb_reading.Size = new System.Drawing.Size(66, 17);
            this.cb_reading.TabIndex = 11;
            this.cb_reading.Text = "Reading";
            this.cb_reading.UseVisualStyleBackColor = true;
            // 
            // cb_watchingTV
            // 
            this.cb_watchingTV.AutoSize = true;
            this.cb_watchingTV.Location = new System.Drawing.Point(200, 279);
            this.cb_watchingTV.Name = "cb_watchingTV";
            this.cb_watchingTV.Size = new System.Drawing.Size(89, 17);
            this.cb_watchingTV.TabIndex = 12;
            this.cb_watchingTV.Text = "Watching TV";
            this.cb_watchingTV.UseVisualStyleBackColor = true;
            // 
            // cb_playingSports
            // 
            this.cb_playingSports.AutoSize = true;
            this.cb_playingSports.Location = new System.Drawing.Point(295, 279);
            this.cb_playingSports.Name = "cb_playingSports";
            this.cb_playingSports.Size = new System.Drawing.Size(93, 17);
            this.cb_playingSports.TabIndex = 13;
            this.cb_playingSports.Text = "Playing Sports";
            this.cb_playingSports.UseVisualStyleBackColor = true;
            // 
            // cb_others
            // 
            this.cb_others.AutoSize = true;
            this.cb_others.Location = new System.Drawing.Point(3, 3);
            this.cb_others.Name = "cb_others";
            this.cb_others.Size = new System.Drawing.Size(57, 17);
            this.cb_others.TabIndex = 14;
            this.cb_others.Text = "Others";
            this.cb_others.UseVisualStyleBackColor = true;
            this.cb_others.CheckedChanged += new System.EventHandler(this.cb_others_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tb_others);
            this.panel3.Controls.Add(this.cb_others);
            this.panel3.Location = new System.Drawing.Point(390, 276);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 22);
            this.panel3.TabIndex = 15;
            // 
            // tb_others
            // 
            this.tb_others.Location = new System.Drawing.Point(65, 1);
            this.tb_others.Name = "tb_others";
            this.tb_others.Size = new System.Drawing.Size(111, 20);
            this.tb_others.TabIndex = 15;
            this.tb_others.Visible = false;
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(313, 350);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(122, 30);
            this.btn_submit.TabIndex = 16;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(109, 302);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(71, 21);
            this.btn_clear.TabIndex = 17;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.cb_playingSports);
            this.Controls.Add(this.cb_watchingTV);
            this.Controls.Add(this.cb_reading);
            this.Controls.Add(this.label_hobby);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tb_age);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.label_age);
            this.Controls.Add(this.label_name);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.tb_input_TextChanged);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_age;
        private System.Windows.Forms.Label label_gender;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.TextBox tb_age;
        private System.Windows.Forms.RadioButton radiobutton_male;
        private System.Windows.Forms.RadioButton radiobutton_female;
        private System.Windows.Forms.Label label_FavColor;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rb_FavOrange;
        private System.Windows.Forms.RadioButton rb_FavPurple;
        private System.Windows.Forms.RadioButton rb_FavRed;
        private System.Windows.Forms.Label label_hobby;
        private System.Windows.Forms.CheckBox cb_reading;
        private System.Windows.Forms.CheckBox cb_watchingTV;
        private System.Windows.Forms.CheckBox cb_playingSports;
        private System.Windows.Forms.CheckBox cb_others;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tb_others;
        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.Button btn_clear;
    }
}

