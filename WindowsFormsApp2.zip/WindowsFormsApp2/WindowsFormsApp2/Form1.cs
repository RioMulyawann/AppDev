﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        DataTable dt_team;
        DataTable dt_player;
        DataTable dt_kejadian;
        DataTable dt_type;
        DataTable dt = new DataTable();
        MySqlConnection connect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league;");
        MySqlCommand command;
        MySqlDataAdapter adapter;

        public Form1()
        {
            InitializeComponent();
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dt_team = new DataTable();
           
            
            string query = "SELECT * FROM team;";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt_team);
           
            
            cbteam.DataSource = dt_team;
            cbteam.ValueMember = "team_id";
            cbteam.DisplayMember = "team_name";
            
            dt_type = new DataTable();
            string querytype = "SELECT IF(type = 'CY','Yellow Card',IF(type = 'CR','Red Card',IF(type = 'PM','Penalty Missed',IF(type = 'GO','Goal',IF(type = 'GP','Goal Penalty','Own Goal'))))) AS `Nama` , type FROM dmatch GROUP BY type;";
            command = new MySqlCommand(querytype, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt_type);
            cboxtype.DataSource = dt_type;
            cboxtype.DisplayMember = "Nama";
            cboxtype.ValueMember = "type";
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team ID");
            dt.Columns.Add("Player ID");
            dt.Columns.Add("Type");



        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbteam_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            dt_player = new DataTable();
            
            string queryplayer = $"SELECT player_name AS `Nama Pemain` , player_id FROM player WHERE player.team_id = '{cbteam.SelectedValue}' AND player.status = '1';";
            command = new MySqlCommand(queryplayer, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt_player);
            cboxPlayer.DataSource = dt_player;
            cboxPlayer.DisplayMember = "Nama Pemain";
            cboxPlayer.ValueMember = "player_id";
           
            
        }

        private void cboxPlayer_SelectedIndexChanged(object sender, EventArgs e)
        {
            dt_kejadian = new DataTable();
            
            string querykejadian = $"SELECT * FROM dmatch WHERE player_id = '{cboxPlayer.SelectedValue}';";
            command = new MySqlCommand(querykejadian, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt_kejadian);
         
          
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
           
         
            dt.Rows.Add(tboxMinute.Text.ToString(), cbteam.SelectedValue.ToString(), cboxPlayer.SelectedValue.ToString(), cboxtype.SelectedValue.ToString());
            dataGridView.DataSource = dt;
        }
    }
}
