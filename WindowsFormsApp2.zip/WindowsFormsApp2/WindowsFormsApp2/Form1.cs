﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }

        List<string> hobbies = new List<string>();
        private void tb_input_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            
            string name = tb_name.Text;
            string age = tb_age.Text;
            string gender = "";
            string texthobby = "";
            if (radiobutton_male.Checked)
            {
                gender = "Male";
            }
            else if (radiobutton_female.Checked)
            {
                gender = "Female";
            }

            if (rb_FavOrange.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (rb_FavPurple.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (rb_FavRed.Checked)
            {
                this.BackColor = Color.Red;
            }

            if (cb_reading.Checked)
            {
                hobbies.Add("Reading");
            }

            if (cb_watchingTV.Checked)
            {
                hobbies.Add("Watching TV");
            }

            if (cb_playingSports.Checked)
            {
                hobbies.Add("Playing Sports");
            }

            if (cb_others.Checked)
            {
                
                hobbies.Add(tb_others.Text);

            }
            for (int i = 0; i < hobbies.Count; i++)
            {
                texthobby += hobbies[i];
                if (i != hobbies.Count - 1)
                {
                    texthobby += ", ";
                }
                
               
            }
            string number = "1234567890";
            string alphabeth = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
            bool sistem1 = true;
            bool sistem2 = true; 
            foreach (char a in alphabeth)
            {
                if (age.Contains(a))
                {
                    sistem1 = false;
                }


            }
            foreach (char b in number)
            {
                if (name.Contains(b) || texthobby.Contains(b))
                {
                    sistem2 = false;
                }
               

            }
           
            if (sistem1 == true && sistem2 == true)
            {
                MessageBox.Show($"Name: {name} \nAge: {age} \nGender: {gender} \nHobbies: {texthobby}");
            }
            else
            {
                MessageBox.Show("Textbox has incorrect input");
            }
           
            }

        private void cb_others_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_others.Checked)
            {
                tb_others.Visible = true;
            }
            if (!cb_others.Checked)
            {
                tb_others.Visible = false;
            }
            
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            tb_name.Text = string.Empty;
            tb_age.Text = string.Empty;
            radiobutton_male.Checked = false;
            radiobutton_female.Checked= false;
            rb_FavOrange.Checked = false;
            rb_FavPurple.Checked = false;
            rb_FavRed.Checked = false;
            cb_others.Checked = false;
            cb_playingSports.Checked = false;
            cb_reading.Checked = false;
            cb_watchingTV.Checked = false;
            tb_others.Visible=false;
            this.BackColor = Color.White;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
