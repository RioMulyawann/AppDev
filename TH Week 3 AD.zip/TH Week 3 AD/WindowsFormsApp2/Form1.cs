﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        int account = 0;
        List<string> Username = new List<string>();
        List<string> Password = new List<string>();
        List<int> Saldo = new List<int>();
        

        
        public Form1()
        {
            InitializeComponent();
           
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            panelLoginView.Visible = false;
            panelRegistrationPage.Visible = true;
               
            
         
               
            
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
            bool Login = false;
            int count = 0;
            foreach (string x in Username)
            {
                if (tboxUsernameLog.Text == x)
                {
                    account = count;
                    Login = true;
                }
                count++;
            }
            if (Login == false)
            {
                MessageBox.Show("Account not found.");
                tboxUsernameLog.Clear();
                tboxPasswordLog.Clear();
                return;
            }
            else
            {
                if (Password[account] != tboxPasswordLog.Text)
                {
                    Login = false;
                    MessageBox.Show("Wrong Password!");
                }
                tboxUsernameLog.Clear();
                tboxPasswordLog.Clear();
            }
            if (Login == true)
            {
                MessageBox.Show($"Welcome!!");
                panelLoginView.Visible = false;
               panelMainView.Visible = true;
                string saldo = Saldo[account].ToString("N0");
                labelSaldoMain.Text = "Rp. " + saldo + ",00";
                tboxUsernameLog.Clear();
                tboxPasswordLog.Clear();
            }

        }

        private void btnRegisterReg_Click(object sender, EventArgs e)
        {
            if (Username.Contains(tboxUsernameReg.Text))
            {
                MessageBox.Show("Username has been used, Try again...");
                tboxUsernameReg.Clear();
                tboxPasswordReg.Clear();
                return;
            }
            else if (tboxUsernameReg.Text == "")
            {
                MessageBox.Show("Error... Username can't be empty");
                tboxUsernameReg.Clear();
                tboxPasswordReg.Clear();
                return;
            }
            else
            {
                Username.Add(tboxUsernameReg.Text);
                Password.Add(tboxPasswordReg.Text);
                Saldo.Add(0);
                tboxUsernameReg.Clear();
                tboxPasswordReg.Clear();
                MessageBox.Show("Registration Successful!");
                panelRegistrationPage.Visible = false;
                panelLoginView.Visible = true;
            }

        }

        private void btnDepositMain_Click(object sender, EventArgs e)
        {
            panelMainView.Visible = false;
            panelDepositView.Visible = true;
        }

        private void btnDepositDep_Click(object sender, EventArgs e)
        {
            string deposits = tboxAmountDeposit.Text.Replace(".", "");
            if (int.TryParse(deposits, out int number))
            {
                int deposit = Convert.ToInt32(deposits);
                if (deposit <= 0)
                {
                    MessageBox.Show("Can't Deposit under Rp.1");
                }
                else
                {
                    Saldo[account] = Saldo[account] + deposit;
                    MessageBox.Show("Successfully Deposit Rp." + deposit.ToString("N0") + ",00");
                    tboxAmountDeposit.Clear();
                    labelSaldoMain.Text = "Rp." + Saldo[account].ToString("N0") + ",00";
                    panelMainView.Visible = true;
                    panelDepositView.Visible = false;
                }
            }
            else
            {
                MessageBox.Show("Error Input");
            }

        }

        private void btnWithdrawMain_Click(object sender, EventArgs e)
        {
            panelMainView.Visible = false;
            panelWithdrawView.Visible = true;
        }

        private void btnLogOutMain_Click(object sender, EventArgs e)
        {
            panelMainView.Visible = false;
            panelLoginView.Visible = true;
        }

        private void btnLogOutDep_Click(object sender, EventArgs e)
        {
            panelDepositView.Visible = false;
            panelLoginView.Visible = true;
        }

        private void btnLogOutWith_Click(object sender, EventArgs e)
        {
            panelWithdrawView.Visible = false;
            panelLoginView.Visible = true;
        }

        private void btnWithdrawWith_Click(object sender, EventArgs e)
        {
            
            string withdrawTemp = tboxAmountWithdraw.Text.Replace(".", "");
            if (int.TryParse(withdrawTemp, out int number))
            {
                int withdraw = Convert.ToInt32(withdrawTemp);
                if (Saldo[account] >= withdraw)
                {
                    Saldo[account] = Saldo[account] - withdraw;
                    MessageBox.Show("Withdraw Rp." + withdraw.ToString("N0") + ",00 Succeed");
                    tboxAmountWithdraw.Clear();
                    labelSaldoWith.Text = "Rp." + Saldo[account].ToString("N0") + ",00";
                    labelSaldoMain.Text = "Rp." + Saldo[account].ToString("N0") + ",00";
                    panelMainView.Visible = true;
                    panelWithdrawView.Visible = false;

                }
                else
                {
                    MessageBox.Show("Your Balance is not enough");
                }
            }
            else
            {
                MessageBox.Show("Error Input");
            }

        }
    }
}
