﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLoginView = new System.Windows.Forms.Panel();
            this.btnRegisterLog = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.tboxPasswordLog = new System.Windows.Forms.TextBox();
            this.tboxUsernameLog = new System.Windows.Forms.TextBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.labelUsername = new System.Windows.Forms.Label();
            this.LabelUCBank = new System.Windows.Forms.Label();
            this.panelRegistrationPage = new System.Windows.Forms.Panel();
            this.btnRegisterReg = new System.Windows.Forms.Button();
            this.tboxPasswordReg = new System.Windows.Forms.TextBox();
            this.tboxUsernameReg = new System.Windows.Forms.TextBox();
            this.labelPasswordReg = new System.Windows.Forms.Label();
            this.labelUsernameReg = new System.Windows.Forms.Label();
            this.labelUCBank2 = new System.Windows.Forms.Label();
            this.panelMainView = new System.Windows.Forms.Panel();
            this.btnWithdrawMain = new System.Windows.Forms.Button();
            this.labelSaldoMain = new System.Windows.Forms.Label();
            this.labelBalanceMain = new System.Windows.Forms.Label();
            this.labelUCBank3 = new System.Windows.Forms.Label();
            this.btnDepositMain = new System.Windows.Forms.Button();
            this.btnLogOutMain = new System.Windows.Forms.Button();
            this.panelDepositView = new System.Windows.Forms.Panel();
            this.btnLogOutDep = new System.Windows.Forms.Button();
            this.btnDepositDep = new System.Windows.Forms.Button();
            this.labelDepositTitle = new System.Windows.Forms.Label();
            this.labelUCBank4 = new System.Windows.Forms.Label();
            this.tboxAmountDeposit = new System.Windows.Forms.TextBox();
            this.panelWithdrawView = new System.Windows.Forms.Panel();
            this.btnLogOutWith = new System.Windows.Forms.Button();
            this.btnWithdrawWith = new System.Windows.Forms.Button();
            this.labelSaldoWith = new System.Windows.Forms.Label();
            this.labelBalanceWith = new System.Windows.Forms.Label();
            this.labelUCBank5 = new System.Windows.Forms.Label();
            this.tboxAmountWithdraw = new System.Windows.Forms.TextBox();
            this.labelWithdrawTitle = new System.Windows.Forms.Label();
            this.panelLoginView.SuspendLayout();
            this.panelRegistrationPage.SuspendLayout();
            this.panelMainView.SuspendLayout();
            this.panelDepositView.SuspendLayout();
            this.panelWithdrawView.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLoginView
            // 
            this.panelLoginView.Controls.Add(this.btnRegisterLog);
            this.panelLoginView.Controls.Add(this.btnLogin);
            this.panelLoginView.Controls.Add(this.tboxPasswordLog);
            this.panelLoginView.Controls.Add(this.tboxUsernameLog);
            this.panelLoginView.Controls.Add(this.labelPassword);
            this.panelLoginView.Controls.Add(this.labelUsername);
            this.panelLoginView.Controls.Add(this.LabelUCBank);
            this.panelLoginView.Location = new System.Drawing.Point(12, 12);
            this.panelLoginView.Name = "panelLoginView";
            this.panelLoginView.Size = new System.Drawing.Size(242, 223);
            this.panelLoginView.TabIndex = 0;
            // 
            // btnRegisterLog
            // 
            this.btnRegisterLog.Location = new System.Drawing.Point(84, 176);
            this.btnRegisterLog.Name = "btnRegisterLog";
            this.btnRegisterLog.Size = new System.Drawing.Size(75, 23);
            this.btnRegisterLog.TabIndex = 7;
            this.btnRegisterLog.Text = "Register";
            this.btnRegisterLog.UseVisualStyleBackColor = true;
            this.btnRegisterLog.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(84, 147);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 23);
            this.btnLogin.TabIndex = 6;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // tboxPasswordLog
            // 
            this.tboxPasswordLog.Location = new System.Drawing.Point(84, 110);
            this.tboxPasswordLog.Name = "tboxPasswordLog";
            this.tboxPasswordLog.Size = new System.Drawing.Size(119, 20);
            this.tboxPasswordLog.TabIndex = 5;
            // 
            // tboxUsernameLog
            // 
            this.tboxUsernameLog.Location = new System.Drawing.Point(84, 73);
            this.tboxUsernameLog.Name = "tboxUsernameLog";
            this.tboxUsernameLog.Size = new System.Drawing.Size(119, 20);
            this.tboxUsernameLog.TabIndex = 4;
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(21, 113);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(59, 13);
            this.labelPassword.TabIndex = 3;
            this.labelPassword.Text = "Password: ";
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.Location = new System.Drawing.Point(21, 76);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(61, 13);
            this.labelUsername.TabIndex = 2;
            this.labelUsername.Text = "Username: ";
            // 
            // LabelUCBank
            // 
            this.LabelUCBank.AutoSize = true;
            this.LabelUCBank.Font = new System.Drawing.Font("Goudy Stout", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelUCBank.Location = new System.Drawing.Point(19, 14);
            this.LabelUCBank.Name = "LabelUCBank";
            this.LabelUCBank.Size = new System.Drawing.Size(184, 28);
            this.LabelUCBank.TabIndex = 1;
            this.LabelUCBank.Text = "UC BANK";
            // 
            // panelRegistrationPage
            // 
            this.panelRegistrationPage.Controls.Add(this.btnRegisterReg);
            this.panelRegistrationPage.Controls.Add(this.tboxPasswordReg);
            this.panelRegistrationPage.Controls.Add(this.tboxUsernameReg);
            this.panelRegistrationPage.Controls.Add(this.labelPasswordReg);
            this.panelRegistrationPage.Controls.Add(this.labelUsernameReg);
            this.panelRegistrationPage.Controls.Add(this.labelUCBank2);
            this.panelRegistrationPage.Location = new System.Drawing.Point(272, 12);
            this.panelRegistrationPage.Name = "panelRegistrationPage";
            this.panelRegistrationPage.Size = new System.Drawing.Size(242, 223);
            this.panelRegistrationPage.TabIndex = 8;
            this.panelRegistrationPage.Visible = false;
            // 
            // btnRegisterReg
            // 
            this.btnRegisterReg.Location = new System.Drawing.Point(84, 176);
            this.btnRegisterReg.Name = "btnRegisterReg";
            this.btnRegisterReg.Size = new System.Drawing.Size(75, 23);
            this.btnRegisterReg.TabIndex = 7;
            this.btnRegisterReg.Text = "Register";
            this.btnRegisterReg.UseVisualStyleBackColor = true;
            this.btnRegisterReg.Click += new System.EventHandler(this.btnRegisterReg_Click);
            // 
            // tboxPasswordReg
            // 
            this.tboxPasswordReg.Location = new System.Drawing.Point(84, 110);
            this.tboxPasswordReg.Name = "tboxPasswordReg";
            this.tboxPasswordReg.Size = new System.Drawing.Size(119, 20);
            this.tboxPasswordReg.TabIndex = 5;
            // 
            // tboxUsernameReg
            // 
            this.tboxUsernameReg.Location = new System.Drawing.Point(84, 73);
            this.tboxUsernameReg.Name = "tboxUsernameReg";
            this.tboxUsernameReg.Size = new System.Drawing.Size(119, 20);
            this.tboxUsernameReg.TabIndex = 4;
            // 
            // labelPasswordReg
            // 
            this.labelPasswordReg.AutoSize = true;
            this.labelPasswordReg.Location = new System.Drawing.Point(21, 113);
            this.labelPasswordReg.Name = "labelPasswordReg";
            this.labelPasswordReg.Size = new System.Drawing.Size(59, 13);
            this.labelPasswordReg.TabIndex = 3;
            this.labelPasswordReg.Text = "Password: ";
            // 
            // labelUsernameReg
            // 
            this.labelUsernameReg.AutoSize = true;
            this.labelUsernameReg.Location = new System.Drawing.Point(21, 76);
            this.labelUsernameReg.Name = "labelUsernameReg";
            this.labelUsernameReg.Size = new System.Drawing.Size(61, 13);
            this.labelUsernameReg.TabIndex = 2;
            this.labelUsernameReg.Text = "Username: ";
            // 
            // labelUCBank2
            // 
            this.labelUCBank2.AutoSize = true;
            this.labelUCBank2.Font = new System.Drawing.Font("Goudy Stout", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUCBank2.Location = new System.Drawing.Point(19, 14);
            this.labelUCBank2.Name = "labelUCBank2";
            this.labelUCBank2.Size = new System.Drawing.Size(184, 28);
            this.labelUCBank2.TabIndex = 1;
            this.labelUCBank2.Text = "UC BANK";
            // 
            // panelMainView
            // 
            this.panelMainView.Controls.Add(this.btnLogOutMain);
            this.panelMainView.Controls.Add(this.btnDepositMain);
            this.panelMainView.Controls.Add(this.btnWithdrawMain);
            this.panelMainView.Controls.Add(this.labelSaldoMain);
            this.panelMainView.Controls.Add(this.labelBalanceMain);
            this.panelMainView.Controls.Add(this.labelUCBank3);
            this.panelMainView.Location = new System.Drawing.Point(532, 12);
            this.panelMainView.Name = "panelMainView";
            this.panelMainView.Size = new System.Drawing.Size(242, 223);
            this.panelMainView.TabIndex = 9;
            this.panelMainView.Visible = false;
            // 
            // btnWithdrawMain
            // 
            this.btnWithdrawMain.Location = new System.Drawing.Point(84, 176);
            this.btnWithdrawMain.Name = "btnWithdrawMain";
            this.btnWithdrawMain.Size = new System.Drawing.Size(75, 23);
            this.btnWithdrawMain.TabIndex = 7;
            this.btnWithdrawMain.Text = "Withdraw";
            this.btnWithdrawMain.UseVisualStyleBackColor = true;
            this.btnWithdrawMain.Click += new System.EventHandler(this.btnWithdrawMain_Click);
            // 
            // labelSaldoMain
            // 
            this.labelSaldoMain.AutoSize = true;
            this.labelSaldoMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.labelSaldoMain.Location = new System.Drawing.Point(112, 108);
            this.labelSaldoMain.Name = "labelSaldoMain";
            this.labelSaldoMain.Size = new System.Drawing.Size(47, 15);
            this.labelSaldoMain.TabIndex = 3;
            this.labelSaldoMain.Text = "Rp0,00";
            // 
            // labelBalanceMain
            // 
            this.labelBalanceMain.AutoSize = true;
            this.labelBalanceMain.Location = new System.Drawing.Point(40, 110);
            this.labelBalanceMain.Name = "labelBalanceMain";
            this.labelBalanceMain.Size = new System.Drawing.Size(46, 13);
            this.labelBalanceMain.TabIndex = 2;
            this.labelBalanceMain.Text = "Balance";
            // 
            // labelUCBank3
            // 
            this.labelUCBank3.AutoSize = true;
            this.labelUCBank3.Font = new System.Drawing.Font("Goudy Stout", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUCBank3.Location = new System.Drawing.Point(19, 14);
            this.labelUCBank3.Name = "labelUCBank3";
            this.labelUCBank3.Size = new System.Drawing.Size(184, 28);
            this.labelUCBank3.TabIndex = 1;
            this.labelUCBank3.Text = "UC BANK";
            // 
            // btnDepositMain
            // 
            this.btnDepositMain.Location = new System.Drawing.Point(84, 147);
            this.btnDepositMain.Name = "btnDepositMain";
            this.btnDepositMain.Size = new System.Drawing.Size(75, 23);
            this.btnDepositMain.TabIndex = 8;
            this.btnDepositMain.Text = "Deposit";
            this.btnDepositMain.UseVisualStyleBackColor = true;
            this.btnDepositMain.Click += new System.EventHandler(this.btnDepositMain_Click);
            // 
            // btnLogOutMain
            // 
            this.btnLogOutMain.Location = new System.Drawing.Point(164, 45);
            this.btnLogOutMain.Name = "btnLogOutMain";
            this.btnLogOutMain.Size = new System.Drawing.Size(58, 24);
            this.btnLogOutMain.TabIndex = 9;
            this.btnLogOutMain.Text = "Log Out";
            this.btnLogOutMain.UseVisualStyleBackColor = true;
            this.btnLogOutMain.Click += new System.EventHandler(this.btnLogOutMain_Click);
            // 
            // panelDepositView
            // 
            this.panelDepositView.Controls.Add(this.tboxAmountDeposit);
            this.panelDepositView.Controls.Add(this.btnLogOutDep);
            this.panelDepositView.Controls.Add(this.btnDepositDep);
            this.panelDepositView.Controls.Add(this.labelDepositTitle);
            this.panelDepositView.Controls.Add(this.labelUCBank4);
            this.panelDepositView.Location = new System.Drawing.Point(12, 255);
            this.panelDepositView.Name = "panelDepositView";
            this.panelDepositView.Size = new System.Drawing.Size(242, 223);
            this.panelDepositView.TabIndex = 10;
            this.panelDepositView.Visible = false;
            // 
            // btnLogOutDep
            // 
            this.btnLogOutDep.Location = new System.Drawing.Point(164, 45);
            this.btnLogOutDep.Name = "btnLogOutDep";
            this.btnLogOutDep.Size = new System.Drawing.Size(58, 24);
            this.btnLogOutDep.TabIndex = 9;
            this.btnLogOutDep.Text = "Log Out";
            this.btnLogOutDep.UseVisualStyleBackColor = true;
            this.btnLogOutDep.Click += new System.EventHandler(this.btnLogOutDep_Click);
            // 
            // btnDepositDep
            // 
            this.btnDepositDep.Location = new System.Drawing.Point(84, 136);
            this.btnDepositDep.Name = "btnDepositDep";
            this.btnDepositDep.Size = new System.Drawing.Size(75, 23);
            this.btnDepositDep.TabIndex = 8;
            this.btnDepositDep.Text = "Deposit";
            this.btnDepositDep.UseVisualStyleBackColor = true;
            this.btnDepositDep.Click += new System.EventHandler(this.btnDepositDep_Click);
            // 
            // labelDepositTitle
            // 
            this.labelDepositTitle.AutoSize = true;
            this.labelDepositTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F);
            this.labelDepositTitle.Location = new System.Drawing.Point(58, 72);
            this.labelDepositTitle.Name = "labelDepositTitle";
            this.labelDepositTitle.Size = new System.Drawing.Size(127, 15);
            this.labelDepositTitle.TabIndex = 3;
            this.labelDepositTitle.Text = "Input Deposit Amount:";
            // 
            // labelUCBank4
            // 
            this.labelUCBank4.AutoSize = true;
            this.labelUCBank4.Font = new System.Drawing.Font("Goudy Stout", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUCBank4.Location = new System.Drawing.Point(19, 14);
            this.labelUCBank4.Name = "labelUCBank4";
            this.labelUCBank4.Size = new System.Drawing.Size(184, 28);
            this.labelUCBank4.TabIndex = 1;
            this.labelUCBank4.Text = "UC BANK";
            // 
            // tboxAmountDeposit
            // 
            this.tboxAmountDeposit.Location = new System.Drawing.Point(72, 100);
            this.tboxAmountDeposit.Name = "tboxAmountDeposit";
            this.tboxAmountDeposit.Size = new System.Drawing.Size(104, 20);
            this.tboxAmountDeposit.TabIndex = 8;
            // 
            // panelWithdrawView
            // 
            this.panelWithdrawView.Controls.Add(this.labelWithdrawTitle);
            this.panelWithdrawView.Controls.Add(this.tboxAmountWithdraw);
            this.panelWithdrawView.Controls.Add(this.btnLogOutWith);
            this.panelWithdrawView.Controls.Add(this.btnWithdrawWith);
            this.panelWithdrawView.Controls.Add(this.labelSaldoWith);
            this.panelWithdrawView.Controls.Add(this.labelBalanceWith);
            this.panelWithdrawView.Controls.Add(this.labelUCBank5);
            this.panelWithdrawView.Location = new System.Drawing.Point(272, 255);
            this.panelWithdrawView.Name = "panelWithdrawView";
            this.panelWithdrawView.Size = new System.Drawing.Size(242, 223);
            this.panelWithdrawView.TabIndex = 10;
            this.panelWithdrawView.Visible = false;
            // 
            // btnLogOutWith
            // 
            this.btnLogOutWith.Location = new System.Drawing.Point(164, 45);
            this.btnLogOutWith.Name = "btnLogOutWith";
            this.btnLogOutWith.Size = new System.Drawing.Size(58, 24);
            this.btnLogOutWith.TabIndex = 9;
            this.btnLogOutWith.Text = "Log Out";
            this.btnLogOutWith.UseVisualStyleBackColor = true;
            this.btnLogOutWith.Click += new System.EventHandler(this.btnLogOutWith_Click);
            // 
            // btnWithdrawWith
            // 
            this.btnWithdrawWith.Location = new System.Drawing.Point(84, 181);
            this.btnWithdrawWith.Name = "btnWithdrawWith";
            this.btnWithdrawWith.Size = new System.Drawing.Size(75, 23);
            this.btnWithdrawWith.TabIndex = 7;
            this.btnWithdrawWith.Text = "Withdraw";
            this.btnWithdrawWith.UseVisualStyleBackColor = true;
            this.btnWithdrawWith.Click += new System.EventHandler(this.btnWithdrawWith_Click);
            // 
            // labelSaldoWith
            // 
            this.labelSaldoWith.AutoSize = true;
            this.labelSaldoWith.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.labelSaldoWith.Location = new System.Drawing.Point(112, 88);
            this.labelSaldoWith.Name = "labelSaldoWith";
            this.labelSaldoWith.Size = new System.Drawing.Size(47, 15);
            this.labelSaldoWith.TabIndex = 3;
            this.labelSaldoWith.Text = "Rp0,00";
            // 
            // labelBalanceWith
            // 
            this.labelBalanceWith.AutoSize = true;
            this.labelBalanceWith.Location = new System.Drawing.Point(36, 90);
            this.labelBalanceWith.Name = "labelBalanceWith";
            this.labelBalanceWith.Size = new System.Drawing.Size(46, 13);
            this.labelBalanceWith.TabIndex = 2;
            this.labelBalanceWith.Text = "Balance";
            // 
            // labelUCBank5
            // 
            this.labelUCBank5.AutoSize = true;
            this.labelUCBank5.Font = new System.Drawing.Font("Goudy Stout", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUCBank5.Location = new System.Drawing.Point(19, 14);
            this.labelUCBank5.Name = "labelUCBank5";
            this.labelUCBank5.Size = new System.Drawing.Size(184, 28);
            this.labelUCBank5.TabIndex = 1;
            this.labelUCBank5.Text = "UC BANK";
            // 
            // tboxAmountWithdraw
            // 
            this.tboxAmountWithdraw.Location = new System.Drawing.Point(73, 155);
            this.tboxAmountWithdraw.Name = "tboxAmountWithdraw";
            this.tboxAmountWithdraw.Size = new System.Drawing.Size(104, 20);
            this.tboxAmountWithdraw.TabIndex = 10;
            // 
            // labelWithdrawTitle
            // 
            this.labelWithdrawTitle.AutoSize = true;
            this.labelWithdrawTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F);
            this.labelWithdrawTitle.Location = new System.Drawing.Point(60, 136);
            this.labelWithdrawTitle.Name = "labelWithdrawTitle";
            this.labelWithdrawTitle.Size = new System.Drawing.Size(136, 15);
            this.labelWithdrawTitle.TabIndex = 10;
            this.labelWithdrawTitle.Text = "Input Withdraw Amount:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 581);
            this.Controls.Add(this.panelWithdrawView);
            this.Controls.Add(this.panelDepositView);
            this.Controls.Add(this.panelMainView);
            this.Controls.Add(this.panelRegistrationPage);
            this.Controls.Add(this.panelLoginView);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelLoginView.ResumeLayout(false);
            this.panelLoginView.PerformLayout();
            this.panelRegistrationPage.ResumeLayout(false);
            this.panelRegistrationPage.PerformLayout();
            this.panelMainView.ResumeLayout(false);
            this.panelMainView.PerformLayout();
            this.panelDepositView.ResumeLayout(false);
            this.panelDepositView.PerformLayout();
            this.panelWithdrawView.ResumeLayout(false);
            this.panelWithdrawView.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLoginView;
        private System.Windows.Forms.Label LabelUCBank;
        private System.Windows.Forms.Button btnRegisterLog;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox tboxPasswordLog;
        private System.Windows.Forms.TextBox tboxUsernameLog;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Panel panelRegistrationPage;
        private System.Windows.Forms.Button btnRegisterReg;
        private System.Windows.Forms.TextBox tboxPasswordReg;
        private System.Windows.Forms.TextBox tboxUsernameReg;
        private System.Windows.Forms.Label labelPasswordReg;
        private System.Windows.Forms.Label labelUsernameReg;
        private System.Windows.Forms.Label labelUCBank2;
        private System.Windows.Forms.Panel panelMainView;
        private System.Windows.Forms.Button btnLogOutMain;
        private System.Windows.Forms.Button btnDepositMain;
        private System.Windows.Forms.Button btnWithdrawMain;
        private System.Windows.Forms.Label labelSaldoMain;
        private System.Windows.Forms.Label labelBalanceMain;
        private System.Windows.Forms.Label labelUCBank3;
        private System.Windows.Forms.Panel panelDepositView;
        private System.Windows.Forms.Button btnLogOutDep;
        private System.Windows.Forms.Button btnDepositDep;
        private System.Windows.Forms.Label labelDepositTitle;
        private System.Windows.Forms.Label labelUCBank4;
        private System.Windows.Forms.TextBox tboxAmountDeposit;
        private System.Windows.Forms.Panel panelWithdrawView;
        private System.Windows.Forms.Button btnLogOutWith;
        private System.Windows.Forms.Button btnWithdrawWith;
        private System.Windows.Forms.Label labelSaldoWith;
        private System.Windows.Forms.Label labelBalanceWith;
        private System.Windows.Forms.Label labelUCBank5;
        private System.Windows.Forms.Label labelWithdrawTitle;
        private System.Windows.Forms.TextBox tboxAmountWithdraw;
    }
}

