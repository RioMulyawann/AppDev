﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH_WEEK_4_AD
{
    internal class Team
    {
        public string TeamNames;
        public string TeamCountrys;
        public string TeamCitys;
        public List<Players> Playerlists;


        public Team (string TeamNames, string TeamCountrys, string TeamCitys, List<Players> PlayerLists)
        {
            this.TeamName = TeamNames;
            this.TeamCountry = TeamCountrys;
            this.TeamCity = TeamCitys;
            this.Playerlist = PlayerLists;
            
        }
        public string TeamName { get; set; }
        public string TeamCountry { get; set; }
        public string TeamCity { get; set; }
        internal List<Players> Playerlist { get; set; }

    }
}
