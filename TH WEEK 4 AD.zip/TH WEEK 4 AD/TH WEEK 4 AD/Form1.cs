﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_WEEK_4_AD
{
    public partial class Form1 : Form
    {
        List<Team> TeamLists;
        List<string> CountryList;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Players> PlayerTeamList1 = new List<Players>
            {
                new Players("01","Kepa Arruzabalaga", "GK"),
                new Players("04","Benoit Badiashile","DF"),
                new Players("05","Enzo Fernandez","MF"),
                new Players("06","Thiago Silva","DF"),
                new Players("07","N'Golo Kante","MF"),
                new Players("08","Mateo Kovacic","MF"),
                new Players("09","Pierre-Emerick Aubameyang","FW"),
                new Players("10","Christian Pulisic","MF"),
                new Players("11","Joao Felix","FW"),
                new Players("12","Ruben Lotus-Cheek","MF"),
                new Players("17","Raheem Sterling","MF")
            };
            List<Players> PlayerTeamList2 = new List<Players>
            {
                new Players("01","David De Gea","GK"),
                new Players("02","Victor Lindelof","DF"),
                new Players("04","Phil Jones","DF"),
                new Players("05","Harry Maguire","DF"),
                new Players("06","Lisandro Martinez","DF"),
                new Players("08","Bruno Fernandez","MF"),
                new Players("09","Anthony Martial","FW"),
                new Players("10","Marcus Rashford","FW"),
                new Players("12","Tyrell Malacia","DF"),
                new Players("14","Christian Eriksen","MF"),
                new Players("18","Casemiro","MF"),
            };
            List<Players> PlayerTeamList3 = new List<Players>
            {
                new Players("01","Manuel Neuer","DF"),
                new Players("02","Dayot Upamecano","MF"),
                new Players("04","Matthijs De Ligt","FW"),
                new Players("05","Benjamin Pavard","MF"),
                new Players("06","Joshua Kimmich","FW"),
                new Players("07","Serge Gnabry","MF"),
                new Players("08","Leon Goretzka","MF"),
                new Players("10","Leroy Sane","FW"),
                new Players("14","Paul Wanner","MF"),
                new Players("21","Lucas Hernandez","DF"),
                new Players("25","Thomas Muller","FW"),
            };
            Team Team1 = new Team("Chelsea", "England", "Fulham", PlayerTeamList1);
            Team Team2 = new Team("Manchester United", "England", "Manchester", PlayerTeamList2);
            Team Team3 = new Team("Bayern Munich", "Germany", "Munich", PlayerTeamList3);
            comboxPlayerPosition.Items.Add("GK");
            comboxPlayerPosition.Items.Add("DF");
            comboxPlayerPosition.Items.Add("MF");
            comboxPlayerPosition.Items.Add("FW");

            TeamLists = new List<Team> { Team1, Team2, Team3 };
            CountryList = new List<string> { "England", "Germany" };
            comboxCountry.DataSource = CountryList;
            comboxCountry.SelectedItem = null;
            comboxTeam.SelectedItem = null;

            listBoxPlayers.Items.Clear();
            



        }

        private void comboxCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            string chosenCountry = (string)comboxCountry.SelectedItem;
            List<Team> TemporaryTeam = new List<Team>();
            foreach (Team team in TeamLists)
            {
                if (team.TeamCountry == chosenCountry)
                {
                    TemporaryTeam.Add(team);
                }
            }
            comboxTeam.DataSource = TemporaryTeam;
            comboxTeam.DisplayMember = "TeamName";



        }

        private void comboxTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBoxPlayers.Items.Clear();
            
            Team ChosenTeam = (Team)comboxTeam.SelectedItem;
            if (ChosenTeam.Playerlist != null)
            {
                
                foreach (Players a in ChosenTeam.Playerlist)
                {

                    listBoxPlayers.Items.Add($"[{a.PlayerNumber}] {a.PlayerName}, {a.PlayerPosition}");


                }
            }
        }

        private void btnAddTeam_Click(object sender, EventArgs e)
        {
            if (tboxTeamName.Text == "" || tboxTeamCountry.Text =="" || tboxTeamCity.Text == "")
            {
                MessageBox.Show("All fields must be filled!","Error 404",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool checker = true;
                foreach (Team a in TeamLists)
                {
                    
                    if (a.TeamName == tboxTeamName.Text)
                    {
                        checker= false;
                    }
                   
                }
               if (checker == false)
                {
                    MessageBox.Show("Team name already exist...");
                }
               else
                {
                    Team NewTeam = new Team (tboxTeamName.Text, tboxTeamCountry.Text, tboxTeamCity.Text,new List<Players>());
                    TeamLists.Add(NewTeam);
                    comboxCountry.SelectedItem = null;
                    if (!CountryList.Contains(tboxTeamCountry.Text))
                    {
                        CountryList.Add(tboxTeamCountry.Text);
                        comboxCountry.DataSource = null;
                        comboxCountry.DataSource = CountryList;
                    }
                    tboxTeamCity.Clear();
                    tboxTeamCountry.Clear();
                    tboxTeamName.Clear();
                }
            }
        }

        private void btnAddPlayer_Click(object sender, EventArgs e)
        {
            if (tboxPlayerNumber.Text == "" || tboxPlayerName.Text == "" || (string)comboxPlayerPosition.SelectedItem == "")
            {
                MessageBox.Show("All fields must be filled!", "Error 404", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool checker = true;
                Team ChosenTeam = (Team)comboxTeam.SelectedItem;
                string position = (string)comboxPlayerPosition.SelectedItem;
                Players NewPlayer = new Players(tboxPlayerNumber.Text,tboxPlayerName.Text,position);
                foreach(Players b in ChosenTeam.Playerlist)
                {
                    if(b.PlayerNumber == tboxPlayerNumber.Text)
                    {
                        checker = false;
                    }
                }
                if (checker == false)
                {
                    MessageBox.Show("Player with the same number is found..");
                }
                else
                {
                    ChosenTeam.Playerlist.Add(NewPlayer);
                    listBoxPlayers.Items.Clear();
                    foreach(Players a in ChosenTeam.Playerlist)
                    {
                        listBoxPlayers.Items.Add($"[{a.PlayerNumber}] {a.PlayerName}, {a.PlayerPosition}");
                    }
                    tboxPlayerName.Clear();
                    tboxPlayerNumber.Clear();
                    comboxPlayerPosition.SelectedItem = -1;
                }

            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            Team ChosenTeam = (Team)comboxTeam.SelectedItem;
            if (ChosenTeam.Playerlist.Count > 11)
            {
                ChosenTeam.Playerlist.RemoveAt(listBoxPlayers.SelectedIndex);
                listBoxPlayers.Items.Clear();
                foreach (Players a in ChosenTeam.Playerlist)
                {
                    listBoxPlayers.Items.Add($"[{a.PlayerNumber}] {a.PlayerName}, {a.PlayerPosition}");
                }
            }
            else
            {
                MessageBox.Show("Number of players are less than 11","Error 404",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
    }
}
