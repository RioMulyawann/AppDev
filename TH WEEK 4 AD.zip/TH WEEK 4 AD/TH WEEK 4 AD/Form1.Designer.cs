﻿namespace TH_WEEK_4_AD
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LabelTeamTitle = new System.Windows.Forms.Label();
            this.labelChooseCountry = new System.Windows.Forms.Label();
            this.labelChooseTeam = new System.Windows.Forms.Label();
            this.comboxCountry = new System.Windows.Forms.ComboBox();
            this.comboxTeam = new System.Windows.Forms.ComboBox();
            this.labelTeamName = new System.Windows.Forms.Label();
            this.labelTeamCountry = new System.Windows.Forms.Label();
            this.labelTeamCity = new System.Windows.Forms.Label();
            this.tboxTeamName = new System.Windows.Forms.TextBox();
            this.tboxTeamCountry = new System.Windows.Forms.TextBox();
            this.tboxTeamCity = new System.Windows.Forms.TextBox();
            this.btnAddTeam = new System.Windows.Forms.Button();
            this.labelAddTeam = new System.Windows.Forms.Label();
            this.labelAddPlayers = new System.Windows.Forms.Label();
            this.btnAddPlayer = new System.Windows.Forms.Button();
            this.tboxPlayerNumber = new System.Windows.Forms.TextBox();
            this.tboxPlayerName = new System.Windows.Forms.TextBox();
            this.labelPlayerPosition = new System.Windows.Forms.Label();
            this.labelPlayerNumber = new System.Windows.Forms.Label();
            this.labelPlayerName = new System.Windows.Forms.Label();
            this.listBoxPlayers = new System.Windows.Forms.ListBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.comboxPlayerPosition = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // LabelTeamTitle
            // 
            this.LabelTeamTitle.AutoSize = true;
            this.LabelTeamTitle.Location = new System.Drawing.Point(51, 84);
            this.LabelTeamTitle.Name = "LabelTeamTitle";
            this.LabelTeamTitle.Size = new System.Drawing.Size(90, 13);
            this.LabelTeamTitle.TabIndex = 0;
            this.LabelTeamTitle.Text = "Soccer Team List";
            // 
            // labelChooseCountry
            // 
            this.labelChooseCountry.AutoSize = true;
            this.labelChooseCountry.Location = new System.Drawing.Point(51, 112);
            this.labelChooseCountry.Name = "labelChooseCountry";
            this.labelChooseCountry.Size = new System.Drawing.Size(88, 13);
            this.labelChooseCountry.TabIndex = 1;
            this.labelChooseCountry.Text = "Choose Country: ";
            // 
            // labelChooseTeam
            // 
            this.labelChooseTeam.AutoSize = true;
            this.labelChooseTeam.Location = new System.Drawing.Point(51, 146);
            this.labelChooseTeam.Name = "labelChooseTeam";
            this.labelChooseTeam.Size = new System.Drawing.Size(79, 13);
            this.labelChooseTeam.TabIndex = 2;
            this.labelChooseTeam.Text = "Choose Team: ";
            // 
            // comboxCountry
            // 
            this.comboxCountry.FormattingEnabled = true;
            this.comboxCountry.Location = new System.Drawing.Point(145, 109);
            this.comboxCountry.Name = "comboxCountry";
            this.comboxCountry.Size = new System.Drawing.Size(141, 21);
            this.comboxCountry.TabIndex = 3;
            this.comboxCountry.SelectedIndexChanged += new System.EventHandler(this.comboxCountry_SelectedIndexChanged);
            // 
            // comboxTeam
            // 
            this.comboxTeam.FormattingEnabled = true;
            this.comboxTeam.Location = new System.Drawing.Point(145, 146);
            this.comboxTeam.Name = "comboxTeam";
            this.comboxTeam.Size = new System.Drawing.Size(141, 21);
            this.comboxTeam.TabIndex = 4;
            this.comboxTeam.SelectedIndexChanged += new System.EventHandler(this.comboxTeam_SelectedIndexChanged);
            // 
            // labelTeamName
            // 
            this.labelTeamName.AutoSize = true;
            this.labelTeamName.Location = new System.Drawing.Point(349, 112);
            this.labelTeamName.Name = "labelTeamName";
            this.labelTeamName.Size = new System.Drawing.Size(71, 13);
            this.labelTeamName.TabIndex = 5;
            this.labelTeamName.Text = "Team Name: ";
            // 
            // labelTeamCountry
            // 
            this.labelTeamCountry.AutoSize = true;
            this.labelTeamCountry.Location = new System.Drawing.Point(349, 146);
            this.labelTeamCountry.Name = "labelTeamCountry";
            this.labelTeamCountry.Size = new System.Drawing.Size(79, 13);
            this.labelTeamCountry.TabIndex = 6;
            this.labelTeamCountry.Text = "Team Country: ";
            // 
            // labelTeamCity
            // 
            this.labelTeamCity.AutoSize = true;
            this.labelTeamCity.Location = new System.Drawing.Point(349, 182);
            this.labelTeamCity.Name = "labelTeamCity";
            this.labelTeamCity.Size = new System.Drawing.Size(60, 13);
            this.labelTeamCity.TabIndex = 7;
            this.labelTeamCity.Text = "Team City: ";
            // 
            // tboxTeamName
            // 
            this.tboxTeamName.Location = new System.Drawing.Point(434, 110);
            this.tboxTeamName.Name = "tboxTeamName";
            this.tboxTeamName.Size = new System.Drawing.Size(126, 20);
            this.tboxTeamName.TabIndex = 8;
            // 
            // tboxTeamCountry
            // 
            this.tboxTeamCountry.Location = new System.Drawing.Point(434, 146);
            this.tboxTeamCountry.Name = "tboxTeamCountry";
            this.tboxTeamCountry.Size = new System.Drawing.Size(126, 20);
            this.tboxTeamCountry.TabIndex = 9;
            // 
            // tboxTeamCity
            // 
            this.tboxTeamCity.Location = new System.Drawing.Point(434, 181);
            this.tboxTeamCity.Name = "tboxTeamCity";
            this.tboxTeamCity.Size = new System.Drawing.Size(126, 20);
            this.tboxTeamCity.TabIndex = 10;
            // 
            // btnAddTeam
            // 
            this.btnAddTeam.Location = new System.Drawing.Point(434, 218);
            this.btnAddTeam.Name = "btnAddTeam";
            this.btnAddTeam.Size = new System.Drawing.Size(55, 23);
            this.btnAddTeam.TabIndex = 11;
            this.btnAddTeam.Text = "Add";
            this.btnAddTeam.UseVisualStyleBackColor = true;
            this.btnAddTeam.Click += new System.EventHandler(this.btnAddTeam_Click);
            // 
            // labelAddTeam
            // 
            this.labelAddTeam.AutoSize = true;
            this.labelAddTeam.Location = new System.Drawing.Point(431, 84);
            this.labelAddTeam.Name = "labelAddTeam";
            this.labelAddTeam.Size = new System.Drawing.Size(70, 13);
            this.labelAddTeam.TabIndex = 12;
            this.labelAddTeam.Text = "Adding Team";
            // 
            // labelAddPlayers
            // 
            this.labelAddPlayers.AutoSize = true;
            this.labelAddPlayers.Location = new System.Drawing.Point(673, 83);
            this.labelAddPlayers.Name = "labelAddPlayers";
            this.labelAddPlayers.Size = new System.Drawing.Size(77, 13);
            this.labelAddPlayers.TabIndex = 20;
            this.labelAddPlayers.Text = "Adding Players";
            // 
            // btnAddPlayer
            // 
            this.btnAddPlayer.Location = new System.Drawing.Point(676, 217);
            this.btnAddPlayer.Name = "btnAddPlayer";
            this.btnAddPlayer.Size = new System.Drawing.Size(55, 23);
            this.btnAddPlayer.TabIndex = 19;
            this.btnAddPlayer.Text = "Add";
            this.btnAddPlayer.UseVisualStyleBackColor = true;
            this.btnAddPlayer.Click += new System.EventHandler(this.btnAddPlayer_Click);
            // 
            // tboxPlayerNumber
            // 
            this.tboxPlayerNumber.Location = new System.Drawing.Point(676, 145);
            this.tboxPlayerNumber.Name = "tboxPlayerNumber";
            this.tboxPlayerNumber.Size = new System.Drawing.Size(126, 20);
            this.tboxPlayerNumber.TabIndex = 17;
            // 
            // tboxPlayerName
            // 
            this.tboxPlayerName.Location = new System.Drawing.Point(676, 109);
            this.tboxPlayerName.Name = "tboxPlayerName";
            this.tboxPlayerName.Size = new System.Drawing.Size(126, 20);
            this.tboxPlayerName.TabIndex = 16;
            // 
            // labelPlayerPosition
            // 
            this.labelPlayerPosition.AutoSize = true;
            this.labelPlayerPosition.Location = new System.Drawing.Point(591, 181);
            this.labelPlayerPosition.Name = "labelPlayerPosition";
            this.labelPlayerPosition.Size = new System.Drawing.Size(82, 13);
            this.labelPlayerPosition.TabIndex = 15;
            this.labelPlayerPosition.Text = "Player Position: ";
            // 
            // labelPlayerNumber
            // 
            this.labelPlayerNumber.AutoSize = true;
            this.labelPlayerNumber.Location = new System.Drawing.Point(591, 145);
            this.labelPlayerNumber.Name = "labelPlayerNumber";
            this.labelPlayerNumber.Size = new System.Drawing.Size(79, 13);
            this.labelPlayerNumber.TabIndex = 14;
            this.labelPlayerNumber.Text = "Player Number:";
            // 
            // labelPlayerName
            // 
            this.labelPlayerName.AutoSize = true;
            this.labelPlayerName.Location = new System.Drawing.Point(591, 111);
            this.labelPlayerName.Name = "labelPlayerName";
            this.labelPlayerName.Size = new System.Drawing.Size(73, 13);
            this.labelPlayerName.TabIndex = 13;
            this.labelPlayerName.Text = "Player Name: ";
            // 
            // listBoxPlayers
            // 
            this.listBoxPlayers.FormattingEnabled = true;
            this.listBoxPlayers.Location = new System.Drawing.Point(54, 217);
            this.listBoxPlayers.Name = "listBoxPlayers";
            this.listBoxPlayers.Size = new System.Drawing.Size(232, 134);
            this.listBoxPlayers.TabIndex = 21;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(54, 357);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(87, 23);
            this.btnRemove.TabIndex = 22;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // comboxPlayerPosition
            // 
            this.comboxPlayerPosition.AutoCompleteCustomSource.AddRange(new string[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.comboxPlayerPosition.FormattingEnabled = true;
            this.comboxPlayerPosition.Location = new System.Drawing.Point(676, 180);
            this.comboxPlayerPosition.Name = "comboxPlayerPosition";
            this.comboxPlayerPosition.Size = new System.Drawing.Size(126, 21);
            this.comboxPlayerPosition.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(848, 450);
            this.Controls.Add(this.comboxPlayerPosition);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.listBoxPlayers);
            this.Controls.Add(this.labelAddPlayers);
            this.Controls.Add(this.btnAddPlayer);
            this.Controls.Add(this.tboxPlayerNumber);
            this.Controls.Add(this.tboxPlayerName);
            this.Controls.Add(this.labelPlayerPosition);
            this.Controls.Add(this.labelPlayerNumber);
            this.Controls.Add(this.labelPlayerName);
            this.Controls.Add(this.labelAddTeam);
            this.Controls.Add(this.btnAddTeam);
            this.Controls.Add(this.tboxTeamCity);
            this.Controls.Add(this.tboxTeamCountry);
            this.Controls.Add(this.tboxTeamName);
            this.Controls.Add(this.labelTeamCity);
            this.Controls.Add(this.labelTeamCountry);
            this.Controls.Add(this.labelTeamName);
            this.Controls.Add(this.comboxTeam);
            this.Controls.Add(this.comboxCountry);
            this.Controls.Add(this.labelChooseTeam);
            this.Controls.Add(this.labelChooseCountry);
            this.Controls.Add(this.LabelTeamTitle);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelTeamTitle;
        private System.Windows.Forms.Label labelChooseCountry;
        private System.Windows.Forms.Label labelChooseTeam;
        private System.Windows.Forms.ComboBox comboxCountry;
        private System.Windows.Forms.ComboBox comboxTeam;
        private System.Windows.Forms.Label labelTeamName;
        private System.Windows.Forms.Label labelTeamCountry;
        private System.Windows.Forms.Label labelTeamCity;
        private System.Windows.Forms.TextBox tboxTeamName;
        private System.Windows.Forms.TextBox tboxTeamCountry;
        private System.Windows.Forms.TextBox tboxTeamCity;
        private System.Windows.Forms.Button btnAddTeam;
        private System.Windows.Forms.Label labelAddTeam;
        private System.Windows.Forms.Label labelAddPlayers;
        private System.Windows.Forms.Button btnAddPlayer;
        private System.Windows.Forms.TextBox tboxPlayerNumber;
        private System.Windows.Forms.TextBox tboxPlayerName;
        private System.Windows.Forms.Label labelPlayerPosition;
        private System.Windows.Forms.Label labelPlayerNumber;
        private System.Windows.Forms.Label labelPlayerName;
        private System.Windows.Forms.ListBox listBoxPlayers;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.ComboBox comboxPlayerPosition;
    }
}

