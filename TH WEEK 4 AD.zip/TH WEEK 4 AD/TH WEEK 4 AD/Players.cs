﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH_WEEK_4_AD
{
    internal class Players
    {
        public string PlayerNumbers;
        public string PlayerNames;
        public string PlayerPositions;
        

        public Players(string PlayerNumbers, string PlayerNames, string PlayerPositions) 
        {
            this.PlayerNumber = PlayerNumbers;
            this.PlayerName = PlayerNames;
            this.PlayerPosition = PlayerPositions;
        }
        public string PlayerNumber { get => PlayerNames; set => PlayerNames = value; }
        public string PlayerName { get; set; }
        public string PlayerPosition { get; set; }
    }
}
