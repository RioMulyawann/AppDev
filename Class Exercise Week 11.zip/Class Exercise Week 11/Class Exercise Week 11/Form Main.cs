﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Class_Exercise_Week_11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlAdapter;
        
        DataTable dtTeam = new DataTable();
        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnection = new MySqlConnection("server =localhost;uid=root;password=isbmantap;database=premier_league");
            sqlConnection.Open();
            sqlConnection.Close();
            // if ([Condition],[True],[False])
            //string sqlQuery = "Select player_id as 'Player ID', player_name as 'Player Name', IF(playing_pos = 'D','Defender',IF(playing_pos = 'F','Forward',IF(playing_pos = 'G','GoalKeeper','Midfielder'))) as 'Playing Position', team_name as 'Team Name', nation AS 'Nationality' FROM Player,team,nationality WHERE team.team_id = player.team_id AND player.nationality_id = nationality.nationality_id";
            //string sqlQuery = "Select match_id,match_date,t.team_name as 'TEAM HOME', t2.team_name as 'TEAM AWAY' FROM `match` m,team t, team t2 WHERE team_home = t.team_id AND team_away = t2.team_id";

            string sqlQuery = "SELECT t.team_id as 'TEAM ID', team_name AS 'TEAM NAME',home_stadium AS 'HOME STADIUM', capacity AS 'CAPACITY', city as 'CITY', m.manager_name AS 'MANAGER NAME', m2.manager_name as 'ASSISTANT MANAGER', p.player_name as 'CAPTAIN NAME' FROM Team t,Player p,manager m, manager m2 WHERE t.manager_id = m.manager_id AND t.assmanager_id = m2.manager_id AND t.captain_id = p.player_id";
            sqlCommand = new MySqlCommand(sqlQuery,sqlConnection);
            sqlAdapter= new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtTeam);
            dataGridViewTable.DataSource = dtTeam;

            
        }
    }
}
