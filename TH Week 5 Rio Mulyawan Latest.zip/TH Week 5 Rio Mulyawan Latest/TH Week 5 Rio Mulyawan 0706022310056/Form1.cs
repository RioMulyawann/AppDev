﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week_5_Rio_Mulyawan_0706022310056
{
    public partial class ShopProgram : Form
    {
        DataTable ProductDataSimpan;
        DataTable CategoryData;
        DataTable ProductDataTampil;
        int totalCategory = 5;
        public ShopProgram()
        {
            InitializeComponent();
            ProductDataSimpan = new DataTable();
            CategoryData = new DataTable();
            ProductDataTampil = new DataTable();
            
        }

        private void ShopProgram_Load(object sender, EventArgs e)
        {

            ProductDataSimpan.Columns.Add("ID Product");
            ProductDataSimpan.Columns.Add("Nama Product");
            ProductDataSimpan.Columns.Add("Harga");
            ProductDataSimpan.Columns.Add("Stock");
            ProductDataSimpan.Columns.Add("ID Category");

            ProductDataTampil.Columns.Add("ID Product");
            ProductDataTampil.Columns.Add("Nama Product");
            ProductDataTampil.Columns.Add("Harga");
            ProductDataTampil.Columns.Add("Stock");
            ProductDataTampil.Columns.Add("ID Category");

            CategoryData.Columns.Add("ID Category");
            CategoryData.Columns.Add("Nama Category");

            dataGridCategory.DataSource = CategoryData;
            dataGridProduct.DataSource = ProductDataSimpan;

     

            ProductDataSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            ProductDataSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            ProductDataSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            ProductDataSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            ProductDataSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            ProductDataSimpan.Rows.Add("C001", "Celana Pendek Coklat ", "60000", "11", "C4");
            ProductDataSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            ProductDataSimpan.Rows.Add("R002", "Rocca T-Shirt", "50000", "8", "C2");

            CategoryData.Rows.Add("C1", "Jas");
            CategoryData.Rows.Add("C2", "T-Shirt");
            CategoryData.Rows.Add("C3", "Rok");
            CategoryData.Rows.Add("C4", "Celana");
            CategoryData.Rows.Add("C5", "Cawat");

            for (int i = 0; i < CategoryData.Rows.Count; i++)
            {
                cboxCategory.Items.Add(CategoryData.Rows[i][1].ToString());
            }

            
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            cboxFilter.Enabled = true;

            for (int i = 0; i < CategoryData.Rows.Count; i++)
            {
                if (cboxFilter.Items.Contains(CategoryData.Rows[i][1].ToString()))
                {

                }
                else
                {
                    cboxFilter.Items.Add(CategoryData.Rows[i][1].ToString());
                }
               
            }

        }

        private void cboxFilter_SelectedValueChanged(object sender, EventArgs e)
        {
            string FilterID = "";
            if (cboxFilter.SelectedIndex != -1)
            {
                ProductDataTampil.Rows.Clear();

                
                for (int i = 0; i < CategoryData.Rows.Count; i++)
                {
                    if (CategoryData.Rows[i][1].ToString().Contains(cboxFilter.SelectedItem.ToString()))
                    {
                        FilterID = CategoryData.Rows[i][0].ToString();
                    }
                }

                foreach (DataRow dr in ProductDataSimpan.Rows)
                {
                    if (dr[4].ToString() == FilterID)
                    {
                        ProductDataTampil.Rows.Add(dr.ItemArray);
                    }
                }
                dataGridProduct.DataSource = ProductDataTampil;


            }


        }

        private void btnFilterAll_Click(object sender, EventArgs e)
        {
            dataGridProduct.DataSource = ProductDataSimpan;
            cboxFilter.SelectedIndex = -1;
            cboxFilter.Enabled = false;
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            int idChecker = 0;
            string TempID = "";
            if (tbNamaProduct.Text == "" || tbHarga.Text == "" || tbStock.Text == "" || cboxCategory.SelectedItem == null)
            {
                MessageBox.Show("Input yang lenkap dong");
                tbNamaProduct.Clear();
                cboxCategory.SelectedIndex = -1;
                tbStock.Clear();
                tbHarga.Clear();
            }
            else
            {

                for (int i = 0; i < ProductDataSimpan.Rows.Count; i++)
                {
                    if (ProductDataSimpan.Rows[i][0].ToString().Substring(0, 1).ToUpper() == tbNamaProduct.Text.Substring(0, 1).ToUpper())
                    {
                        idChecker++;
                    }
                    
                }
                for (int i = 0; i < ProductDataSimpan.Rows.Count; i++)
                {
                    if (tbNamaProduct.Text.Substring(0,1).ToUpper()+"00" + (idChecker+1) == ProductDataSimpan.Rows[i][0].ToString())
                    {
                        idChecker++;
                    }
                }
                    


                if (idChecker < 10)
                {
                    TempID = tbNamaProduct.Text.Substring(0, 1).ToUpper() + "00" + (idChecker+1).ToString();
                }
                else if (idChecker >= 10 && idChecker < 100)
                {
                    TempID = tbNamaProduct.Text.Substring(0, 1).ToUpper() + "0" + (idChecker+1).ToString();
                }
                else
                {
                    TempID = tbNamaProduct.Text.Substring(0, 1).ToUpper() + (idChecker+1).ToString();
                }



                string CategoryID = "";
                for (int i = 0; i < CategoryData.Rows.Count; i++)
                {
                    if (CategoryData.Rows[i][1].ToString().Contains(cboxCategory.SelectedItem.ToString()))
                    {
                        CategoryID = CategoryData.Rows[i][0].ToString();
                    }
                }

                ProductDataSimpan.Rows.Add(TempID, tbNamaProduct.Text, tbHarga.Text, tbStock.Text, CategoryID);

                tbNamaProduct.Clear();
                cboxCategory.SelectedIndex = -1;
                tbStock.Clear();
                tbHarga.Clear();
            }
            
        }

        private void dataGridProduct_SelectionChanged(object sender, EventArgs e)
        {
            tbNamaProduct.Clear();
            tbStock.Clear();
            tbHarga.Clear();
            string sementara = "";
            string CategoryTemp = "";

            if (dataGridProduct.SelectedRows != null)
            {
                foreach (DataGridViewRow row in dataGridProduct.SelectedRows)
                {
                    tbNamaProduct.Text = row.Cells[1].Value.ToString();
                    tbHarga.Text = row.Cells[2].Value.ToString();
                    tbStock.Text = row.Cells[3].Value.ToString();
                    sementara = row.Cells[4].Value.ToString();
                }
                foreach (DataRow row in CategoryData.Rows)
                {
                    if (row[0].ToString().Contains(sementara))
                    {
                        CategoryTemp = row[1].ToString();
                    }
                }
                cboxCategory.SelectedItem = CategoryTemp;
            }
        }

        private void dataGridCategory_SelectionChanged(object sender, EventArgs e)
        {

            tbNamaCategory.Clear();
            foreach (DataGridViewRow row in dataGridCategory.SelectedRows)
            {
                tbNamaCategory.Text = row.Cells[1].Value.ToString();
            }
            if (dataGridCategory.SelectedRows == null)
            {
                cboxCategory.SelectedIndex = -1;
            }
        }

        private void dataGridProduct_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dataGridProduct.ClearSelection();
            dataGridCategory.ClearSelection();
            cboxCategory.SelectedIndex = -1;
        }

        private void btnEditProduct_Click(object sender, EventArgs e)
        {
            string CategoryID = "";
            if (tbNamaProduct.Text != "" || tbHarga.Text != "" || tbStock.Text != "" || cboxCategory.SelectedItem != null)
            {
                for (int i = 0; i < CategoryData.Rows.Count; i++)
                {
                    if (CategoryData.Rows[i][1].ToString().Contains(cboxCategory.SelectedItem.ToString()))
                    {
                        CategoryID = CategoryData.Rows[i][0].ToString();
                    }
                }

                foreach (DataGridViewRow row in dataGridProduct.SelectedRows)
                {
                    row.Cells[1].Value = tbNamaProduct.Text;
                    row.Cells[2].Value = tbHarga.Text;
                    row.Cells[3].Value = tbStock.Text;
                    row.Cells[4].Value = CategoryID;

                }

                tbNamaProduct.Clear();
                cboxCategory.SelectedItem = null;
                tbStock.Clear();
                tbHarga.Clear();
                dataGridProduct.ClearSelection();
                if (dataGridCategory.SelectedRows == null)
                {
                    cboxCategory.SelectedIndex = -1;
                }
            }
               
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            bool checker = true;
            if (tbNamaCategory.Text == "")
            {
                MessageBox.Show("Masukan nama category terlebih dahulu ya ");
            }
            else
            {
                foreach (DataRow row in CategoryData.Rows)
                {
                    if (row[1].ToString() == tbNamaCategory.Text)
                    {
                        MessageBox.Show("Category sudah ada");
                        dataGridCategory.ClearSelection();
                        checker = false;
                    }

                }

                if (checker == true)
                {
                    if (CategoryData.Rows.Count == 0)
                    {
                        totalCategory = 0;
                    }
                    CategoryData.Rows.Add("C" + (totalCategory + 1), tbNamaCategory.Text);
                    totalCategory++;

                }
            }
           
            tbNamaCategory.Clear();


        }

        private void btnRemoveCategory_Click(object sender, EventArgs e)
        {
            dataGridProduct.ClearSelection();
            string CatID = "";
            foreach (DataGridViewRow row in dataGridCategory.SelectedRows)
            {
                CatID = CategoryData.Rows[row.Index][0].ToString();
                CategoryData.Rows.RemoveAt(row.Index);
                
            }

            dataGridCategory.ClearSelection();
            tbNamaCategory.Clear();
            List <int> indexRows = new List<int>();
            int totalyangada = 0;
            for (int i = 0; i < ProductDataSimpan.Rows.Count; i++)
            {
                
                if (ProductDataSimpan.Rows[i][4].ToString() == CatID)
                {
                    totalyangada++;
                    
                }
            }
            bool b = true;
            for (int i = 0; i< totalyangada; i++)
            {
                for (int j = 0; j < ProductDataSimpan.Rows.Count; j++)
                {
                    if (ProductDataSimpan.Rows[j][4].ToString() == CatID && b == true)
                    {
                        ProductDataSimpan.Rows[j].Delete();
                        b = false;
                    }
                }
                b = true;
            }
        }

        private void btnRemoveProduct_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridProduct.SelectedRows)
            {
                ProductDataSimpan.Rows.RemoveAt(row.Index);
                
            }

        }

        private void cboxCategory_Click(object sender, EventArgs e)
        {
            cboxCategory.Items.Clear();
            for (int i = 0; i < CategoryData.Rows.Count; i++)
            {
                cboxCategory.Items.Add(CategoryData.Rows[i][1].ToString());
            }
            cboxCategory.SelectedItem = null;
        }
    }
}
